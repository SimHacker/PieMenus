		"    Occasional User Advice\n\n\
Aim!\n\
Don't try to save all your cities.\n\
Never stop working in the launch screen:\n\
  scoring is higher, and every shot is worth three on the city screen (MIRVs).\n\
Lasers take longer to get going, but have a longer range.\n\
For fast moving missiles, use rocks or interceptors.\n\
Learn the shift and meta keys."
