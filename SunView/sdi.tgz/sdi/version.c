char *version =  "Version 210 of tumtum, Tue Jan 16 03:17:47 EST 1990";
