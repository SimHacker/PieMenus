#include <setjmp.h>
static int argc = 1;
static char *argv[] = {"sdi", 0};

extern XR_gc_check_magic, XR_gc_make_magic;

static void
XR_load_gcsdi()
{
  printf("loading done, call 'doit' to start sdi.\n");
}

static jmp_buf buff;

static void
doit()
{
  if (setjmp(buff) == 0) {
    doitall(argc, argv);
  } else {
    gc_printf("Done, returning to cedarboot.\n");
  }
}

exit(val)
{
    longjmp(buff, 1);
}
