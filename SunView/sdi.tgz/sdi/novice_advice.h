		"    Novice Advice\n\n\
Left button targets interceptor missile.\n\
Middle button lays down rocks.\n\
Right button initiates 'pop up' x-ray laser.\n\
Missiles which move up off the launch screen\n\
  later reappear moving down on the city screen.\n\
Stop missiles on the launch screen, and with lasers, for more points."
