#include <stdio.h>

forker()
{
  printf("forking.\n"); fflush(stdout);
  if (fork() == 0)
    {exit(0);}
}

main(argc,argv)
char **argv;
{
do_with_delay(forker, 10, 0);
doitall(argc,argv);
}
