"use strict";

// PieTargetEntity.js
// By Don Hopkins (dhopkins@donhopkins.com)
//
// Distributed under the Apache License, Version 2.0.
// See the accompanying file LICENSE or http://www.apache.org/licenses/LICENSE-2.0.html
//
// userData: { "grabbableKey": { "grabbable": true } }


(print("PieTargetEntity: loaded"), function() {

    print("PieTargetEntity: called");

    var _this;

    PieTargetEntity = function() {
        _this = this;
    };

    PieTargetEntity.prototype = {

        preload: function(entityID) {
            _this.entityID = entityID;
            _this.hand = null;
        },

        setHand: function(hand) {
            this.hand = hand;
            print("setHand", hand);
        },

        startFarTrigger: function() {
            this.startPie({
                "type": "trigger",
                "distance": "far",
                "hand": _this.hand,
                "handPosition": (_this.hand == "left" ? MyAvatar.getLeftPalmPosition() : MyAvatar.getRightPalmPosition())
            });
        },

        startNearTrigger: function() {
            this.startPie({
                "type": "trigger",
                "distance": "near",
                "hand": _this.hand,
                "handPosition": (_this.hand == "left" ? MyAvatar.getLeftPalmPosition() : MyAvatar.getRightPalmPosition())
            });
        },

        mousePressOnEntity: function(entityID, mouseEvent) {
            this.startPie({
                "type": "mouse",
                "mouseEvent": mouseEvent
            });
        },

        startPie: function(trackParams) {
            //print("PieTargetEntity: mousePressOnEntity entityID", this.entityID, "trackParams", JSON.stringify(trackParams));

            var channelName = "PieChef-" + MyAvatar.sessionUUID;
            var entity = Entities.getEntityProperties(this.entityID, ["userData"]);
            var userData = entity["userData"];
            var data = JSON.parse(userData);
            var pieID = data['pieID'];
            var pieParams = data['pieParams'];

            var message = {
                'type': 'Show',
                'entityID': this.entityID,
                'pieID': pieID,
                'pieParams': pieParams,
                'trackParams': trackParams
            };
            print("PieTargetEntity: mousePressOnEntity channelName", channelName, "message", JSON.stringify(message));

            Messages.sendMessage(
                channelName, JSON.stringify(message));
        }

    };

    return new PieTargetEntity();

})
