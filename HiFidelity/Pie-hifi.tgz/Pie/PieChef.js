"use strict";

// PieChef.js
// By Don Hopkins (dhopkins@donhopkins.com)
//
// Distributed under the Apache License, Version 2.0.
// See the accompanying file LICENSE or http://www.apache.org/licenses/LICENSE-2.0.html
//

(function() {

    var webPageURL = "PieChefPage.html"; // URL of tablet web page.
    var lastWebPageURL = ""; // Last random URL of tablet web page.
    var buttonName = "PIE CHEF"; // Tablet button label.
    var onPiePage = false; // True when voting web page is opened.
    var webHandlerConnected = false; // True when the web handler has been connected.
    var channelName = "PieChef"; // Unique name for channel that we listen to.
    var deg2rad = Math.PI / 180.0;
    var rad2deg = 1.0 / deg2rad;
    var tablet = Tablet.getTablet("com.highfidelity.interface.tablet.system"); // The awesome tablet.
    var itemDistanceBase = 0.12;
    var itemDistanceStep = 0.08;
    var itemTextColor = {red: 255, green: 255, blue: 255};
    var itemTextBackgroundColor = {red: 0, green: 0, blue: 0};
    var pieLineColor = {red: 255, green: 255, blue: 0};
    var pieLineWidth = 4;
    var currentPieData = null;
    var popupDistance = 0.5;
    var lineDistance = 0.25;
    var pies = {
        'compass': {
            "id": "compass",
            "title": "Compass",
            "slices": [
                {
                    "direction": 0,
                    "subtend": 45,
                    "items": [
                        {
                            "label": "This is the North label. It has a lot of words in it. The text should be broken to fit the maximum width of the label.",
                            "action": {
                                "message": "You picked North."
                            }
                        }
                    ]
                },
                {
                    "direction": 45,
                    "subtend": 45,
                    "items": [
                        {
                            "label": "NorthEast",
                            "action": {
                                "message": "You picked NorthEast."
                            }
                        }
                    ]
                },
                {
                    "direction": 90,
                    "subtend": 45,
                    "items": [
                        {
                            "label": "East",
                            "action": {
                                "message": "You picked East."
                            }
                        }
                    ]
                },
                {
                    "direction": 135,
                    "subtend": 45,
                    "items": [
                        {
                            "label": "SouthEast",
                            "action": {
                                "message": "You picked SouthEast."
                            }
                        }
                    ]
                },
                {
                    "direction": 180,
                    "subtend": 45,
                    "items": [
                        {
                            "label": "South",
                            "action": {
                                "message": "You picked South."
                            }
                        }
                    ]
                },
                {
                    "direction": 225,
                    "subtend": 45,
                    "items": [
                        {
                            "label": "SouthWest",
                            "action": {
                                "message": "You picked SouthWest."
                            }
                        }
                    ]
                },
                {
                    "direction": 270,
                    "subtend": 45,
                    "items": [
                        {
                            "label": "West",
                            "action": {
                                "message": "You picked West."
                            }
                        }
                    ]
                },
                {
                    "direction": 315,
                    "subtend": 45,
                    "items": [
                        {
                            "label": "NorthWest",
                            "action": {
                                "message": "You picked NorthWest."
                            }
                        }
                    ]
                }
            ]
        }
    };

    Messages.messageReceived.connect(function (channel, message, senderID) {

        // Ignore messages to any other channel than mine.
        if (channel != channelName) {
            return;
        }

        print("Messages.messageReceived", "channel", channel, "message", message, "senderID", senderID);

        // Parse the message and pull out the message parameters.
        var messageData = JSON.parse(message);
        var messageType = messageData.type;

        switch (messageType) {

            case 'Show':
                var pie = messageData.pie || pies[messageData.pieID];
                showPie(messageData.entityID, pie, messageData.pieParams, messageData.trackParams);
                break;

            default:
                print("messageReceived: unknown message type: " + messageType + " message: " + message);
                break;

        }

    });

    function showPie(entityID, pie, pieParams, trackParams) {
        print("showPie", "entityID", entityID, "pie", pie, "pieParams", JSON.stringify(pieParams), "trackParams", JSON.stringify(trackParams));

        if (pie == null) {
            return;
        }

        cancelCurrentPie();

        var slicesData = [];
        var entity = Entities.getEntityProperties(entityID, ["position"]);
        var targetPosition = entity["position"];
        var myPosition = MyAvatar.getDefaultEyePosition();
        var orientation = Quat.lookAtSimple(targetPosition, myPosition);
        var orientationBack = Quat.lookAtSimple(myPosition, targetPosition);
        var initialPosition = Vec3.sum(myPosition, Vec3.multiply(Quat.getFront(orientationBack), popupDistance));
        var linePosition = Vec3.sum(myPosition, Vec3.multiply(Quat.getFront(orientationBack), lineDistance));

        print("showPie: initialPosition: " + JSON.stringify(initialPosition) + " MyAvatar.position: " + JSON.stringify(MyAvatar.position) + " offset: " + JSON.stringify(Vec3.subtract(initialPosition, MyAvatar.position)) + " orientation: " + JSON.stringify(orientation));

        var lineID =
            Overlays.addOverlay(
                "line3d", {
                    start: linePosition,
                    end: initialPosition,
                    color: pieLineColor,
                    lineWidth: pieLineWidth,
                    drawInFront: true,
                    ignoreRayIntersection: true,
                    parentID: MyAvatar.sessionUUID,
                    parentJointIndex: MyAvatar.getJointIndex("Head")
                });

        var sphereID =
            Overlays.addOverlay(
                "sphere", {
                    position: initialPosition,
                    color: pieLineColor,
                    size: 0.02,
                    alpha: 1.0,
                    solid: true,
                    drawInFront: true,
                    ignoreRayIntersection: true,
                    parentID: MyAvatar.sessionUUID,
                    parentJointIndex: MyAvatar.getJointIndex("Head")
                });

        currentPieData = {
            pie: pie,
            sliceIndex: -1,
            itemIndex: -1,
            position: initialPosition,
            orientation: orientation,
            slicesData: slicesData,
            lineID: lineID,
            sphereID: sphereID
        };

        for (var i = 0, n = pie.slices.length; i < n; i++) {
            (function(i) {

                var slice = pie.slices[i];
                var items = slice.items;
                var direction = slice.direction;
                var itemsData = [];

                var sliceData = {
                    slice: slice,
                    index: i,
                    direction: direction,
                    itemsData: itemsData
                };
                slicesData.push(sliceData);

                for (var j = 0, m = items.length; j < m; j++) {
                    (function(j) {

                        var item = items[j];
                        var label = item.label;
                        var distance = itemDistanceBase + (itemDistanceStep * j);

                        var offset = {
                            x: Math.sin(direction * deg2rad) * distance,
                            y: Math.cos(direction * deg2rad) * distance,
                            z: 0.0
                        };
                        var rotatedOffset = Vec3.multiplyQbyV(orientation, offset);
                        var position = Vec3.sum(initialPosition, rotatedOffset);

                        print("offset", JSON.stringify(offset), "rotatedOffset", JSON.stringify(rotatedOffset), "position", JSON.stringify(position));

                        
                        var maxWidth = 0.1;
                        var thickness = 0.01;
                        var lineHeight = 0.01;
                        var margin = 0.0;
                        var dimensions = {
                            x: maxWidth, // max width for measuring text.
                            y: 100.0, // very tall for measuring text.
                            z: thickness
                        };

                        var textID =
                            Overlays.addOverlay(
                                "text3d", {
                                    text: label,
                                    lineHeight: lineHeight,
                                    leftMargin: margin,
                                    topMargin: margin,
                                    rightMargin: margin,
                                    bottomMargin: margin,
                                    color: itemTextColor,
                                    backgroundColor: itemTextBackgroundColor,
                                    dimensions: dimensions,
                                    position: position,
                                    rotation: orientationBack,
                                    isFacingAvatar: false,
                                    drawInFront: true,
                                    ignoreRayIntersection: true
                                });

                        var textSize =
                            Overlays.textSizeWrap(textID, label, maxWidth);

                        print("label", label, "textSize", textSize.width, textSize.height);

                        Overlays.editOverlay(
                            textID, {
                                dimensions: {
                                    x: margin + textSize.width + margin,
                                    y: margin + textSize.height + margin,
                                    z: thickness
                                }
                            });

                        var itemData = {
                            item: item,
                            index: j,
                            direction: direction,
                            distance: distance,
                            label: label,
                            position: position,
                            textID: textID
                        };

                        print("made itemData: " + JSON.stringify(itemData));

                        itemsData.push(itemData);

                    })(j);
                }

            })(i);
        }

    }

    function cancelCurrentPie()
    {
        if (currentPieData == null) {
            return;
        }

        var slicesData = currentPieData.slicesData;

        for (var i = 0, n = slicesData.length; i < n; i++) {
            var sliceData = slicesData[i];
            var itemsData = sliceData.itemsData;

            for (var j = 0, m = itemsData.length; j < m; j++) {
                var itemData = itemsData[j];

                try {
                    Overlays.deleteOverlay(itemData.textID);
                } catch (e) {}

            }

        }

        try {
            Overlays.deleteOverlay(currentPieData.lineID);
        } catch (e) {}

        try {
            Overlays.deleteOverlay(currentPieData.sphereID);
        } catch (e) {}

        currentPieData = null;
    }

    function loadFromUserData(entityID) {
        var props = null;
        try {
            props = Entities.getEntityProperties(entityID, ["userData"]);
        } catch (e) {}
        if (!props) {
            return null;
        }

        var userData = props.userData;
        if ((userData == null) || (userData == "")) {
            return null;
        }

        var data = null;
        try {
            data = JSON.parse(userData);
        } catch (e) {
            print("loadFromUserData error parsing userData: " + userData);
        }

        return data;
    }

    function saveToUserData(entityID, data) {
        var userData = JSON.stringify(data);
        try {
            Entities.editEntity(
                entityID, {
                    userData: userData
                });
        } catch (e) {
            print("saveToUserData error saving userData: ", userData);
            return;
        }
        print("saveToUserData saved userData length: ", userData.length);
    }

    function onTabletButtonClicked() {
        showTabletWebPage();
    }

    function showTabletWebPage() {
        lastWebPageURL = Script.resolvePath(webPageURL + '?rand=' + Math.random());
        onPiePage = true;
        tablet.gotoWebScreen(lastWebPageURL);
        // Connect immediately so we don't miss anything.
        connectWebHandler();
    }

    function updatePiePage() {
        if (!onPiePage) {
            return;
        }

        var event = JSON.stringify({
            type: "Update",
            pies: pies
        });

        print("updatePiePage emitScriptEvent event.length:", event.length);

        tablet.emitScriptEvent(event);
    }

    function getAvatarRelativePosition(distance, height) {
        var direction = Quat.getFront(MyAvatar.orientation);
        var position = Vec3.sum(MyAvatar.position, Vec3.multiply(direction, distance));
        position.y += height;
        return position;
    }

    function createPieTarget() {
        var pieTarget = Entities.addEntity({
            type: "Sphere",
            name: "PieTarget",
            position: getAvatarRelativePosition(1.0, 0.5),
            dimensions: {x: 0.5, y: 0.5, z: 0.5},
            color: {red: 0, green: 255, blue: 0},
            script: Script.resolvePath("PieTargetEntity.js"),
            userData: JSON.stringify({
                grabbableKey: { grabbable: true },
                pieID: 'compass',
                pieParams: {}
            })
        });
    }

    // create a new pie.
    function createPie(pieID, data) {
        pies[pieID] = data;
        data.id = pieID;
        updatePiePage();
    }

    function editPie(pieID, data) {
        var pie = pies[pieID];
        if (!pie) {
            pie = {
                id: pieID
            };
            pies[pieID] = pie;
        }

        for (var key in data) {
            pie[key] = data[key];
        }

        updatePiePage();
    }

    function deletePie(pieID) {
        delete pies[pieID];
        updatePiePage();
    }

    function onWebEventReceived(event) {
        if (!onPiePage) {
            return;
        }

        print("Received web event: " + event);

        var eventData = JSON.parse(event);
        var eventType = eventData.type;

        switch (eventType) {
            case 'Ready':
                updatePiePage();
                break;
            case 'Update':
                updatePiePage();
                break;
            case 'CreatePieTarget':
                createPieTarget();
                break;
            case 'CreatePie':
                createPie(eventData.pieID, eventData.data);
                break;
            case 'EditPie':
                editPie(eventData.pieID, eventData.data);
                break;
            case 'DeletePie':
                deletePie(eventData.entityID);
                break;
            default:
                print("onWebEventReceived unexpected eventType", eventType);
                break;
        }
    }

    function onScreenChanged(type, url) {
        print("onScreenChanged", "type", type, "url", url, "lastWebPageURL", lastWebPageURL);
    
        if ((type === "Web") && 
            (url === lastWebPageURL)) {
            if (!onPiePage) {
                onPiePage = true;
                connectWebHandler();
            }
        } else { 
            if (onPiePage) {
                onPiePage = false;
                disconnectWebHandler();
            }
        }

    }

    function onTabletButtonDestroyed() {

        cancelCurrentPie();

        if (onPiePage) {
            disconnectWebHandler();
            tablet.gotoHomeScreen();
            onPiePage = false;
        }

        // Clean up the tablet button we made.
        tabletButton.clicked.disconnect(onTabletButtonClicked);
        tablet.removeButton(tabletButton);

        print("Removed pie chef button from tablet.");
    }

    function connectWebHandler() {
        if (!webHandlerConnected) {
            try {
                tablet.webEventReceived.connect(onWebEventReceived);
            } catch (e) {
                print("connectWebHandler error connecting: " + e);
                return;
            }
            webHandlerConnected = true;
            print("connectWebHandler connected");
            updatePiePage();
        }
    }

    function disconnectWebHandler() {
        if (webHandlerConnected) {
            try {
                tablet.webEventReceived.disconnect(onWebEventReceived);
            } catch (e) {
                print("disconnectWebHandler error disconnecting: " + e);
                return;
            }
            webHandlerConnected = false;
            print("disconnectWebHandler disconnected");
        }
    }

    // Create our tablet button and arrange to create a voting box 
    // when it's clicked, repond to messages from the tablet web page,
    // and to clean up when it's deleted.

    var tabletButton = tablet.addButton({
        icon: "icons/tablet-icons/menu-i.svg",
        activeIcon: "icons/tablet-icons/menu-a.svg",
        text: buttonName,
        sortOrder: 0
    });

    tabletButton.clicked.connect(onTabletButtonClicked);

    tablet.screenChanged.connect(onScreenChanged);

    Script.scriptEnding.connect(onTabletButtonDestroyed);

    print("Added pie chef button to tablet.");

    // Set up the channel name a little bit later,
    // because MyAvatar.sessionUUID is null upon startup!
    Script.setTimeout(function() {
        channelName += "-" + MyAvatar.sessionUUID;
        print("Subscribing to channelName " + channelName);
        Messages.subscribe(channelName);
    }, 1000);

}());
