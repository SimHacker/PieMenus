using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;

[AddComponentMenu("Code snippet")]
[ExecuteInEditMode]
public class TCCodeSnippet : MonoBehaviour 
{
#if UNITY_EDITOR
    public string[] CodeString;

    Component helperComp;
    bool compilled;
    bool prevPlay = false;

    TCCodeSnippetManager settings;

    string uidString
    {
        get
        {
            int uid = GetInstanceID();
            if (uid < 0)
                return "1" + Mathf.Abs(uid).ToString();
            else
                return uid.ToString();
        }
    }

    string AssetPath(string name)
    {
        return Path.GetDirectoryName(AssetDatabase.GetAssetPath(MonoScript.FromMonoBehaviour(this))) + "/Snippets/" + name + (settings.language == TCCodeSnippetManager.Lang.CSharp ? ".cs" : ".js");
    }

    string AssetPathSwitch(string name)
    {
        return Path.GetDirectoryName(AssetDatabase.GetAssetPath(MonoScript.FromMonoBehaviour(this))) + "/Snippets/" + name + (settings.language == TCCodeSnippetManager.Lang.CSharp ? ".js" : ".cs");
    }

    string FilePath(string name)
    {
        return Application.dataPath.Replace("Assets", "") + AssetPath(name);
    }

    public string code;
    public string helperCompName = null;
    public string lastCode;
    public string lastFile;


    public string lastHelperCompName;

    public bool dirty
    {
        get
        {
            if (code != lastCode || helperCompName != lastHelperCompName || lastFile != FilePath(helperCompName))
                return true;

            return false;
        }
    }

    public bool needsCompile
    {
        get
        {   
            if (CodeIsEmpty())
                return false;

            if (File.Exists(FilePath(helperCompName)) && !dirty )
                return false;

            return true;
        }
    }

    bool StringEmpty(string str)
    {
		if (str == null)
			return true;
		
        return string.IsNullOrEmpty(str.Replace("\n", "").Replace("\r", ""));
    }

    public bool CodeIsEmpty()
    {
        return StringEmpty(code) && StringEmpty(lastCode);
    }

    string FormatCode()
    {
        string result = code;

        if (settings.language == TCCodeSnippetManager.Lang.CSharp)
        {
            string[] lines = result.Split('\n');
            result = "";

            foreach (string line in lines)
            {
                result += "\t" + line + "\n";
            }
        }

        result = result.Trim('\n', '\r', '\t', ' ');

        return result;
    }

    void Awake()
    {
        if (helperCompName == null)
            helperCompName = "TCSnippet" + gameObject.name + uidString; 
    }

    void OnEnable()
    {
        settings = GetSettings();

        System.Type t = TCType.Get(helperCompName);

        if (t != null)
        {
            helperComp = GetComponent(t);
            ManageComp();

            if (File.Exists(FilePath(helperCompName)))
            {
                code = ExtractCode(File.ReadAllText(FilePath(helperCompName)));
                lastCode = code;
            }
        }
        EditorApplication.playmodeStateChanged += PlaymodeCallback;
    }

    public void PlaymodeCallback()
    {
        if (needsCompile)
            BuildCode();
    }


    string ExtractCode(string input)
    {
        string output = input;

        output = output.Replace("\t", "");


        if (settings.language == TCCodeSnippetManager.Lang.CSharp)
        {
            int ind = output.IndexOf("{") + 1;
            output = output.Substring(ind, output.Length - ind - 1);
        }
        else
        {
            output = output.Replace("#pragma strict", "");
        }

        output = output.Trim('\n', '\r', '\t', ' ');

        return output;
    }


    void ManageComp()
    {
        if (helperComp == null)
        {
            System.Type t = TCType.Get(helperCompName);

            if (t != null && GetComponent(t) == null)
                gameObject.AddComponent(helperCompName);

            EditorUtility.SetDirty(this);
        }
    }

    void Update()
    {
        ManageComp();
    }


    void CleanUpHelperCompChanged()
    {
        if (File.Exists(FilePath(lastHelperCompName)))
        {
            AssetDatabase.DeleteAsset(AssetPath(lastHelperCompName));
        }
    }
    void CleanUpFileChanged()
    {
        if (File.Exists(lastFile))
        {
            DestroyImmediate(GetComponent(helperCompName));
            AssetDatabase.DeleteAsset(AssetPathSwitch(helperCompName));
        }
    }

    public TCCodeSnippetManager GetSettings()
    {
        string path = Directory.GetParent(Path.GetDirectoryName(AssetDatabase.GetAssetPath(MonoScript.FromMonoBehaviour(this)))) +"/settings.asset";

        TCCodeSnippetManager manager = (TCCodeSnippetManager)AssetDatabase.LoadAssetAtPath(path, typeof(TCCodeSnippetManager));

        if (manager == null)
        {
            manager = (TCCodeSnippetManager)ScriptableObject.CreateInstance(typeof(TCCodeSnippetManager));
            AssetDatabase.CreateAsset(manager, path);
        }

        return manager;
    }

    public void BuildCode()
    {
        if (helperCompName != lastHelperCompName )
            CleanUpHelperCompChanged();

        if (FilePath(helperCompName) != lastFile)
            CleanUpFileChanged();

        lastCode = code;
        lastHelperCompName = helperCompName;
        lastFile = FilePath(lastHelperCompName);

        string writeString;
        if (settings.language == TCCodeSnippetManager.Lang.CSharp)
        {
            writeString = @"
using UnityEngine;
using System.Collections;

public class " + helperCompName + @" : MonoBehaviour
{
";
            writeString += FormatCode();
            writeString += @"
}";
        }
        else
        {
            writeString = @"
#pragma strict
";
            writeString += @"
";
            writeString += FormatCode();
        }

        File.WriteAllText(FilePath(helperCompName), writeString);
        AssetDatabase.ImportAsset(AssetPath(helperCompName));
    }
#endif
}
