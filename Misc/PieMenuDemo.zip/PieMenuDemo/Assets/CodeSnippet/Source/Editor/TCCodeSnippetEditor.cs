using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(TCCodeSnippet))]
[CanEditMultipleObjects]
public class TCCodeSnippetEditor : Editor{

    TCCodeSnippet codeSnippet;
    SerializedProperty code;
    SerializedProperty helperCompName;
    SerializedProperty functionName;
    TCCodeSnippetManager settings;


    bool quickOpen;
    bool prevFocus;
    int pos = 0;

    string quickAddFunction = "";


    void TextArea(SerializedProperty p)
    {
        EditorGUI.BeginProperty(GUILayoutUtility.GetRect(16.0f, 1.0f), new GUIContent(""), p);
        EditorGUI.BeginChangeCheck();

        GUI.SetNextControlName("TextArea");
        string newValue = EditorGUILayout.TextArea(p.stringValue, GUILayout.MinHeight(50.0f));

        if (Event.current.keyCode == KeyCode.Tab)
            Event.current.Use();

        if (EditorGUI.EndChangeCheck())
            code.stringValue = newValue;

        EditorGUI.EndProperty();

        Event.current.GetTypeForControl(GUIUtility.GetControlID(FocusType.Keyboard));
    }


    void AddFunction(string name, string arg = "", string argType = "")
    {
        string add = "";
        bool caps = false;

        foreach (char c in name)
        {
            switch (c)
            {
                case '!':
                case '@':
                case '#':
                case '$':
                case '%':
                case '^':
                case '&':
                case '*':
                case '(':
                case ')':
                case '+':
                    break;

                case ' ':
                    caps = true;
                    break;

                default:
                    add += caps ? char.ToUpper(c) : c;
                    caps = false;
                    break;
            }
        }

        if (!codeSnippet.CodeIsEmpty())
            code.stringValue += @"

";
        if (settings.language == TCCodeSnippetManager.Lang.CSharp)
            code.stringValue += @"void " + add + "(" + argType + " " + arg + @")
{

}";
        else
            code.stringValue += "function " + add + "(" + arg + (arg != ""? " : " : "") + argType + @")
{

}";
    }

    void AddButton(string add, string arg = "", string argType = "")
    {
        GUI.SetNextControlName("FocusFix");
        if (GUILayout.Button(add, "OL Plus", GUILayout.MinWidth(80.0f)))
        {
            AddFunction(add, arg, argType);
            GUI.FocusControl("FocusFix");
        }
    }

    string FocusableTextField(string currentTextIn, string label, string defaultText, string fieldName)
    {
        GUI.SetNextControlName(fieldName);

        GUILayout.BeginHorizontal();
        GUILayout.Label(label);
        string currentTextOut = GUILayout.TextField(currentTextIn, GUILayout.Width(150.0f));
        GUILayout.EndHorizontal();

        if (GUI.GetNameOfFocusedControl() == fieldName && currentTextOut == defaultText && Event.current.type == EventType.repaint)
            currentTextOut = "";
        else if (GUI.GetNameOfFocusedControl() != fieldName && currentTextOut == "" && Event.current.type == EventType.repaint)
            currentTextOut = defaultText;

        return currentTextOut;
    }


    override public void OnInspectorGUI()
    {
        serializedObject.Update();

        if (Selection.GetTransforms(SelectionMode.Unfiltered).Length == 1)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("Component name");

            EditorGUI.BeginProperty(GUILayoutUtility.GetRect(16.0f, 1.0f), new GUIContent(""), helperCompName);
            EditorGUI.BeginChangeCheck();

            GUI.SetNextControlName("nameField");
            string newValue = EditorGUILayout.TextField(helperCompName.stringValue);

            if (EditorGUI.EndChangeCheck())
                helperCompName.stringValue = newValue;

            EditorGUI.EndProperty();

            if (GUI.GetNameOfFocusedControl() != "nameField" && codeSnippet.helperCompName != codeSnippet.lastHelperCompName && Event.current.type == EventType.Repaint)
                DestroyImmediate(codeSnippet.gameObject.GetComponent(codeSnippet.lastHelperCompName));

            GUILayout.EndHorizontal();
        }

        TextArea(code);

        if (!code.hasMultipleDifferentValues)
        {
            if (settings.showQuickFunctionField)
            {
                quickAddFunction = FocusableTextField(quickAddFunction, "Quick add", "Press enter to add function", "quickFunc");

                bool focus = GUI.GetNameOfFocusedControl() == "quickFunc";

                if (focus)
                {
                    if (Event.current.keyCode == KeyCode.Return && Event.current.type == EventType.used)
                    {
                        AddFunction(quickAddFunction);
                        quickAddFunction = "";
                    }
                }
            }


            if (settings.showFrequentFunctionsField)
            {
                GUILayout.BeginVertical("Box");


                quickOpen = EditorGUILayout.Foldout(quickOpen, new GUIContent("Frequent functions"));

                if (quickOpen)
                {

                    AddButton("OnEnable", "");
                    AddButton("Update");
                    AddButton("OnDisable", "");

                    GUILayout.Space(20.0f);

                    GUILayout.BeginHorizontal();

                    GUILayout.BeginVertical(GUILayout.Width(145.0f));
                    AddButton("OnCollisionEnter", "Collision collision");
                    AddButton("OnCollisionStay", "Collision collision");
                    AddButton("OnCollisionExit", "Collision collision");
                    GUILayout.EndVertical();

                    GUILayout.BeginVertical(GUILayout.Width(145.0f));
                    AddButton("OnTriggerEnter", "Collider other");
                    AddButton("OnTriggerStay", "Collider other");
                    AddButton("OnTriggerExit", "Collider other");
                    GUILayout.EndVertical();
                    GUILayout.EndHorizontal();

                    GUILayout.Space(20.0f);

                    GUILayout.BeginHorizontal();

                    GUILayout.BeginVertical(GUILayout.Width(145.0f));
                    AddButton("OnMouseEnter");
                    AddButton("OnMouseOver");
                    AddButton("OnMouseExit");
                    GUILayout.EndVertical();

                    GUILayout.BeginVertical(GUILayout.Width(145.0f));
                    AddButton("OnMouseDown");
                    AddButton("OnMouseDrag");
                    AddButton("OnMouseUp");
                    GUILayout.EndVertical();
                    GUILayout.EndHorizontal();
                }

                GUILayout.EndVertical();
            }
        }

        serializedObject.ApplyModifiedProperties();

        if (codeSnippet.needsCompile)
        {
            GUILayout.BeginHorizontal();

            Color old = GUI.color;

            GUI.color = new Color(1.0f, 1.0f, 1.0f, 0.6f);
            GUILayout.Label("Snippet will update later, or");
            GUI.color = old;

            if (GUILayout.Button("Update now"))
                codeSnippet.BuildCode();

            GUILayout.EndHorizontal();

        }
    }


    void OnDisable()
    {
        if (codeSnippet.needsCompile)
            codeSnippet.BuildCode();
    }

    void OnEnable()
    {
        codeSnippet = target as TCCodeSnippet;

        code = serializedObject.FindProperty("code");
        functionName = serializedObject.FindProperty("functionName");
        helperCompName= serializedObject.FindProperty("helperCompName");

        if (codeSnippet.needsCompile)
            codeSnippet.BuildCode();


        settings = codeSnippet.GetSettings();
    }
}
