using UnityEngine;
using System.Collections;

public class TCCodeSnippetManager : ScriptableObject
{
    public enum Lang
    {
        CSharp, 
        Javascript
    }

    public Lang language = Lang.CSharp;
    public bool showQuickFunctionField = true;
    public bool showFrequentFunctionsField = true;
}
