Thank you for purchasing Code Snippet

Usage

Using code snippet is easy. After downloading and importing the items, you will find a new item in the 'Component' drop down called Code Snippet.
Use that to add a snippet to the currently selected GameObject.

The editor has 4 fields:
-The first let's you set the name of the snippet. It defaults to a unique, but somewhat scrambled, name
-The second field is where you can code!
-The third field let's you specify a name for a function. When you press enter, it will add a function to your code with that name (Eg: void MyFunctionName(){})
-The fourth dropdown let's you add frequently used functions

Changin language

IMPORTANT: By default Code Snippet will produce a C# script. If you want to make a javascript file, open the CodeSnippet folder, and look for a file called settings. Select it, and choose javascript as language in the inspector

Additional settings

You can turn off the quick function field, and the frequent functions field. They are on by default.