////////////////////////////////////////////////////////////////////////
// PieMenuBakery.cs
// By Don Hopkins (dhopkins@DonHopkins.com)
//
// Copyright 2012 Don Hopkins.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


////////////////////////////////////////////////////////////////////////


using UnityEngine;
using UnityEditor;
using System;
using System.Collections;
using System.Collections.Generic;


////////////////////////////////////////////////////////////////////////


public class PieMenuBakery : EditorWindow {


    public bool pieMenusOpened = true;


    [MenuItem("PieMenu/Bakery")]
    static void Init()
    {
        EditorWindow window =
            EditorWindow.GetWindowWithRect(
                typeof(PieMenuBakery), 
                new Rect(100.0f, 100.0f, 400.0f, 00));
        window.Show();
    }


    public void OnGUI()
    {
		EditorGUIUtility.LookLikeControls(150.0f);

        PieMenuRoot root =
            PieMenuRoot.GetRoot();

        root.GetCamera();

        List<string> pieMenuKeys =
            root.GetPieMenuKeys();
        int pieMenuCount =
            pieMenuKeys.Count;

        string pieMenusOpenedLabel =
            (pieMenuCount == 1) ? "1 Pie Menu" : (pieMenuCount + " Pie Menus");
        pieMenusOpened =
            EditorGUILayout.Foldout(pieMenusOpened, pieMenusOpenedLabel);
        if (pieMenusOpened) {

            pieMenuKeys.Sort();

            EditorGUI.indentLevel = 3;

            foreach (string key in pieMenuKeys) {
                PieMenu pieMenu =
                   root.FindPieMenu(key);

               string title;

               if (pieMenu == null) {
                   title = "(missing)";
               } else {
                   title = pieMenu.title;
               }

                EditorGUILayout.LabelField(
                    key, 
                    title);

            }

            EditorGUI.indentLevel = 1;
        }
        
    }


};


////////////////////////////////////////////////////////////////////////
