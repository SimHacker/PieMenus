////////////////////////////////////////////////////////////////////////
// PieMenuRootEditor.cs
// By Don Hopkins (dhopkins@DonHopkins.com)
//
// Copyright 2012 Don Hopkins.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


////////////////////////////////////////////////////////////////////////


using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;


////////////////////////////////////////////////////////////////////////


[CustomEditor(typeof(PieMenuRoot))]
public class PieMenuRootEditor : Editor {


    private bool objectOpened = false;
    private bool animationOpened = false;
    private bool cameraOpened = false;
    private bool textOpened = false;
    private bool defaultPropertiesOpened = false;


    public override void OnInspectorGUI()
    {
        bool changed = false;
        PieMenuRoot root = (PieMenuRoot)target;

        EditorGUI.indentLevel = 1;


        string[] commandLabels = new string[] {
            "Pick a command:", 
            "Layout all pie menu game objects.",
            "Update all pie menus from game objects.",
            "Load JSON properties from PieMenuRoot.txt.",
            "Save JSON properties to PieMenuRoot.txt.",
        };

        int commandIndex =
            EditorGUILayout.Popup(
                "Command",
                0,
                commandLabels);
        switch (commandIndex) {
            case 1:
                LayoutAllGameObjects(root);
                break;
            case 2:
                UpdateAllFromGameObjects(root);
                break;
            case 3:
                root.LoadJSONProperties();
                break;
            case 4:
                root.SaveJSONProperties();
                break;
        }

        root.guiSkin = 
            (GUISkin)EditorGUILayout.ObjectField(
                "GUI Skin",
                root.guiSkin, 
                typeof(GUISkin),
                false);

        objectOpened =
            EditorGUILayout.Foldout(objectOpened, "Object Properties");
        if (objectOpened) {
            EditorGUI.indentLevel = 3;
        
            root.objectLayer =
                EditorGUILayout.LayerField(
                    "Layer",
                    root.objectLayer);

            root.objectDistance =
                EditorGUILayout.FloatField(
                    "Distance",
                    root.objectDistance);

            root.itemObjectDistance =
                EditorGUILayout.FloatField(
                    "Item Distance",
                    root.itemObjectDistance);

            root.itemObjectSelectedDistance =
                EditorGUILayout.FloatField(
                    "Item Selected Distance",
                    root.itemObjectSelectedDistance);

            root.itemObjectScale =
                EditorGUILayout.FloatField(
                    "Item Scale",
                    root.itemObjectScale);

            EditorGUI.indentLevel = 1;
        }

        animationOpened =
            EditorGUILayout.Foldout(animationOpened, "Animation Properties");
        if (animationOpened) {
            EditorGUI.indentLevel = 3;
        
            root.animationMaxMoveSpeed =
                EditorGUILayout.FloatField(
                    "Max Move Speed",
                    root.animationMaxMoveSpeed);

            root.animationMaxMoveTime =
                EditorGUILayout.FloatField(
                    "Max Move Time",
                    root.animationMaxMoveTime);

            root.animationMinDistance =
                EditorGUILayout.FloatField(
                    "Min Distance",
                    root.animationMinDistance);

            EditorGUI.indentLevel = 1;
        }

        cameraOpened =
            EditorGUILayout.Foldout(cameraOpened, "Camera Properties");
        if (cameraOpened) {
            EditorGUI.indentLevel = 3;

            root.cameraSize =
                EditorGUILayout.FloatField(
                    "Size",
                    root.cameraSize);

            root.itemObjectCameraScale =
                EditorGUILayout.FloatField(
                    "Item Scale",
                    root.itemObjectCameraScale);

            root.editorScale =
                EditorGUILayout.FloatField(
                    "Editor Scale",
                    root.editorScale);

            root.screenScale =
                EditorGUILayout.FloatField(
                    "Screen Scale",
                    root.screenScale);

            root.cameraDepth =
                EditorGUILayout.FloatField(
                    "Depth",
                    root.cameraDepth);

            root.cameraNearClipPlane =
                EditorGUILayout.FloatField(
                    "Near Clip Plane",
                    root.cameraNearClipPlane);

            root.cameraFarClipPlane =
                EditorGUILayout.FloatField(
                    "Far Clip Plane",
                    root.cameraFarClipPlane);

            EditorGUI.indentLevel = 1;
        }

        textOpened =
            EditorGUILayout.Foldout(textOpened, "Text Properties");
        if (textOpened) {
            EditorGUI.indentLevel = 3;

            root.textBackgroundColor =
                EditorGUILayout.ColorField(
                    "Text Background Color",
                    root.textBackgroundColor);

            root.textBackgroundLeftRightMargin =
                EditorGUILayout.FloatField(
                    "Text Background Left Right Margin",
                    root.textBackgroundLeftRightMargin);

            root.textBackgroundTopBottomMargin =
                EditorGUILayout.FloatField(
                    "Text Background Top Bottom Margin",
                    root.textBackgroundTopBottomMargin);

            FontAndColorsField(
                "Title",
                ref root.titleFont,
                ref root.titleTopColor,
                ref root.titleUpperLeftColor,
                ref root.titleLowerRightColor);

            OffsetField(
                "Title",
                ref root.titleOffsetX,
                ref root.titleOffsetY);

            FontAndColorsField(
                "Description",
                ref root.descriptionFont,
                ref root.descriptionTopColor,
                ref root.descriptionUpperLeftColor,
                ref root.descriptionLowerRightColor);

            OffsetField(
                "Description",
                ref root.descriptionOffsetX,
                ref root.descriptionOffsetY);

            FontAndColorsField(
                "Item Title",
                ref root.itemTitleFont,
                ref root.itemTitleTopColor,
                ref root.itemTitleUpperLeftColor,
                ref root.itemTitleLowerRightColor);

            FontAndColorsField(
                "Item Title Disabled",
                ref root.itemTitleDisabledFont,
                ref root.itemTitleDisabledTopColor,
                ref root.itemTitleDisabledUpperLeftColor,
                ref root.itemTitleDisabledLowerRightColor);

            OffsetField(
                "Item Title",
                ref root.itemTitleOffsetX,
                ref root.itemTitleOffsetY);

            FontAndColorsField(
                "Item Description",
                ref root.itemDescriptionFont,
                ref root.itemDescriptionTopColor,
                ref root.itemDescriptionUpperLeftColor,
                ref root.itemDescriptionLowerRightColor);

            FontAndColorsField(
                "Item Description Disabled",
                ref root.itemDescriptionDisabledFont,
                ref root.itemDescriptionDisabledTopColor,
                ref root.itemDescriptionDisabledUpperLeftColor,
                ref root.itemDescriptionDisabledLowerRightColor);

            OffsetField(
                "Item Description",
                ref root.itemDescriptionOffsetX,
                ref root.itemDescriptionOffsetY);

            EditorGUI.indentLevel = 1;
        }

        defaultPropertiesOpened =
            EditorGUILayout.Foldout(defaultPropertiesOpened, "Default Properties");
        if (defaultPropertiesOpened) {
            EditorGUI.indentLevel = 3;

            DrawDefaultInspector();

            EditorGUI.indentLevel = 1;
        }

        if (changed || GUI.changed) {
            EditorUtility.SetDirty(target);
        }

    }


    public void FontAndColorsField(string title, ref Font font, ref Color topColor, ref Color upperLeftColor, ref Color lowerRightColor)
    {

        font = 
            (Font)EditorGUILayout.ObjectField(
                title + " Font",
                font,
                typeof(Font),
                false);

        topColor =
            EditorGUILayout.ColorField(
                title + " Top Color",
                topColor);

        upperLeftColor =
            EditorGUILayout.ColorField(
                title + " Upper Left Color",
                upperLeftColor);

        lowerRightColor =
            EditorGUILayout.ColorField(
                title + " Lower Right Color",
                lowerRightColor);

    }


    public void OffsetField(string title, ref float offsetX, ref float offsetY)
    {

        offsetX =
            EditorGUILayout.FloatField(
                title + " Offset X",
                offsetX);

        offsetY =
            EditorGUILayout.FloatField(
                title + " Offset Y",
                offsetY);

    }


    public void OnSceneGUI()
    {
        PieMenuRoot root =
            (PieMenuRoot)target;

        PieMenuRootEditor.HandlePieMenuRootSceneGUI(
            root,
            null,
            null,
            null,
            null);
    }


    public static void HandlePieMenuRootSceneGUI(PieMenuRoot selectedRoot, PieMenu selectedPieMenu, PieMenuCenter selectedCenter, PieMenuSlice selectedSlice, PieMenuItem selectedItem)
    {
        foreach (Transform childTransform in selectedRoot.gameObject.transform) {
            PieMenu pieMenu =
                childTransform.gameObject.GetComponent<PieMenu>();
            if (pieMenu != null) {
                PieMenuEditor.HandlePieMenuSceneGUI(
                    pieMenu,
                    selectedPieMenu,
                    selectedCenter,
                    selectedSlice,
                    selectedItem);
            }
        }

    }


    public void LayoutAllGameObjects(PieMenuRoot root)
    {
        foreach (Transform childTransform in root.gameObject.transform) {
            PieMenu pieMenu =
                childTransform.gameObject.GetComponent<PieMenu>();
            if (pieMenu != null) {
                pieMenu.LayoutGameObjects();
            }
        }
    }


    public void UpdateAllFromGameObjects(PieMenuRoot root)
    {
        foreach (Transform childTransform in root.gameObject.transform) {
            PieMenu pieMenu =
                childTransform.gameObject.GetComponent<PieMenu>();
            if (pieMenu != null) {
                pieMenu.UpdateFromGameObjects();
            }
        }
    }


};


////////////////////////////////////////////////////////////////////////
