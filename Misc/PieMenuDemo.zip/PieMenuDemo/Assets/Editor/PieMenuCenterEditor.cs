////////////////////////////////////////////////////////////////////////
// PieMenuCenterEditor.cs
// By Don Hopkins (dhopkins@DonHopkins.com)
//
// Copyright 2012 Don Hopkins.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


////////////////////////////////////////////////////////////////////////


using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;


////////////////////////////////////////////////////////////////////////


[CustomEditor(typeof(PieMenuCenter))]
public class PieMenuCenterEditor : Editor {


    private bool defaultPropertiesOpened = false;


    public override void OnInspectorGUI()
    {
        bool changed = false;
        PieMenuCenter center =
            (PieMenuCenter)target;

        EditorGUI.indentLevel = 1;

        defaultPropertiesOpened =
            EditorGUILayout.Foldout(defaultPropertiesOpened, "Default Properties");

        if (defaultPropertiesOpened) {

            EditorGUI.indentLevel = 3;
            DrawDefaultInspector();
            EditorGUI.indentLevel = 1;

        }

    }


    public void OnSceneGUI()
    {
        PieMenuCenter center = 
            (PieMenuCenter)target;
        PieMenu pieMenu =
            center.GetPieMenu();
        PieMenuRoot root =
            pieMenu.GetRoot();

        PieMenuRootEditor.HandlePieMenuRootSceneGUI(
            root,
            pieMenu,
            center,
            null,
            null);
    }


    public static void HandlePieMenuCenterSceneGUI(PieMenuCenter center, PieMenuCenter selectedCenter)
    {
        PieMenu pieMenu =
            center.GetPieMenu();
        PieMenuRoot root =
            pieMenu.GetRoot();

        if (center == selectedCenter) {
            Handles.color =
                new Color(1.0f, 0.0f, 0.0f, 0.25f);

            Handles.DrawSolidDisc(
                center.gameObject.transform.position,
                center.gameObject.transform.up,
                pieMenu.inactiveRadius * root.editorScale);
        } else {
            Handles.color =
                Color.white;

            Handles.DrawWireDisc(
                center.gameObject.transform.position,
                center.gameObject.transform.up,
                pieMenu.inactiveRadius * root.editorScale);
        }

    }


};


////////////////////////////////////////////////////////////////////////
