////////////////////////////////////////////////////////////////////////
// PieMenuItemEditor.cs
// By Don Hopkins (dhopkins@DonHopkins.com)
//
// Copyright 2012 Don Hopkins.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


////////////////////////////////////////////////////////////////////////


using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;


////////////////////////////////////////////////////////////////////////


[CustomEditor(typeof(PieMenuItem))]
public class PieMenuItemEditor : Editor {


    private bool defaultPropertiesOpened = false;


    public static void InspectItem(
        PieMenuItem item,
        int indentLevel,
        PieMenuItemEditor itemEditor,
        ref bool changedRef,
        ref bool defaultPropertiesOpenedRef,
        ref int fromIndex,
        ref int toIndex)
    {
        if (item == null) {
            EditorGUILayout.LabelField(
                "Item", 
                "(null)");
            return;
        }

        PieMenuSlice slice =
            item.GetSlice();
        PieMenu pieMenu =
            slice.GetPieMenu();

        pieMenu.Layout();

        EditorGUI.indentLevel = indentLevel;

        int itemCount =
            slice.CountItems();
        int visibleItemCount =
            slice.CountVisibleItems();

        string label =
            "" + item.index;

        if (item.hidden) {

            label += " (Hidden)";

        }

        EditorGUILayout.LabelField(
            "Item", 
            label);

        string[] indexLabels = 
            new string[itemCount];
        for (int i = 0; i < itemCount; i++) {
            indexLabels[i] = "Index " + i;
        }

        if (itemCount > 1) {
            int newIndex =
                EditorGUILayout.Popup(
                    "Index",
                    item.index,
                    indexLabels);
            if (newIndex != item.index) {
                fromIndex = item.index;
                toIndex = newIndex;
            }
        }

        item.title =
            EditorGUILayout.TextField(
                "Title",
                ((item.title == null)
                    ? ""
                    : item.title));

        item.description =
            EditorGUILayout.TextField(
                "Description",
                ((item.description == null)
                    ? ""
                    : item.description));

        item.id =
            EditorGUILayout.TextField(
                "ID",
                ((item.id == null)
                    ? ""
                    : item.id));

        item.texture = 
            (Texture)EditorGUILayout.ObjectField(
                "Texture",
                item.texture, 
                typeof(Texture),
                false);

        item.subMenu =
            EditorGUILayout.TextField(
                "Sub-Menu",
                ((item.subMenu == null)
                    ? ""
                    : item.subMenu));

        item.hidden = 
            EditorGUILayout.Toggle(
                "Hidden", 
                item.hidden);

        item.disabled = 
            EditorGUILayout.Toggle(
                "Disabled", 
                item.disabled);

        item.disabledReason =
            EditorGUILayout.TextField(
                "Disabled Reason",
                ((item.disabledReason == null)
                    ? ""
                    : item.disabledReason));

        item.subMenuCenter =
            EditorGUILayout.Toggle(
                "Sub-Menu Center",
                item.subMenuCenter);

        if (itemEditor != null) {

            defaultPropertiesOpenedRef =
                EditorGUILayout.Foldout(defaultPropertiesOpenedRef, "Default Properties");

            if (defaultPropertiesOpenedRef) {

                EditorGUI.indentLevel = indentLevel + 2;
                itemEditor.DrawDefaultInspector();
                EditorGUI.indentLevel = indentLevel;

            }

        }

    }


    public override void OnInspectorGUI()
    {
        PieMenuItem item =
            (PieMenuItem)target;
        PieMenuSlice slice =
            item.GetSlice();
        bool changed = 
            false;

        int fromIndex = -1;
        int toIndex = -1;

        PieMenuItemEditor.InspectItem(
            item,
            1,
            this,
            ref changed,
            ref defaultPropertiesOpened,
            ref fromIndex,
            ref toIndex);

        if ((slice != null) && (fromIndex != -1)) {
            slice.ChangeItemIndex(fromIndex, toIndex);
        }

        if (changed || GUI.changed) {
            EditorUtility.SetDirty(target);
        }

    }


    public void OnSceneGUI()
    {
        PieMenuItem item = 
            (PieMenuItem)target;
        PieMenuSlice slice =
            item.GetSlice();
        PieMenu pieMenu =
            slice.GetPieMenu();
        PieMenuRoot root =
            pieMenu.GetRoot();

        PieMenuRootEditor.HandlePieMenuRootSceneGUI(
            root,
            pieMenu,
            null,
            slice, 
            item);
    }


    public static void HandlePieMenuItemSceneGUI(PieMenuItem item, PieMenuItem selectedItem)
    {
        Handles.color =
            (item == selectedItem)
                ? Color.red
                : Color.white;

        Handles.Disc(
            item.gameObject.transform.rotation,
            item.gameObject.transform.position,
            item.gameObject.transform.up,
            1.0f,
            false,
            1.0f);

        if (item == selectedItem) {
            string label = "";
            if ((item.title != null) && (item.title != "")) {
                label += item.title;
            }
            if ((item.description != null) && (item.description != "")) {
                if (label != "") {
                    label += "\n\n";
                }
                label += item.description.Replace("\\n", "\n");
            }
            if (label != "") {
                Handles.Label(
                    item.gameObject.transform.position,
                    label);
            }
        }

    }


};


////////////////////////////////////////////////////////////////////////
