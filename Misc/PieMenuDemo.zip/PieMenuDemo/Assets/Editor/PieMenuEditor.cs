////////////////////////////////////////////////////////////////////////
// PieMenuEditor.cs
// By Don Hopkins (dhopkins@DonHopkins.com)
//
// Copyright 2012 Don Hopkins.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


////////////////////////////////////////////////////////////////////////


using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;


////////////////////////////////////////////////////////////////////////


[CustomEditor(typeof(PieMenu))]
public class PieMenuEditor : Editor {

    private bool slicesOpened = false;
    private bool defaultPropertiesOpened = false;
    private bool[] itemsOpened;


    public override void OnInspectorGUI()
    {
        bool changed = false;
        PieMenu pieMenu =
            (PieMenu)target;

        EditorGUI.indentLevel = 1;

        string[] commandLabels = new string[] {
            "Pick a command:", 
            "Layout pie menu game objects.",
            "Update pie menu from game objects.",
        };

        int commandIndex =
            EditorGUILayout.Popup(
                "Command",
                0,
                commandLabels);
        switch (commandIndex) {
            case 1:
                pieMenu.LayoutGameObjects();
                break;
            case 2:
                pieMenu.UpdateFromGameObjects();
                break;
        }

        pieMenu.title =
            EditorGUILayout.TextField(
                "Title",
                ((pieMenu.title == null)
                    ? ""
                    : pieMenu.title));

        pieMenu.description =
            EditorGUILayout.TextField(
                "Description",
                ((pieMenu.description == null)
                    ? ""
                    : pieMenu.description));

        pieMenu.centerTexture = 
            (Texture)EditorGUILayout.ObjectField(
                "Center Texture",
                pieMenu.centerTexture, 
                typeof(Texture),
                false);

       pieMenu.centerTextureSize =
            Mathf.Max(
                0.0f,
                EditorGUILayout.FloatField(
                    "Center Texture Size",
                    pieMenu.centerTextureSize));

        pieMenu.defaultItemTexture = 
            (Texture)EditorGUILayout.ObjectField(
                "Default Item Texture",
                pieMenu.defaultItemTexture, 
                typeof(Texture),
                false);

        pieMenu.objectScale =
            Mathf.Max(
                0.0f,
                EditorGUILayout.FloatField(
                    "Object Scale",
                    pieMenu.objectScale));

        pieMenu.center = 
            (PieMenuCenter)EditorGUILayout.ObjectField(
                "Center",
                pieMenu.center, 
                typeof(PieMenuCenter),
                true);

        pieMenu.centerScale =
            Mathf.Max(
                0.0f,
                EditorGUILayout.FloatField(
                    "Center Scale",
                    pieMenu.centerScale));

        pieMenu.radius =
            Mathf.Max(
                0.0f,
                EditorGUILayout.FloatField(
                    "Radius", 
                    pieMenu.radius));

        pieMenu.inactiveRadius =
            Mathf.Max(
                0.0f,
                EditorGUILayout.FloatField(
                    "Inactive Radius", 
                    pieMenu.inactiveRadius));

        pieMenu.clockwise = 
            EditorGUILayout.Toggle(
                "Clockwise", 
                pieMenu.clockwise);

        pieMenu.initialAngle =
            Mathf.Max(
                0.0f,
                Mathf.Min(
                    360.0f,
                    EditorGUILayout.FloatField(
                        "Initial Angle (deg)", 
                        pieMenu.initialAngle)));

        pieMenu.itemLabelJustification =
            (PieMenu.ItemLabelJustification)EditorGUILayout.EnumPopup(
                "Item Label Justification",
                pieMenu.itemLabelJustification);

        pieMenu.itemLabelExtraRadius =
            EditorGUILayout.FloatField(
                "Item Label Extra Radius", 
                pieMenu.itemLabelExtraRadius);

        int sliceCount = 
            pieMenu.CountSlices();
        int newSliceCount = 
            Mathf.Max(
                0,
                EditorGUILayout.IntField(
                    "Slice Count", 
                    sliceCount));

        if (newSliceCount != sliceCount) {

            if (sliceCount < newSliceCount) {

                for (int i = sliceCount; i < newSliceCount; i++) {
                    PieMenuSlice slice =
                        pieMenu.CreateSlice(null);
                }

            } else {

                for (int i = sliceCount - 1; i >= newSliceCount; i--) {
                    PieMenuSlice slice =
                        pieMenu.GetSlice(i);
                    pieMenu.DestroySlice(
                        slice, true);
                }

            }

            //Debug.Log("CHANGING SLICE COUNT FROM " + sliceCount + " to " + newSliceCount);
            pieMenu.UpdateFromGameObjects();
            pieMenu.LayoutGameObjects();
            sliceCount = newSliceCount;
            changed = true;
        }

        string sliceCountLabel =
            sliceCount + ((sliceCount == 1) ? " Slice" : " Slices");

        int initialDeg =
            (int)Mathf.Floor(
                0.5f +
                (PieMenu.radToDeg *
                 PieMenu.NormalizeAngle(
                     pieMenu.initialAngle * 
                     PieMenu.degToRad)));

        switch (sliceCount) {

            case 2:
                sliceCountLabel += " (Switch)";
                break;

            case 4: 
                if ((initialDeg % 90) == 0) {
                    sliceCountLabel += " (Plus)";
                } else if ((initialDeg % 45) == 0) {
                    sliceCountLabel += " (Cross)";
                }
                break;

            case 8:
                if ((initialDeg % 45) == 0) {
                    sliceCountLabel += " (Compass)";
                }
                break;

            case 12:
                if ((initialDeg % 30) == 0) {
                    sliceCountLabel += " (Clock)";
                }
                break;
        }

        slicesOpened =
            EditorGUILayout.Foldout(
                slicesOpened,
                sliceCountLabel);

        if (slicesOpened) {

            EditorGUI.indentLevel = 3;

            float angle =
                pieMenu.initialAngle * ((2.0f * Mathf.PI) / 360.0f);
            float turn =
                (sliceCount == 0)
                    ? 0.0f
                    : ((2.0f * Mathf.PI) / (float)sliceCount);

            if (pieMenu.clockwise) {
                turn = -turn;
            }
            
            if (sliceCount == 0) {

                EditorGUILayout.LabelField(
                    "Slice", 
                    "(no slices)");

            } else {

                int fromIndex = -1;
                int toIndex = -1;

                if (itemsOpened == null) {
                    itemsOpened = new bool[sliceCount];
                } else if (itemsOpened.Length != sliceCount) {
                    bool[] newItemsOpened = new bool[sliceCount];
                    int n =
                        (int)Mathf.Min(itemsOpened.Length, newItemsOpened.Length);
                    for (int i = 0; i < n; i++) {
                        newItemsOpened[i] = itemsOpened[i];
                    }
                    itemsOpened = newItemsOpened;
                }

                for (int i = 0; i < sliceCount; i++) {

                    PieMenuSlice slice =
                        pieMenu.GetSlice(i);

                    bool dummy = false;

                    PieMenuSliceEditor.InspectSlice(
                        slice,
                        3,
                        null,
                        ref itemsOpened[i],
                        ref changed,
                        ref dummy,
                        ref fromIndex,
                        ref toIndex);

                    EditorGUILayout.Space();

                }

                if (fromIndex != -1) {
                    pieMenu.ChangeSliceIndex(
                        fromIndex,
                        toIndex);
                    pieMenu.LayoutGameObjects();

                }
            }

            EditorGUI.indentLevel = 1;

        }

        defaultPropertiesOpened =
            EditorGUILayout.Foldout(defaultPropertiesOpened, "Default Properties");

        if (defaultPropertiesOpened) {

            EditorGUI.indentLevel = 3;
            DrawDefaultInspector();
            EditorGUI.indentLevel = 1;

        }

        if (changed || GUI.changed) {
            EditorUtility.SetDirty(target);
        }

    }


    public void OnSceneGUI()
    {
        PieMenu pieMenu = 
            (PieMenu)target;
        PieMenuRoot root =
            pieMenu.GetRoot();

        PieMenuRootEditor.HandlePieMenuRootSceneGUI(
            root,
            pieMenu,
            null,
            null, 
            null);
    }


    public static void HandlePieMenuSceneGUI(PieMenu pieMenu, PieMenu selectedPieMenu, PieMenuCenter selectedCenter, PieMenuSlice selectedSlice, PieMenuItem selectedItem)
    {
        PieMenuRoot root =
            pieMenu.GetRoot();

        Handles.color =
            (pieMenu == selectedPieMenu)
                ? Color.red
                : Color.white;

        Handles.DrawWireDisc(
            pieMenu.gameObject.transform.position,
            pieMenu.gameObject.transform.up,
            pieMenu.radius * root.editorScale);

        Handles.DrawWireDisc(
            pieMenu.gameObject.transform.position,
            pieMenu.gameObject.transform.up,
            pieMenu.inactiveRadius * root.editorScale);

        if (pieMenu == selectedPieMenu) {

            if (pieMenu.center != null) {
                PieMenuCenterEditor.HandlePieMenuCenterSceneGUI(
                    pieMenu.center,
                    selectedCenter);
            }

            string label = "";
            if ((pieMenu.title != null) && (pieMenu.title != "")) {
                label += pieMenu.title;
            }
            if ((pieMenu.description != null) && (pieMenu.description != "")) {
                if (label != "") {
                    label += "\n\n";
                }
                label += pieMenu.description.Replace("\\n", "\n");
            }
            if (label != "") {
                Handles.Label(
                    pieMenu.gameObject.transform.position,
                    label);
            }

            foreach (Transform childTransform in pieMenu.gameObject.transform) {
                PieMenuSlice slice =
                    childTransform.gameObject.GetComponent<PieMenuSlice>();
                if (slice != null) {
                    PieMenuSliceEditor.HandlePieMenuSliceSceneGUI(
                       slice,
                       selectedCenter,
                       selectedSlice,
                       selectedItem);
                }
            }

        } else {
            string label = "";
            if ((pieMenu.title != null) && (pieMenu.title != "")) {
                label += pieMenu.title;
            }
            if (label != "") {
                Handles.Label(
                    pieMenu.gameObject.transform.position,
                    label);
            }

        }

    }


};


////////////////////////////////////////////////////////////////////////
