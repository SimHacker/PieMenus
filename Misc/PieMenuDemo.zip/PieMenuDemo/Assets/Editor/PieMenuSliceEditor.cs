////////////////////////////////////////////////////////////////////////
// PieMenuSliceEditor.cs
// By Don Hopkins (dhopkins@DonHopkins.com)
//
// Copyright 2012 Don Hopkins.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


////////////////////////////////////////////////////////////////////////


using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;


////////////////////////////////////////////////////////////////////////


[CustomEditor(typeof(PieMenuSlice))]
public class PieMenuSliceEditor : Editor {


    private bool itemsOpened = false;
    private bool defaultPropertiesOpened = false;


    public static void InspectSlice(
        PieMenuSlice slice,
        int indentLevel,
        PieMenuSliceEditor sliceEditor,
        ref bool itemsOpenedRef,
        ref bool changedRef,
        ref bool defaultPropertiesOpenedRef,
        ref int fromIndex,
        ref int toIndex)
    {
        bool changed = false;

        PieMenu pieMenu =
            slice.GetPieMenu();

        pieMenu.Layout();

        EditorGUI.indentLevel = indentLevel;

        int sliceCount =
            pieMenu.CountSlices();

        string label =
            "" + slice.sliceIndex + ":";

        label +=
            "(" + 
            PieMenu.DirectionName(slice.angle, sliceCount) + 
            ")";

        EditorGUILayout.LabelField(
            "Slice", 
            label);

        string[] indexLabels = 
            new string[sliceCount];
        for (int i = 0; i < sliceCount; i++) {
            indexLabels[i] = "Index " + i;
        }

        if (sliceCount == 1) {
            EditorGUILayout.LabelField(
                "Index", 
                "0");
        } else {
            int newIndex =
                EditorGUILayout.Popup(
                    "Index",
                    slice.sliceIndex,
                    indexLabels);
            if (newIndex != slice.sliceIndex) {
                fromIndex = slice.sliceIndex;
                toIndex = newIndex;
            }
        }

        slice.id =
            EditorGUILayout.TextField(
                "ID",
                ((slice.id == null)
                    ? ""
                    : slice.id));

        slice.distancePerItem =
            EditorGUILayout.FloatField(
                "Distance Per Item",
                slice.distancePerItem);

        int itemCount = 
            slice.CountItems();
        int newItemCount = 
            Mathf.Max(
                0,
                EditorGUILayout.IntField(
                    "Item Count", 
                    itemCount));

        if (newItemCount != itemCount) {

            if (itemCount < newItemCount) {

                for (int i = itemCount; i < newItemCount; i++) {
                    PieMenuItem item =
                        slice.CreateItem(null);
                }

            } else {

                for (int i = itemCount - 1; i >= newItemCount; i--) {
                    PieMenuItem item =
                        slice.GetItem(i);
                    slice.DestroyItem(
                        item, true);
                }

            }

            //Debug.Log("CHANGING ITEM COUNT FROM " + itemCount + " to " + newItemCount);
            pieMenu.UpdateVisibleItems();
            slice.LayoutGameObjects();
            itemCount = newItemCount;
            changed = true;
        }

        string itemCountLabel =
            itemCount + ((itemCount == 1) ? " Item" : " Items");

        itemsOpenedRef =
            EditorGUILayout.Foldout(
                itemsOpenedRef,
                itemCountLabel);

        if (itemsOpenedRef) {

            EditorGUI.indentLevel = indentLevel + 2;

            if (itemCount == 0) {

                EditorGUILayout.LabelField(
                    "Item", 
                    "(no items)");

            } else {

                int itemFromIndex = -1;
                int itemToIndex = -1;

                for (int i = 0; i < itemCount; i++) {

                    PieMenuItem item =
                        slice.GetItem(i);

                    bool dummy = false;

                    PieMenuItemEditor.InspectItem(
                        item,
                        indentLevel + 2,
                        null,
                        ref changedRef,
                        ref dummy,
                        ref itemFromIndex,
                        ref itemToIndex);

                    EditorGUILayout.Space();

                }

                if (itemFromIndex != -1) {
                    slice.ChangeItemIndex(
                        fromIndex, 
                        toIndex);
                    slice.LayoutGameObjects();
                }
            }

            EditorGUI.indentLevel = indentLevel;

        }

        if (sliceEditor != null) {

            defaultPropertiesOpenedRef =
                EditorGUILayout.Foldout(defaultPropertiesOpenedRef, "Default Properties");

            if (defaultPropertiesOpenedRef) {

                EditorGUI.indentLevel = indentLevel + 2;
                sliceEditor.DrawDefaultInspector();
                EditorGUI.indentLevel = indentLevel;

            }

        }

    }


    public override void OnInspectorGUI()
    {
        PieMenuSlice slice =
            (PieMenuSlice)target;
        PieMenu pieMenu =
            slice.GetPieMenu();
        bool changed =
            false;

        int fromIndex = -1;
        int toIndex = -1;

        PieMenuSliceEditor.InspectSlice(
            slice,
            1,
            this,
            ref itemsOpened,
            ref changed,
            ref defaultPropertiesOpened,
            ref fromIndex,
            ref toIndex);

        if (fromIndex != -1) {
            pieMenu.ChangeSliceIndex(fromIndex, toIndex);
        }

        if (changed || GUI.changed) {
            EditorUtility.SetDirty(target);
        }

    }


    public void OnSceneGUI()
    {
        PieMenuSlice slice = 
            (PieMenuSlice)target;
        PieMenu pieMenu =
            slice.GetPieMenu();
        PieMenuRoot root =
            pieMenu.GetRoot();

        PieMenuRootEditor.HandlePieMenuRootSceneGUI(
            root,
            pieMenu,
            null,
            slice,
            null);
    }


    public static void HandlePieMenuSliceSceneGUI(PieMenuSlice slice, PieMenuCenter selectedCenter, PieMenuSlice selectedSlice, PieMenuItem selectedItem)
    {
        PieMenu pieMenu =
            slice.GetPieMenu();
        PieMenuRoot root =
            pieMenu.GetRoot();

        Handles.color =
            Color.white;

        float sliceSubtend = 
            (Mathf.PI * 2.0f) / (float)pieMenu.CountSlices();
        float angle0 =
            slice.angle + (sliceSubtend * 0.5f);
        float angle1 =
            slice.angle - (sliceSubtend * 0.5f);

/*
        Vector3 lineStart =
            pieMenu.gameObject.transform.position +
            (pieMenu.gameObject.transform.rotation *
             new Vector3(
                pieMenu.inactiveRadius * Mathf.Cos(angle0) * root.editorScale,
                0.0f,
                pieMenu.inactiveRadius * Mathf.Sin(angle0) * root.editorScale));
        Vector3 lineEnd =
            pieMenu.gameObject.transform.position +
            (pieMenu.gameObject.transform.rotation *
             new Vector3(
                pieMenu.radius * Mathf.Cos(angle0) * root.editorScale,
                0.0f,
                pieMenu.radius * Mathf.Sin(angle0) * root.editorScale));
        Handles.DrawLine(
            lineStart,
            lineEnd);
*/

        float labelRadius =
            (pieMenu.radius + pieMenu.inactiveRadius) * 0.5f;

        Handles.Label(
            pieMenu.gameObject.transform.position +
            (pieMenu.gameObject.transform.rotation *
             new Vector3(
                labelRadius * Mathf.Cos(slice.angle) * root.editorScale,
                0.0f,
                labelRadius * Mathf.Sin(slice.angle) * root.editorScale)),
            PieMenu.DirectionName(slice.angle, pieMenu.CountSlices()));

        if (slice == selectedSlice) {

            Handles.color =
                new Color(1.0f, 0.0f, 0.0f, 0.25f);

            Handles.DrawSolidArc(
                pieMenu.gameObject.transform.position,
                pieMenu.gameObject.transform.up,
                (pieMenu.gameObject.transform.rotation *
                 new Vector3(
                    pieMenu.radius * Mathf.Cos(angle0) * root.editorScale,
                    0.0f,
                    pieMenu.radius * Mathf.Sin(angle0) * root.editorScale)),
                sliceSubtend * PieMenu.radToDeg,
                pieMenu.radius * root.editorScale);

            foreach (Transform childTransform in slice.gameObject.transform) {
                PieMenuItem item =
                    childTransform.gameObject.GetComponent<PieMenuItem>();
                if (item != null) {
                    PieMenuItemEditor.HandlePieMenuItemSceneGUI(
                       item,
                       selectedItem);
                }
            }

        }

    }


};


////////////////////////////////////////////////////////////////////////
