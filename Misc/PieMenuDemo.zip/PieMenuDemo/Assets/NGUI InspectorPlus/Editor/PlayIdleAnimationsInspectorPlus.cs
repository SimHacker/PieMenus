
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(PlayIdleAnimations))]
public class PlayIdleAnimationsInspectorPlus : Editor {public override void OnInspectorGUI (){}
}