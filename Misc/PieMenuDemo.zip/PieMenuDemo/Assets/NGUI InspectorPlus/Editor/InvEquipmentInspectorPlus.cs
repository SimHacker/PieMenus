
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(InvEquipment))]
public class InvEquipmentInspectorPlus : Editor {public override void OnInspectorGUI (){}
}