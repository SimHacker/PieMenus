
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(UIOrthoCamera))]
public class UIOrthoCameraInspectorPlus : Editor {public override void OnInspectorGUI (){}
}