
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(SetColorOnSelection))]
public class SetColorOnSelectionInspectorPlus : Editor {public override void OnInspectorGUI (){}
}