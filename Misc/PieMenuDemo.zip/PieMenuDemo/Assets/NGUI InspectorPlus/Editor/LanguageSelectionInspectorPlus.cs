
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(LanguageSelection))]
public class LanguageSelectionInspectorPlus : Editor {public override void OnInspectorGUI (){}
}