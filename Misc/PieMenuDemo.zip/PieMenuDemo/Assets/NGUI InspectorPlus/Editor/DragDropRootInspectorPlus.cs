
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(DragDropRoot))]
public class DragDropRootInspectorPlus : Editor {public override void OnInspectorGUI (){}
}