
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(NGUIDebug))]
public class NGUIDebugInspectorPlus : Editor {public override void OnInspectorGUI (){}
}