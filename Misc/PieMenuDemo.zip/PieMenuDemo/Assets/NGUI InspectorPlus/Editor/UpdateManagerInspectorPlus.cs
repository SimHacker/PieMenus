
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(UpdateManager))]
public class UpdateManagerInspectorPlus : Editor {public override void OnInspectorGUI (){}
}