
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(UIInput))]
public class UIInputInspectorPlus : Editor {
	SerializedObject so;
	SerializedProperty[] properties;
	new string name;
    int count;  
	Rect tooltipRect;  
	void OnEnable ()
	{
		so = serializedObject;
		count = 9;
		properties = new SerializedProperty[count];
	}
	void ProgressBar (float value, string label)
	{
		GUILayout.Space (3.0f);
		Rect rect = GUILayoutUtility.GetRect (18, 18);
		EditorGUI.ProgressBar (rect, value, label);
		GUILayout.Space (3.0f);
	}

	void PropertyField (SerializedProperty sp, string name)
	{
		if (sp.hasChildren) {
			while (true) {
				if (sp.propertyPath != name && !sp.propertyPath.StartsWith (name + "."))
					break;

				EditorGUI.indentLevel = sp.depth;
				bool child = EditorGUILayout.PropertyField (sp);
				if (!sp.NextVisible (child))
					break;
			}
		} else
			EditorGUILayout.PropertyField (sp);
	}

	void ArrayGUI (SerializedProperty sp, string name)
	{
		EditorGUIUtility.LookLikeControls (120.0f, 40.0f);
		GUILayout.Space (4.0f);
		EditorGUILayout.BeginVertical ("box");

		int i = 0;
		int del = -1;

		SerializedProperty array = sp.Copy ();
		SerializedProperty size = null;
		bool first = true;

		while (true) {
			if (sp.propertyPath != name && !sp.propertyPath.StartsWith (name + "."))
				break;

			bool child;
			EditorGUI.indentLevel = sp.depth;

			if (sp.depth == 1 && !first) {
				EditorGUILayout.BeginHorizontal ();

				if (GUILayout.Button ("-", GUILayout.Width (24.0f)))
					del = i;

				//GUILayout.Label (" + i);
				child = EditorGUILayout.PropertyField (sp);

				GUI.enabled = i > 0;

				if (GUILayout.Button ("U", GUILayout.Width (24.0f), GUILayout.Height(18.0f)))
					array.MoveArrayElement (i - 1, i);

				GUI.enabled = i < array.arraySize - 1;
                if (GUILayout.Button("D", GUILayout.Width(24.0f), GUILayout.Height(18.0f)))
					array.MoveArrayElement (i + 1, i);

				++i;

				GUI.enabled = true;
				EditorGUILayout.EndHorizontal ();
			} else if (sp.depth == 1) {
				first = false;
				size = sp.Copy ();

				EditorGUILayout.BeginHorizontal ();

				if (!size.hasMultipleDifferentValues && GUILayout.Button ("+", GUILayout.Width (24.0f)))
					array.arraySize += 1;


				child = EditorGUILayout.PropertyField (sp);

				EditorGUILayout.EndHorizontal ();
			} else {
				child = EditorGUILayout.PropertyField (sp);
			}

			if (!sp.NextVisible (child))
				break;
		}

		sp.Reset ();

		if (del != -1)
			array.DeleteArrayElementAtIndex (del);

		if (array.isExpanded && !size.hasMultipleDifferentValues) {
			EditorGUILayout.BeginHorizontal ();

			if (GUILayout.Button ("+", GUILayout.Width (24.0f)))
				array.arraySize += 1;

			GUI.enabled = false;
			EditorGUILayout.PropertyField (array.GetArrayElementAtIndex (array.arraySize - 1), new GUIContent ("" + array.arraySize));
			GUI.enabled = true;

			EditorGUILayout.EndHorizontal ();
		}

		EditorGUI.indentLevel = 0;
		EditorGUILayout.EndVertical ();
		EditorGUIUtility.LookLikeControls (170.0f, 80.0f);
	}

	void RefreshVars()
	{
        properties[0] = so.FindProperty ("label");
        properties[1] = so.FindProperty ("maxChars");
        properties[2] = so.FindProperty ("caratChar");
        properties[3] = so.FindProperty ("validator");
        properties[4] = so.FindProperty ("type");
        properties[5] = so.FindProperty ("isPassword");
        properties[6] = so.FindProperty ("activeColor");
        properties[7] = so.FindProperty ("eventReceiver");
        properties[8] = so.FindProperty ("functionName");
     }

	void Vector2Field(SerializedProperty sp)
	{
        EditorGUI.BeginProperty(GUILayoutUtility.GetLastRect(), new GUIContent(), sp);
		EditorGUI.BeginChangeCheck ();
		var newValue = EditorGUILayout.Vector2Field (sp.name, sp.vector2Value);

		if (EditorGUI.EndChangeCheck ())
			sp.vector2Value = newValue;
		
		EditorGUI.EndProperty ();
	}

	void QuaternionField(SerializedProperty sp)
	{
        EditorGUI.BeginProperty(GUILayoutUtility.GetLastRect(), new GUIContent(), sp);
		
		EditorGUI.BeginChangeCheck ();
		SerializedProperty x = sp.FindPropertyRelative ("x");
		SerializedProperty y = sp.FindPropertyRelative ("y");
		SerializedProperty z = sp.FindPropertyRelative ("z");
		SerializedProperty w = sp.FindPropertyRelative ("w");

		Quaternion q = new Quaternion (x.floatValue, y.floatValue, z.floatValue, w.floatValue);
                   
		var newValue = EditorGUILayout.Vector3Field (name, q.eulerAngles);

		if (EditorGUI.EndChangeCheck ()) {
			Quaternion r = Quaternion.Euler (newValue);
			x.floatValue = r.x;
			y.floatValue = r.y;
			z.floatValue = r.z;
			w.floatValue = r.w;
		}

		EditorGUI.EndProperty ();
	}
	public override void OnInspectorGUI ()
	{
        so.Update();
        RefreshVars();
        SerializedProperty sp;

        EditorGUIUtility.LookLikeControls(135.0f, 50.0f);
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[0]; 
            if (sp != null){
            name = "label";PropertyField(sp, name);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Text label modified by this input."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[1]; 
            if (sp != null){
            name = "maxChars";sp.intValue = Mathf.Max (0, sp.intValue);EditorGUILayout.PropertyField(sp);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Maximum number of characters allowed before input no longer works."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[2]; 
            if (sp != null){
            name = "caratChar";PropertyField(sp, name);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Visual carat character appended to the end of the text when typing."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[3]; 
            if (sp != null){
            name = "validator";PropertyField(sp, name);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Delegate used for validation."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[4]; 
            if (sp != null){
            name = "type";PropertyField(sp, name);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Type of the touch screen keyboard used on iOS and Android devices."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[5]; 
            if (sp != null){
            name = "isPassword";PropertyField(sp, name);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Whether this input field should hide its text."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[6]; 
            if (sp != null){
            name = "activeColor";PropertyField(sp, name);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Color of the label when the input field has focus."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[7]; 
            if (sp != null){
            name = "eventReceiver";PropertyField(sp, name);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Event receiver that will be notified when the input field submits its data (enter gets pressed)."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
                    {
                    GUILayout.BeginHorizontal();
                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 22.0f;
                    style.fixedHeight = 22.0f;
                    EditorGUI.HelpBox(GUILayoutUtility.GetRect(new GUIContent(), style), "", MessageType.Info);
                    }
            sp = properties[8]; 
            if (sp != null){
            name = "functionName";PropertyField(sp, name);
                    {
                    GUILayout.EndHorizontal();
	                Rect last = GUILayoutUtility.GetLastRect();
	                GUI.Label(last, new GUIContent("","Function that will be called on the event receiver when the input field submits its data."));
					                    GUIStyle style = new GUIStyle();
                    style.fixedWidth = 250.0f;
                    style.wordWrap = true;
					Vector2 size = new GUIStyle().CalcSize(new GUIContent(GUI.tooltip));
					tooltipRect = new Rect(Event.current.mousePosition.x + 4.0f, Event.current.mousePosition.y + 12.0f, 27.0f + size.x, size.y * 1.7f);

                    while (tooltipRect.width > 250.0f)
                    {
                        tooltipRect.width /= 2.0f;
                        tooltipRect.height *= 2.0f;
                    }
                    }}
		if (!string.IsNullOrEmpty(GUI.tooltip))
        {
            GUI.Box(tooltipRect, new GUIContent());
			EditorGUI.HelpBox(tooltipRect, GUI.tooltip, MessageType.Info);
			Repaint();
		}
		
		GUI.tooltip = "";
        //START REMOVE HERE TO REMOVE WATERMARK
        GUILayout.Space(5.0f);
        GUI.color = new Color(1.0f, 1.0f, 1.0f, 0.4f);
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUILayout.Label("Created by");
        GUI.color = new Color(1.0f, 1.0f, 1.0f, 0.7f);
        if (GUILayout.Button("Inspector++", GUILayout.Width(85.0f), GUILayout.Height(15.0f)))
            Application.OpenURL("http://forum.unity3d.com/threads/136727-Inspector-Meh-to-WOW-inspectors");
        GUI.color = new Color(1.0f, 1.0f, 1.0f, 1.0f);
        //END REMOVE HERE FOR WATERMARK
        so.ApplyModifiedProperties(); 
    }
}