
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(IgnoreTimeScale))]
public class IgnoreTimeScaleInspectorPlus : Editor {public override void OnInspectorGUI (){}
}