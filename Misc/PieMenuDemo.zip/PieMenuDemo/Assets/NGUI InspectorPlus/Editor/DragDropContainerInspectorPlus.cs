
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(DragDropContainer))]
public class DragDropContainerInspectorPlus : Editor {public override void OnInspectorGUI (){}
}