
using UnityEngine;
using System.Collections;
using UnityEditor;
using System.Reflection;
using System;
using Object = UnityEngine.Object;

[CanEditMultipleObjects]
[CustomEditor(typeof(ShaderQuality))]
public class ShaderQualityInspectorPlus : Editor {public override void OnInspectorGUI (){}
}