>* introduction
>
>** definition
>
>Pies are circular menus, 
>the selection from which is based on the direction between two points,
>specified by clicking the mouse, 
>stroking the pen, 
 ^^^^^^^^ ^^^ ^^^ this could be put in a less suggestive fashion?
>touching the screen, 
>or waving the hand. 

>A pie menu is centered on the first point, 
>which could be the location of the cursor when the mouse button went down, 
>the beginning of the pen stroke, 
>or whatever location is appropriate for the input device. 
>In the center of the pie, where the cursor starts out, 
>is an inactive region that selects nothing. 

Is this necessarily true?  Seems like there might be other interesting
things to do with the center too.

>The wedge shaped slices of the pie, 
>adjacent to the cursor but in different directions,
>correspond to the menu selections.
>
>** fast and easy
>
>Pies are fast to use, 
>because it takes very little cursor motion to choose a slice, 
>and selecting a direction does not require visual feedback. 
>
>Pies are easy to use,
>because of the wedge shape and large area of the selection regions,
>which extend out to the screen edges.
>As the cursor moves out from the center of the pie, 
>the control over the direction becomes more precise,
>giving you more leverage to make the desired selection.
>
>** two dimensional
>
>Pies offer two dimensions of input, 
>the direction and the distance between the two points, 
>which may be used as parameters to the selection.
>The path traveled between the points does not matter, 
>just the direction and distance between the endpoints of the path.

Again, these are facets of your particular implementation.

>** self revealing gestural user interface
>
>Pies are a self revealing gestural user interface, 
>because without even looking, you can move in any direction, 
>and "click ahead" so fast that the menu doesn't even pop up.  
>Only when used more slowly like a traditional menu, 
>does a pie menu pop up on the screen, 
>to reveal the available selections, 
>and teach you to click ahead. 
>
>By clicking and popping up a pie menu, 
>looking at the labels, 
>moving the cursor in the desired direction, 
>then clicking to make a selection, 
>you learn the menu and practice the gesture to click ahead.
>
>With a little practice, 
>it becomes quite easy to click ahead 
>even through nested pie menus.
>
>* explain why they are so defined
>
>Pie menus may be implemented in many ways, but the essential design goal
>should be to make gestural selection as smooth and reliable as possible,
>given the particular input device.  In particular, this describes how
>pie menus can be made to work well with the mouse; in abstract, pie
>menus can be made to work with many types of input devices such as the
>stylus or touch pad, by adapting the tracking behavior to the
>constraints and features of the particular hardware.
>
>When a pie menu pops up, it is ideally centered at the location of the
>click that invoked it: where the mouse button was pressed, the screen
>was touched, or whatever. The cursor might have moved 
>in the time it took to respond to the click, so simply centering the
>menu on the current cursor position would interfere with click ahead. 
>The center of the pie is inactive, and clicking again in the center
>dismisses the menu without making a selection. 
>
>The slices of the pie are all adjacent to the cursor, each in a
>different direction. This arrangement minimizes the motion required to
>make a selection. As you move the cursor further into the wider area of
>a slice, your directional control becomes more precise.  So the active
>areas of the slices extend out to the edges of the screen, and you can
>move the cursor as far as you want in any direction to select a slice.
>The ability to increase the angular accuracy by moving the cursor as far
>as you need is another property of pie menus that makes reliable click
>ahead possible.
>
>When you pop up a pie menu near the edge of the screen, the menu
>window may have to be moved by a certain offset in order to fit
>completely on the screen, otherwise you couldn't read the menu. But it
>would be quite unexpected were the menu to slip out from under the
>click, leaving the cursor pointing at the wrong slice. So whenever the
>menu is displayed on the screen, and it must be moved in order to fit,
>it is important to "warp" the cursor by the same offset, relative to
>its position at the time the menu is displayed. If a selection is
>made, but the menu is not popped up on the screen due to click ahead
>display premption, the cursor should not be warped. 
>
>* disadvantages and solutions
>
>One disadvantage of pie menus is that the popup window has a large
>area because of the circular layout.  Pie menus with long labels or
>many items can be very large.  Pie menus with an odd number of items
>are less symetric and harder to use. Dynamically changing pie menus
>do not work well with click ahead. 
>
>The layout algorithm should minimize the menu size, prevent the labels
>from overlapping, and clearly associate each label with its respective
>slice. It is not necessary to confine each label to the interior of
>its slice -- that could result in enormous menus. Rotated text is also
>undesirable, since it's jagged, hard to read, and still results in
>large menus. I have implemented a successful layout policy that
>justifies the label edges against the center of the slice, at an inner
>radius big enough that no two adjacent labels overlap. To delimit the
>active areas of the menu, short lines are drawn, like cuts in a pie
>crust, between the slices, from the inactive radius to the label
>radius.
>
>Pie menus with short labels or square icons tend to be smaller and have
>less wasted space, and wider labels can be placed in the top and bottom
>positions.  The fewer and evener the number of items in a pie menu, the
>easier it is to use.  Certain numbers of items are well suited to
>various metaphors.  Dynamically changing pie menus should at least
>always have their first (or default) item in the same direction.  Pie
>menus that do not change, and are thoughtfully designed, can be
>extremely efficient.
>
>One solution to the problem of pie menus with too many items is to
>dissolve large menus into smaller logically related submenus. Nested
>pies work quite well as a gestural interface, because it's possible to
>click ahead through them without visual feedback. If you think of it as
>navagating through rooms in a building or city streets, you just
>remember the directions, and chunk out the selection gestures one after
>the other.
>
>Another way around the problem is the scrolling spiral pie menu, that
>encompasses many items, but only displays a fixed number of them at
>once. By winding the cursor around the menu center, you can scroll
>through all the items, like walking up or down a spiral staircase or
>parking garage. 
>
>* explain their speed and accuracy
>
>Pie menus are faster and have a lower error rate than linear "pull down"
>menu.  According to Fitt's law, the "seek time" required to point the
>cursor at a target depends on the distance to the target and the target
>area.  Since the wedge shaped slices of a pie menu are all quite large
>and very close to the cursor (their active area extends to the edge of
>the screen), Fitt's law predicts good times for pie menus.  But the
>rectangular target areas of a linear menu are very small in comparison,
>and they're each a different distance (but the same direction) from the
>cursor.
>
>
>Callahan's experiment comparing 8 item pies and linear menus
>  Callahan's experiment confirms Fitt's law, by showing ...
>
>Buxton's experiment comparing different sized pie menus and input devices
>  8 and 12 very good. rehersal. trackball bad. mouse good. pen great.
>
>* two dimensions: direction and distance
>  continuous or discrete
>  two dimensional examples: font style/size, color hue/saturation
>
>* metaphor, kinesthetics, and gesture
>
>Idealy, the application designer should arrange the labels and submenus
>in directions that reflect their spatial associations and relationships
>between them, making it easy to remember which direction does what.
>Opposite or complementary items can be places 180 degrees apart, and
>orthogonal pairs 90 degrees apart.
>
>A natural pie menu metaphor is geographical navagation:
>driving around the intersections and streets of a city,
>walking around the halls and rooms of a building, 
>or climbing around the branches and leaves of a tree. 
>
>        items		metaphores
>	-----		----------
>        2		switch confirmation boolean
>        4		box room arrows edges corners
>	6		hex
>	8		compass arrows edges+corners
>	10		decimal
>	12		clock months
>
>  designing kinesthetically pleasing pie menus
>  example: window manager
>
>* implementations and availability
>  in X10 for the uwm window manager
>  in SunView for the SDI game
>  in NeWS for the Lite Toolkit
>  in OpenWindows for The NeWS Toolkit
>  safer than linear menus, probably not patented
>  league for programming freedom
>  take a look and feel free
>
>My first attempt at implementing pie menus was on a Sun 3/160 running
>the X10 window system, adding them to the "uwm" window manager (June
>86), since there was no standard menu package at the time.  The user
>could define nested menus in a ".uwmrc" file, and bind them to mouse
>buttons (possibly modified by shift keys).  The default menu layout
>was specified by an initial angle and a radius, which you could
>override in any menu whose labels overlapped, and the popup window was
>shaped as a rectangle large enough the encompass all the labels, with
>a title at the top.
>
>I then linked this piemenuified window manager code into Mitch
>Bradley's Sun Forth System, to make a Forth extensible window manager.
>I used this interactivly programmable system to experiment with pie
>menu tracking and window management techniques, and to administer and
>collect data for Jack Callahan's experiment comparing pie menus with
>linear menus.
>
>While snowed in at home, Mark Weiser implemented Pie Menus for the
>SunView window system (January 87), and they are featured in his "SDI"
>game, the source code to which is available for free.
>
>NeWS Lite Toolkit (May 87)
>
>The NeWS Toolkit
>
>
>Not only are pie menus quicker and easier than linear pull down menu,
>they are probably even safer to use, because pull down menus are
>patented by Apple Computer (patent #?).  It is entirely possible
>(though not very likely) that the pie menu concept was already been
>patented before 1969 (the earliest reference I could find to the
>concept), and I could be in deep trouble for giving away my own code.
>Earlier implementations of pull down menus at Xerox PARC did not
>prevent Apple from patenting them.
