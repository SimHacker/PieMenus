%%

Subject		return(SUBJECT);
number		return(NUMBER);
name		return(NAME);
Menu		return(MENU);
PP[0-9]		{ yylval.str = yytext+2; return(PP); }
PL[0-9]		{ yylval.str = yytext+2; return(PL); }
PO[0-9]		{ yylval.str = yytext+2; return(PO); }
LP[0-9]		{ yylval.str = yytext+2; return(LP); }
LL[0-9]		{ yylval.str = yytext+2; return(LL); }
LO[0-9]		{ yylval.str = yytext+2; return(LO); }
Choose		return(CHOOSE);
[Tt]ime		return(TIME);
sec		return(SEC);
Selected	return(SELECTED);
No		return(NO);
choice		return(CHOICE);
Total		return(TOTAL);
Test		return(TEST);
completed	return(COMPLETED);
[0-9]+\.[0-9]+	{ yylval.str = yytext; return(REAL); }
[0-9]+		{ yylval.str = yytext; return(NUM); }
[A-Za-z0-9]+	{ yylval.str = yytext; return(STR); }
\n		return('\n');
:		return(':');
\'		return('\'');
\.		return('.');
\[		return('[');
\]		return(']');
[ \t]		;
#		return('#');
=		return('=');
