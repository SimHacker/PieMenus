
# line 2 "cruncher.y"

#include <stdio.h>
#include <ctype.h>

int i,j, cell = 0, cells[6], item = 0, menuRow, menuCol, subjnum, choice;
int summeans = 0, menunum = 0, nerrs = 0, errchoice, errs = 0, tots, err, realchoice,mmeans = 0;
double timecells[6],lasttime;
double mtimecells[6][5];
char *malloc();


# line 16 "cruncher.y"
typedef union 	{
	int ival;
	double dval;
	char *str;
	} YYSTYPE;
# define SUBJECT 257
# define NUMBER 258
# define NAME 259
# define MENU 260
# define PP 261
# define PL 262
# define PO 263
# define LP 264
# define LL 265
# define LO 266
# define CHOOSE 267
# define TIME 268
# define SEC 269
# define SELECTED 270
# define NO 271
# define CHOICE 272
# define TOTAL 273
# define TEST 274
# define COMPLETED 275
# define NUM 276
# define STR 277
# define REAL 278
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern short yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256

# line 184 "cruncher.y"
 /* lex stuff goes here, so ... */

#include "lex.yy.c"
short yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 35
# define YYLAST 245
short yyact[]={

  77,  66,  65,  44,  61,  53,  40,  81,  50,  29,
  18,   7,  47,  86,  83,  21,  22,  23,  24,  25,
  26,  52,  68,  39,  72,  12,  62,  43,   7,  33,
   9,  28,   4,  89,  59,  87,  85,  58,  55,  73,
  56,  49,  37,  31,  16,  69,  30,  41,  60,  71,
  70,  80,  75,  74,  64,  36,  79,  35,  34,  32,
  17,  13,   8,   6,  67,  82,  84,  76,  57,  11,
  42,  51,  54,  20,  46,  38,  19,  14,  27,  15,
   3,  10,   5,   2,   1,   0,   0,   0,   0,   0,
  48,   0,   0,  63,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
  88,   0,  90,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,  78,   0,   0,  45 };
short yypact[]={

-225,-1000,-232,  52,-228,-249,  51,-1000,-1000, -14,
-1000,  50,-265,-1000,-246,-226,-267,-1000,   0, -15,
-1000,-1000,-1000,-1000,-1000,-1000,-1000,  49,-230,-1000,
  48,  47,  45, -16,-1000,-244,-1000,-271,-241, -32,
-1000,-261,-241, -17,-268,-1000,-1000,-247,-1000,-273,
-1000, -23, -18,-1000, -24,   9,-274,-243,   9,  44,
-275,-1000,-248,  -1,-1000,  11,  10,-245, -19,  43,
-1000,-1000,  42, -35,-1000,-1000,  41,-269,-1000,-257,
-1000,-1000, -25,-259, -26,   9, -60,   9,-1000,-1000,
-1000 };
short yypgo[]={

   0,  84,  83,  82,  81,  80,  79,  78,  63,  77,
  76,  75,  47,  74,  73,  72,  34,  71,  70,  68,
  67,  66,  65,  64 };
short yyr1[]={

   0,   1,   6,   2,   5,   7,   3,   3,   9,   8,
  10,  14,  14,  14,  14,  14,  14,  15,  11,  17,
  11,  16,  16,  12,  12,  19,  18,  21,  20,  22,
  20,  20,  23,  13,   4 };
short yyr2[]={

   0,   3,   0,   6,   4,   4,   2,   3,   0,   8,
   1,   1,   1,   1,   1,   1,   1,   0,   8,   0,
   6,   3,   3,   1,   2,   0,   9,   0,   5,   0,
   4,   4,   0,   7,   4 };
short yychk[]={

-1000,  -1,  -2,  -5, 257,  -3,  -8, 260,  10, 258,
  -4,  -8, 274,  10,  -9,  -6,  58,  10, 275, -10,
 -14, 261, 262, 263, 264, 265, 266,  -7, 257, 276,
  46,  58,  10, 259,  10,  10,  10,  58, -11, 267,
 277, -12, -18, 268,  35, 276, -13, 273, -12,  58,
 276, -17, 268, 278, -15,  61,  58, -19,  61, -16,
  39, 278, 269, -16,  10, 277, 276, -23, 270,  46,
  39,  39, 269,  58,  10,  10, -20,  35, 276,  91,
  10, 276, -22, 271, -21,  61, 272,  61, -16,  93,
 -16 };
short yydef[]={

   0,  -2,   0,   0,   0,   0,   0,   8,   2,   0,
   1,   0,   0,   6,   0,   0,   0,   7,   0,   0,
  10,  11,  12,  13,  14,  15,  16,   0,   0,   4,
   0,   0,   0,   0,  34,   0,   3,   0,   0,   0,
   5,   0,  23,   0,   0,  19,   9,   0,  24,   0,
  17,   0,   0,  25,   0,   0,   0,   0,   0,   0,
   0,  32,   0,   0,  20,   0,   0,   0,   0,   0,
  21,  22,   0,   0,  18,  33,   0,   0,  29,   0,
  26,  27,   0,   0,   0,   0,   0,   0,  30,  31,
  28 };
#ifndef lint
static char yaccpar_sccsid[] = "@(#)yaccpar	4.1	(Berkeley)	2/11/83";
#endif not lint

#
# define YYFLAG -1000
# define YYERROR goto yyerrlab
# define YYACCEPT return(0)
# define YYABORT return(1)

/*	parser for yacc output	*/

#ifdef YYDEBUG
int yydebug = 0; /* 1 for debugging */
#endif
YYSTYPE yyv[YYMAXDEPTH]; /* where the values are stored */
int yychar = -1; /* current input token number */
int yynerrs = 0;  /* number of errors */
short yyerrflag = 0;  /* error recovery flag */

yyparse() {

	short yys[YYMAXDEPTH];
	short yyj, yym;
	register YYSTYPE *yypvt;
	register short yystate, *yyps, yyn;
	register YYSTYPE *yypv;
	register short *yyxi;

	yystate = 0;
	yychar = -1;
	yynerrs = 0;
	yyerrflag = 0;
	yyps= &yys[-1];
	yypv= &yyv[-1];

 yystack:    /* put a state and value onto the stack */

#ifdef YYDEBUG
	if( yydebug  ) printf( "state %d, char 0%o\n", yystate, yychar );
#endif
		if( ++yyps> &yys[YYMAXDEPTH] ) { yyerror( "yacc stack overflow" ); return(1); }
		*yyps = yystate;
		++yypv;
		*yypv = yyval;

 yynewstate:

	yyn = yypact[yystate];

	if( yyn<= YYFLAG ) goto yydefault; /* simple state */

	if( yychar<0 ) if( (yychar=yylex())<0 ) yychar=0;
	if( (yyn += yychar)<0 || yyn >= YYLAST ) goto yydefault;

	if( yychk[ yyn=yyact[ yyn ] ] == yychar ){ /* valid shift */
		yychar = -1;
		yyval = yylval;
		yystate = yyn;
		if( yyerrflag > 0 ) --yyerrflag;
		goto yystack;
		}

 yydefault:
	/* default state action */

	if( (yyn=yydef[yystate]) == -2 ) {
		if( yychar<0 ) if( (yychar=yylex())<0 ) yychar = 0;
		/* look through exception table */

		for( yyxi=yyexca; (*yyxi!= (-1)) || (yyxi[1]!=yystate) ; yyxi += 2 ) ; /* VOID */

		while( *(yyxi+=2) >= 0 ){
			if( *yyxi == yychar ) break;
			}
		if( (yyn = yyxi[1]) < 0 ) return(0);   /* accept */
		}

	if( yyn == 0 ){ /* error */
		/* error ... attempt to resume parsing */

		switch( yyerrflag ){

		case 0:   /* brand new error */

			yyerror( "syntax error" );
		yyerrlab:
			++yynerrs;

		case 1:
		case 2: /* incompletely recovered error ... try again */

			yyerrflag = 3;

			/* find a state where "error" is a legal shift action */

			while ( yyps >= yys ) {
			   yyn = yypact[*yyps] + YYERRCODE;
			   if( yyn>= 0 && yyn < YYLAST && yychk[yyact[yyn]] == YYERRCODE ){
			      yystate = yyact[yyn];  /* simulate a shift of "error" */
			      goto yystack;
			      }
			   yyn = yypact[*yyps];

			   /* the current yyps has no shift onn "error", pop stack */

#ifdef YYDEBUG
			   if( yydebug ) printf( "error recovery pops state %d, uncovers %d\n", *yyps, yyps[-1] );
#endif
			   --yyps;
			   --yypv;
			   }

			/* there is no state on the stack with an error shift ... abort */

	yyabort:
			return(1);


		case 3:  /* no shift yet; clobber input char */

#ifdef YYDEBUG
			if( yydebug ) printf( "error recovery discards char %d\n", yychar );
#endif

			if( yychar == 0 ) goto yyabort; /* don't discard EOF, quit */
			yychar = -1;
			goto yynewstate;   /* try again in the same state */

			}

		}

	/* reduction by production yyn */

#ifdef YYDEBUG
		if( yydebug ) printf("reduce %d\n",yyn);
#endif
		yyps -= yyr2[yyn];
		yypvt = yypv;
		yypv -= yyr2[yyn];
		yyval = yypv[1];
		yym=yyn;
			/* consult goto table to find next state */
		yyn = yyr1[yyn];
		yyj = yypgo[yyn] + *yyps + 1;
		if( yyj>=YYLAST || yychk[ yystate = yyact[yyj] ] != -yyn ) yystate = yyact[yypgo[yyn]];
		switch(yym){
			
case 2:
# line 36 "cruncher.y"
{ for(i=0; i < 6;i++) cells[i] = 0; } break;
case 4:
# line 41 "cruncher.y"
{ subjnum = atoi(yypvt[-0].str);
			  fprintf(stderr,
				"processing subject number %d\n",subjnum); } break;
case 8:
# line 53 "cruncher.y"
{ err = 0; } break;
case 11:
# line 61 "cruncher.y"
{ cell = 1; menuRow = 1; menuCol = 1;
				menunum = atoi(yypvt[-0].str); } break;
case 12:
# line 63 "cruncher.y"
{ cell = 2; menuRow = 1; menuCol = 2;
				menunum = atoi(yypvt[-0].str); } break;
case 13:
# line 65 "cruncher.y"
{ cell = 3; menuRow = 1; menuCol = 3;
				menunum = atoi(yypvt[-0].str); } break;
case 14:
# line 67 "cruncher.y"
{ cell = 4; menuRow = 2; menuCol = 1;
				menunum = atoi(yypvt[-0].str); } break;
case 15:
# line 69 "cruncher.y"
{ cell = 5; menuRow = 2; menuCol = 2;
				menunum = atoi(yypvt[-0].str); } break;
case 16:
# line 71 "cruncher.y"
{ cell = 6; menuRow = 2; menuCol = 3;
				menunum = atoi(yypvt[-0].str); } break;
case 17:
# line 76 "cruncher.y"
{ realchoice = atoi(yypvt[-0].str);
			  item++;
			  switch (realchoice) {
				case 1:
				case 2:
				case 3: choice = 1; break;
				case 4:
				case 5: choice = 2; break;
				case 6:
				case 7:
				case 8: choice = 3; break; }} break;
case 19:
# line 89 "cruncher.y"
{ realchoice = atoi(yypvt[-0].str);
			  item++;
			  switch (realchoice) {
				case 1:
				case 2:
				case 3: choice = 1; break;
				case 4:
				case 5: choice = 2; break;
				case 6:
				case 7:
				case 8: choice = 3; break; }} break;
case 25:
# line 112 "cruncher.y"
{ lasttime = atof(yypvt[-0].str); } break;
case 26:
# line 114 "cruncher.y"
{
			  if (errs) {
				if (err) {
				  printf("%d %d %d %d %d %d %d %d %d\n",
						subjnum,menuRow,menuCol,
						choice,menunum,
						errchoice,realchoice,err,
						item);
					err = 0;
				}
			}} break;
case 27:
# line 128 "cruncher.y"
{ errchoice = atoi(yypvt[-0].str);
			  if (errchoice != realchoice) {
				cells[cell-1]++; err++; }} break;
case 29:
# line 133 "cruncher.y"
{ errchoice = atoi(yypvt[-0].str);
			  if (errchoice != realchoice) {
				cells[cell-1]++; err++; }} break;
case 31:
# line 138 "cruncher.y"
{ errchoice = 0;
			  cells[cell-1]++; err++; } break;
case 32:
# line 143 "cruncher.y"
{
				mtimecells[cell-1][menunum-1] += atof(yypvt[-0].str);
				timecells[cell-1] += atof(yypvt[-0].str);
				if (!errs && !nerrs && !summeans && !tots && !mmeans)
				printf("%d %d %d %d %d %s %d %d %d\n",
					subjnum,cell,menuRow,menuCol,
					menunum,yypvt[-0].str,
					choice,realchoice,item);
				if(tots)
				printf("%d %d %d %d %d %f %d %d %d\n",
					subjnum,cell,menuRow,menuCol,
					menunum,lasttime,
					choice,realchoice,item);
			} break;
case 34:
# line 161 "cruncher.y"
{
				if(summeans) {
				  printf("%d ",subjnum);
				  for(i=0;i < 6;i++)
				    printf("%d %f ",i+1,timecells[i]/10);
				  printf("\n");
				} else if(nerrs) {
				  printf("%d ",subjnum);
				  for(i=0;i < 6;i++)
				    printf("%d %d ",i+1,cells[i]);
				  printf("\n");
				} else if(mmeans) {
				  printf("%d",subjnum);
				  for(i=0;i < 6;i++) {
				    for(j=0;j < 5;j++)
				      printf(" %10.4f",mtimecells[i][j]/2);
				    printf("\n");
				  }
				  printf("\n");
				}
			} break;
		}
		goto yystack;  /* stack new state and value */

	}
