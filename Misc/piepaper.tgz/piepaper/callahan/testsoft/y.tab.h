
typedef union 	{
	int ival;
	double dval;
	char *str;
	} YYSTYPE;
extern YYSTYPE yylval;
# define SUBJECT 257
# define NUMBER 258
# define NAME 259
# define MENU 260
# define PP 261
# define PL 262
# define PO 263
# define LP 264
# define LL 265
# define LO 266
# define CHOOSE 267
# define TIME 268
# define SEC 269
# define SELECTED 270
# define NO 271
# define CHOICE 272
# define TOTAL 273
# define TEST 274
# define COMPLETED 275
# define NUM 276
# define STR 277
# define REAL 278
