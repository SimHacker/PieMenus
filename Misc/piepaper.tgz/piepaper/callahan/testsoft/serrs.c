/*
 * number of menus seen vs number of errors
 *
 */

#include <stdio.h>

#define	NUMSEEN 60

int totals[2][NUMSEEN];

main()
{
  int subjnum,choice,menuRow,menuCol,menuNum,errchoice,realchoice,err,item;
  int i,j;

  for(i=0;i < 2;i++) for(j=0;j < NUMSEEN;j++)
    { totals[i][j] = 0; }
  while(fscanf(stdin,"%d %d %d %d %d %d %d %d %d\n",
    &subjnum,&menuRow,&menuCol,&choice,&menuNum,&errchoice,
     &realchoice,&err,&item) != EOF) {
    totals[menuRow-1][item-1] += err;
  }
  for(i=0;i < 2;i++) for(j=0;j < NUMSEEN;j++) {
    fprintf(stdout,"%d\t%d\t%d\n",i+1,j+1,totals[i][j]);
  }
}
