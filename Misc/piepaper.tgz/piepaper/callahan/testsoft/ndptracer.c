#include <stdio.h>

#define	MAXROWS	60
#define MAXCOLUMNS	20
#define NOTHING	'?'
#define SIMPLEA 'A'
#define SECONDA 'A'
#define EAT			'E'
#define	SIMPLER	'R'
#define	SECONDR	'R'
#define	THINK		'T'
#define	MINARG	6
#define	MOBMAX	63
#define MAXCHARS	200
#define MAXLINES	500
#define	TRUE		1
#define FALSE		0

int maxcolumns = 0, maxrows = 0;
char *outarray[MAXROWS][MAXCOLUMNS],sequential = FALSE;

main(argc, argv)
int argc;
char **argv;
{
	int             linenum = 1, i, ftime, lasttime, j, lstate[MOBMAX], ptime, stime, eline, eoline, cflag, tstate, phil, rfork, marcs, rtime, sumonly, start, incr, numofphils, crow = 0, ccolumn = 0;
	int             line[MOBMAX];
	char           *malloc();
	char            tempstr[MAXCHARS], atempstr[MAXCHARS];
	char           *larry[MAXLINES], squished = FALSE, timeflag = FALSE, numeric = FALSE;
	char           *infile, oline[MAXCHARS], sline[MAXCHARS], addl, *psline;
	FILE           *fp, *fopen();

	eoline = -1;
	if (argc < MINARG) {
		fprintf(stderr, "usage: %s infile numofphils maxrows maxcolumns -t -n -q -s\n", *argv);
		fprintf(stderr, "\tt=time, n=numeric, q=squished, s=sequential\n");
		exit(1);
	}
	infile = argv[1];
	numofphils = atoi(argv[2]);
	maxrows = atoi(argv[3]);
	maxcolumns = atoi(argv[4]);
	maxcolumns--;
	for (i = 1; i < argc; i++) {
		if (argv[i][0] == '-') {
			switch (argv[i][1]) {
			case 'q':
				squished = TRUE;
				break;
			case 't':
				timeflag = TRUE;
				break;
			case 'n':
				numeric = TRUE;
				break;
			case 's':
				sequential = TRUE;
				break;
			default:
				fprintf(stderr, "non-existant option %s\n", argv[i]);
				exit(1);
			}
		}
	}

	/* check input line to see if it is up to snuff */
	if (maxrows > MAXROWS) {
		fprintf(stderr, "%s: maxrows is too large\n", *argv);
		exit(1);
	}
	if (maxcolumns > MAXCOLUMNS) {
		fprintf(stderr, "%s: maxcolumns is too large\n", *argv);
		exit(1);
	}
	if (!(squished || timeflag || numeric)) {
		fprintf(stderr, "%s: must have a -t, -q, or -n option\n", *argv);
		exit(1);
	}
	if ((fp = fopen(infile, "r")) == NULL) {
		fprintf(stderr, "%s: can't open %s\n", *argv, infile);
		exit(1);
	}
	if ((i = fscanf(fp, "%*s %d %d %d %d %d ", &phil, &rfork, &marcs, &rtime,
			&sumonly)) == EOF) {
		fprintf(stderr, "%s: premature end-of-file\n", *argv);
		exit(1);
	}
	linenum++;
	start = 1;
	incr = 2;

	while (readline(fp, line, numofphils) != EOF) {
		if (linenum == 2) {
			ftime = line[0];
			lasttime = ftime;
			oline[0] = '\0';
		}
		linenum++;
		tstate = 0;
		psline = sline;
		addl = NOTHING;
		cflag = 0;
		for (j = start; j <= numofphils * 2; j += incr) {
			switch (line[j]) {
			case 1:
				addl = NOTHING;
				tstate = 0;
				break;
			case 2:
			case 10:
			case 6:
			case 11:
				addl = SIMPLEA;
				tstate = 1;
				break;
			case 7:
			case 3:
			case 12:
			case 8:
			case 13:
				addl = SECONDA;
				tstate = 1;
				break;
			case 9:
				addl = EAT;
				tstate = 2;
				break;
			case 4:
			case 14:
				addl = SIMPLER;
				tstate = 3;
				break;
			case 5:
				addl = SECONDR;
				tstate = 3;
				break;
			case 15:
				addl = THINK;
				tstate = 4;
				break;
			}
			if ((tstate != lstate[j]) && (tstate != 0))
				cflag = 1;
			*psline++ = addl;
			lstate[j] = tstate;
		}
		*psline = '\0';
		if (cflag) {
			if (rtime)
				ptime = lasttime;
			else
				ptime = lasttime - ftime;
			stime = line[0] - lasttime;
			eline = encode(lstate, start, incr, numofphils);
			if (eoline != -1) {
				atempstr[0] = '\0';
				tempstr[0] = '\0';
				if (timeflag) {
					sprintf(tempstr, "%10d %6d ", ptime, stime);
					strcat(atempstr, tempstr);
				}
				if (squished) {
					sprintf(tempstr, "%s ", oline);
					strcat(atempstr, tempstr);
				}
				if (numeric) {
					sprintf(tempstr, "%d", eoline);
					strcat(atempstr, tempstr);
				}
				outarray[crow][ccolumn] = malloc(strlen(atempstr) + 1);
				strcpy(outarray[crow][ccolumn], atempstr);
				crow = (crow + 1) % maxrows;
				if (crow == 0)
					ccolumn = (ccolumn + 1);
				if (ccolumn > maxcolumns) {
					printit(maxrows, maxcolumns);
					if (!sequential)
						fprintf(stdout, "\f");
					ccolumn = 0;
				}
			}
			lasttime = line[0];
			strcpy(oline, sline);
			eoline = eline;
	  }
  }
	printit(crow, ccolumn);
}

readline(fp,line,numofphils)
FILE *fp;
int line[],numofphils;
{
	int i;

	if(fscanf(fp,"%d ",&line[0]) == EOF) {
		return(EOF);
	}
	for(i=1; i <= numofphils*2; i++) {
		fscanf(fp,"%d ",&line[i]);
	}
	return(1);
}

encode(lstate,start,incr,numofphils)
int lstate[],start,incr;
{
	int sum, factor, i, count;

	count = 0;
	sum = 0;
	for(i=start; i <= numofphils*2; i=i+incr) {
		factor = ipow(5,count);
		sum = sum+(lstate[i]*factor);
		count++;
	}
	return(sum);
}

printit(rows,columns)
int rows,columns;
{
	int             i, j;

	if (sequential) {
		for (i = 0; i < columns; i++)
			for (j = 0; j < maxrows; j++)
				fprintf(stdout, "%s ", outarray[j][i]);
		for (j = 0; j < rows; j++)
			fprintf(stdout, "%s ", outarray[j][columns]);
	} else {
		for (i = 0; i < rows; i++) {
			for (j = 0; j <= columns; j++)
				fprintf(stdout, "%s\t", outarray[i][j]);
			fprintf(stdout, "\n");
		}
		for (i = rows; i < maxrows; i++) {
			for (j = 0; j < columns; j++)
				fprintf(stdout, "%s\t", outarray[i][j]);
			fprintf(stdout, "\n");
		}
	}
}

ipow(x,n)
int x,n;
{
	int k,y,z;

	k = n;
	y = 1;
	z = x;
	while (k != 0)
		if (k%2) { k--; y *= z; }
		else { k /= 2; z *= z; };
	return(y);
}
