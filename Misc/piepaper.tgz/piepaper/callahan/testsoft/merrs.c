/*
 * target location vs number of errors
 *
 */

#include <stdio.h>

int totals[2][8];

main()
{
  int subjnum,choice,menuRow,menuCol,menuNum,errchoice,realchoice,err,item;
  int i,j;

  for(i=0;i < 2;i++) for(j=0;j < 8;j++)
    { totals[i][j] = 0; }
  while(fscanf(stdin,"%d %d %d %d %d %d %d %d %d\n",
    &subjnum,&menuRow,&menuCol,&choice,&menuNum,&errchoice,
     &realchoice,&err,&item) != EOF) {
    totals[menuRow-1][realchoice-1] += err;
  }
  for(i=0;i < 2;i++) for(j=0;j < 8;j++) {
    fprintf(stdout,"%d\t%d\t%d\n",i+1,j+1,totals[i][j]);
  }
}
