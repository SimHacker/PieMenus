#include <stdio.h>

main()
{
	char	*t, *malloc();

	t = malloc(50);
	strcpy(t,"hello there!");
	fprintf(stdout,"anyone home???\n\n\n");
	fprintf(stdout,"a string %s!\n",t);
}
