/*
 * compute mean seektime for menu type and location in menu
 *
 */

#include <stdio.h>

double totals[2][8];
int counts[2][8];

main()
{
  int subjnum,cell,menuRow,menuCol,menuNum,choice,realchoice,item;
  int i,j;
  char ttime[100];
  double time;

  for(i=0;i < 2;i++) for(j=0;j < 8;j++)
    { totals[i][j] = 0.0; counts[i][j] = 0; }
  while(fscanf(stdin,"%d %d %d %d %d %s %d %d %d\n",&subjnum,&cell,&menuRow,&menuCol,&menuNum,ttime,&choice,&realchoice,&item) != EOF) {
    (counts[menuRow-1][realchoice-1])++; totals[menuRow-1][realchoice-1] += atof(ttime);
  }
  for(i=0;i < 2;i++) for(j=0;j < 8;j++) {
    if(counts[i][j] != 0)
      fprintf(stdout,"%d\t%d\t%f\n",i+1,j+1,totals[i][j]/counts[i][j]);
    else fprintf(stdout,"%d\t%d\t%f\n",i+1,j+1,totals[i][j]);
  }
}
