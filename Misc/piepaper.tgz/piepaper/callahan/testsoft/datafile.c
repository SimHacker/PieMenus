/*
 * main prog for crunching don's pie menu data format
 *
 * jrc
 *
 */

#include <stdio.h>

extern int errs;

main(argc,argv)
int argc;
char **argv;
{
	int i;

	for (i = 1; i < argc; i++) {
		if (argv[i][0] == '-') {
			switch (argv[i][1]) {
				case 'e':
					errs = 1;
					break;
			}
		}
	}
	return(yyparse());
}

#include <stdio.h>

yyerror(s)
char *s;
{
	fprintf(stderr,"%s\n",s);
}
