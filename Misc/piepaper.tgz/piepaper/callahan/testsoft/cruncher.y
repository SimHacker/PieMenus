%{

#include <stdio.h>
#include <ctype.h>

int i,j, cell = 0, cells[6], item = 0, menuRow, menuCol, subjnum, choice;
int summeans = 0, menunum = 0, nerrs = 0, errchoice, errs = 0, tots, err, realchoice,mmeans = 0;
double timecells[6],lasttime;
double mtimecells[6][5];
char *malloc();

%}

%start datafile

%union	{
	int ival;
	double dval;
	char *str;
	}

%token SUBJECT NUMBER NAME MENU
%token <str> PP PL PO LP LL LO		/* menu types */
%token CHOOSE TIME SEC SELECTED
%token NO CHOICE TOTAL TEST COMPLETED
%token <str> NUM STR REAL

%%	/* begin rules section */

datafile	:	header
			body
			epilogue
		;

header		:	subjNumberLine '\n'
				{ for(i=0; i < 6;i++) cells[i] = 0; }
			subjNameLine '\n' '\n'
		;

subjNumberLine	:	SUBJECT NUMBER ':' NUM
			{ subjnum = atoi($4);
			  fprintf(stderr,
				"processing subject number %d\n",subjnum); }
		;

subjNameLine	:	SUBJECT NAME ':' STR
		;

body		:	menuItem '\n'
		|	body menuItem '\n'
		;

menuItem	:	MENU { err = 0; } 
			menuType ':' '\n' chooseLine
			timeLines totalLine
		;

menuType	:	cell
		;

cell		:	PP { cell = 1; menuRow = 1; menuCol = 1;
				menunum = atoi($1); }
		|	PL { cell = 2; menuRow = 1; menuCol = 2;
				menunum = atoi($1); }
		|	PO { cell = 3; menuRow = 1; menuCol = 3;
				menunum = atoi($1); }
		|	LP { cell = 4; menuRow = 2; menuCol = 1;
				menunum = atoi($1); }
		|	LL { cell = 5; menuRow = 2; menuCol = 2;
				menunum = atoi($1); }
		|	LO { cell = 6; menuRow = 2; menuCol = 3;
				menunum = atoi($1); }
		;

chooseLine	:	CHOOSE '#' NUM
			{ realchoice = atoi($3);
			  item++;
			  switch (realchoice) {
				case 1:
				case 2:
				case 3: choice = 1; break;
				case 4:
				case 5: choice = 2; break;
				case 6:
				case 7:
				case 8: choice = 3; break; }}
			'=' qstrnum '.' '\n'
		|	CHOOSE NUM
			{ realchoice = atoi($2);
			  item++;
			  switch (realchoice) {
				case 1:
				case 2:
				case 3: choice = 1; break;
				case 4:
				case 5: choice = 2; break;
				case 6:
				case 7:
				case 8: choice = 3; break; }}
			'=' qstrnum '\n'
		;

qstrnum		:	'\'' STR '\''
		|	'\'' NUM '\''
		;

timeLines	:	timeLine
		|	timeLine timeLines
		;

timeLine	:	TIME ':' REAL
			{ lasttime = atof($3); }
			SEC SELECTED ':' specialString '\n'
			{
			  if (errs) {
				if (err) {
				  printf("%d %d %d %d %d %d %d %d %d\n",
						subjnum,menuRow,menuCol,
						choice,menunum,
						errchoice,realchoice,err,
						item);
					err = 0;
				}
			}}
		;

specialString	:	'#' NUM
			{ errchoice = atoi($2);
			  if (errchoice != realchoice) {
				cells[cell-1]++; err++; }}
			'=' qstrnum
		|	NUM
			{ errchoice = atoi($1);
			  if (errchoice != realchoice) {
				cells[cell-1]++; err++; }}
			'=' qstrnum
		|	'[' NO CHOICE ']'
			{ errchoice = 0;
			  cells[cell-1]++; err++; }
		;

totalLine	:	TOTAL TIME ':' REAL
			{
				mtimecells[cell-1][menunum-1] += atof($4);
				timecells[cell-1] += atof($4);
				if (!errs && !nerrs && !summeans && !tots && !mmeans)
				printf("%d %d %d %d %d %s %d %d %d\n",
					subjnum,cell,menuRow,menuCol,
					menunum,$4,
					choice,realchoice,item);
				if(tots)
				printf("%d %d %d %d %d %f %d %d %d\n",
					subjnum,cell,menuRow,menuCol,
					menunum,lasttime,
					choice,realchoice,item);
			}
			SEC '\n'
		;

epilogue	:	TEST COMPLETED '.' '\n'
			{
				if(summeans) {
				  printf("%d ",subjnum);
				  for(i=0;i < 6;i++)
				    printf("%d %f ",i+1,timecells[i]/10);
				  printf("\n");
				} else if(nerrs) {
				  printf("%d ",subjnum);
				  for(i=0;i < 6;i++)
				    printf("%d %d ",i+1,cells[i]);
				  printf("\n");
				} else if(mmeans) {
				  printf("%d",subjnum);
				  for(i=0;i < 6;i++) {
				    for(j=0;j < 5;j++)
				      printf(" %10.4f",mtimecells[i][j]/2);
				    printf("\n");
				  }
				  printf("\n");
				}
			}
		;

%% /* lex stuff goes here, so ... */

#include "lex.yy.c"
