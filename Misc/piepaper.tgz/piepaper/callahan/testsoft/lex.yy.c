# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX 200
# define output(c) (void) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin ={stdin}, *yyout ={stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
	return(SUBJECT);
break;
case 2:
	return(NUMBER);
break;
case 3:
	return(NAME);
break;
case 4:
	return(MENU);
break;
case 5:
	{ yylval.str = yytext+2; return(PP); }
break;
case 6:
	{ yylval.str = yytext+2; return(PL); }
break;
case 7:
	{ yylval.str = yytext+2; return(PO); }
break;
case 8:
	{ yylval.str = yytext+2; return(LP); }
break;
case 9:
	{ yylval.str = yytext+2; return(LL); }
break;
case 10:
	{ yylval.str = yytext+2; return(LO); }
break;
case 11:
	return(CHOOSE);
break;
case 12:
	return(TIME);
break;
case 13:
	return(SEC);
break;
case 14:
return(SELECTED);
break;
case 15:
	return(NO);
break;
case 16:
	return(CHOICE);
break;
case 17:
	return(TOTAL);
break;
case 18:
	return(TEST);
break;
case 19:
return(COMPLETED);
break;
case 20:
{ yylval.str = yytext; return(REAL); }
break;
case 21:
	{ yylval.str = yytext; return(NUM); }
break;
case 22:
{ yylval.str = yytext; return(STR); }
break;
case 23:
	return('\n');
break;
case 24:
	return(':');
break;
case 25:
	return('\'');
break;
case 26:
	return('.');
break;
case 27:
	return('[');
break;
case 28:
	return(']');
break;
case 29:
	;
break;
case 30:
	return('#');
break;
case 31:
	return('=');
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
#ifdef lint
goto yyfussy;
#endif
} return(0); }
/* end of yylex */
int yyvstop[] ={
0,

29,
0,

23,
0,

30,
0,

25,
0,

26,
0,

21,
22,
0,

24,
0,

31,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

27,
0,

28,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

15,
22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

20,
0,

22,
0,

9,
22,
0,

10,
22,
0,

8,
22,
0,

22,
0,

6,
22,
0,

7,
22,
0,

5,
22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

13,
22,
0,

22,
0,

4,
22,
0,

22,
0,

22,
0,

18,
22,
0,

12,
22,
0,

22,
0,

22,
0,

22,
0,

3,
22,
0,

22,
0,

22,
0,

22,
0,

22,
0,

17,
22,
0,

22,
0,

22,
0,

22,
0,

11,
22,
0,

22,
0,

22,
0,

16,
22,
0,

22,
0,

2,
22,
0,

22,
0,

1,
22,
0,

22,
0,

14,
22,
0,

22,
0,

19,
22,
0,
0};
# define YYTYPE char
struct yywork { YYTYPE verify, advance; } yycrank[] ={
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,3,	1,4,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,3,	0,0,	0,0,	
1,5,	0,0,	0,0,	0,0,	
1,6,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	1,7,	
0,0,	1,8,	1,8,	1,8,	
1,8,	1,8,	1,8,	1,8,	
1,8,	1,8,	1,8,	1,9,	
0,0,	0,0,	1,10,	0,0,	
0,0,	0,0,	1,11,	1,11,	
1,12,	1,11,	1,11,	1,11,	
1,11,	1,11,	1,11,	1,11,	
1,11,	1,13,	1,14,	1,15,	
1,11,	1,16,	1,11,	1,11,	
1,17,	1,18,	1,11,	1,11,	
1,11,	1,11,	1,11,	1,11,	
1,19,	13,27,	1,20,	0,0,	
13,28,	13,29,	1,11,	1,11,	
1,21,	1,11,	1,11,	1,11,	
1,11,	1,11,	1,11,	1,11,	
1,11,	1,11,	1,11,	1,22,	
1,11,	1,11,	1,11,	1,11,	
1,23,	1,24,	1,11,	1,11,	
1,11,	1,11,	1,11,	1,11,	
8,25,	12,26,	8,8,	8,8,	
8,8,	8,8,	8,8,	8,8,	
8,8,	8,8,	8,8,	8,8,	
14,30,	15,31,	16,32,	23,44,	
24,38,	16,33,	16,34,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	26,46,	30,50,	35,54,	
36,55,	37,56,	38,57,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	8,11,	8,11,	8,11,	
8,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	39,58,	
40,59,	41,60,	42,61,	43,62,	
44,63,	46,64,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
50,65,	54,66,	55,67,	56,68,	
57,69,	58,70,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
11,11,	11,11,	11,11,	11,11,	
17,35,	18,37,	21,40,	22,42,	
59,71,	18,38,	60,72,	61,73,	
62,74,	21,41,	64,75,	18,39,	
66,76,	67,77,	70,78,	71,79,	
17,36,	72,80,	74,81,	75,82,	
76,83,	77,84,	79,85,	22,43,	
25,45,	25,45,	25,45,	25,45,	
25,45,	25,45,	25,45,	25,45,	
25,45,	25,45,	27,47,	27,47,	
27,47,	27,47,	27,47,	27,47,	
27,47,	27,47,	27,47,	27,47,	
28,48,	28,48,	28,48,	28,48,	
28,48,	28,48,	28,48,	28,48,	
28,48,	28,48,	29,49,	29,49,	
29,49,	29,49,	29,49,	29,49,	
29,49,	29,49,	29,49,	29,49,	
32,51,	32,51,	32,51,	32,51,	
32,51,	32,51,	32,51,	32,51,	
32,51,	32,51,	33,52,	33,52,	
33,52,	33,52,	33,52,	33,52,	
33,52,	33,52,	33,52,	33,52,	
34,53,	34,53,	34,53,	34,53,	
34,53,	34,53,	34,53,	34,53,	
34,53,	34,53,	80,86,	81,87,	
83,88,	84,89,	86,90,	88,91,	
90,92,	92,93,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] ={
0,	0,	0,
yycrank+1,	0,		0,	
yycrank+0,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+0,	0,		yyvstop+7,
yycrank+0,	0,		yyvstop+9,
yycrank+78,	0,		yyvstop+11,
yycrank+0,	0,		yyvstop+14,
yycrank+0,	0,		yyvstop+16,
yycrank+153,	0,		yyvstop+18,
yycrank+21,	yysvec+11,	yyvstop+20,
yycrank+17,	yysvec+11,	yyvstop+22,
yycrank+35,	yysvec+11,	yyvstop+24,
yycrank+26,	yysvec+11,	yyvstop+26,
yycrank+62,	yysvec+11,	yyvstop+28,
yycrank+175,	yysvec+11,	yyvstop+30,
yycrank+176,	yysvec+11,	yyvstop+32,
yycrank+0,	0,		yyvstop+34,
yycrank+0,	0,		yyvstop+36,
yycrank+174,	yysvec+11,	yyvstop+38,
yycrank+182,	yysvec+11,	yyvstop+40,
yycrank+38,	yysvec+11,	yyvstop+42,
yycrank+35,	yysvec+11,	yyvstop+44,
yycrank+252,	0,		0,	
yycrank+58,	yysvec+11,	yyvstop+46,
yycrank+262,	yysvec+11,	yyvstop+48,
yycrank+272,	yysvec+11,	yyvstop+50,
yycrank+282,	yysvec+11,	yyvstop+52,
yycrank+60,	yysvec+11,	yyvstop+54,
yycrank+0,	yysvec+11,	yyvstop+56,
yycrank+292,	yysvec+11,	yyvstop+59,
yycrank+302,	yysvec+11,	yyvstop+61,
yycrank+312,	yysvec+11,	yyvstop+63,
yycrank+63,	yysvec+11,	yyvstop+65,
yycrank+74,	yysvec+11,	yyvstop+67,
yycrank+58,	yysvec+11,	yyvstop+69,
yycrank+65,	yysvec+11,	yyvstop+71,
yycrank+95,	yysvec+11,	yyvstop+73,
yycrank+101,	yysvec+11,	yyvstop+75,
yycrank+104,	yysvec+11,	yyvstop+77,
yycrank+105,	yysvec+11,	yyvstop+79,
yycrank+106,	yysvec+11,	yyvstop+81,
yycrank+117,	yysvec+11,	yyvstop+83,
yycrank+0,	yysvec+25,	yyvstop+85,
yycrank+106,	yysvec+11,	yyvstop+87,
yycrank+0,	yysvec+11,	yyvstop+89,
yycrank+0,	yysvec+11,	yyvstop+92,
yycrank+0,	yysvec+11,	yyvstop+95,
yycrank+127,	yysvec+11,	yyvstop+98,
yycrank+0,	yysvec+11,	yyvstop+100,
yycrank+0,	yysvec+11,	yyvstop+103,
yycrank+0,	yysvec+11,	yyvstop+106,
yycrank+144,	yysvec+11,	yyvstop+109,
yycrank+140,	yysvec+11,	yyvstop+111,
yycrank+131,	yysvec+11,	yyvstop+113,
yycrank+147,	yysvec+11,	yyvstop+115,
yycrank+152,	yysvec+11,	yyvstop+117,
yycrank+175,	yysvec+11,	yyvstop+119,
yycrank+170,	yysvec+11,	yyvstop+121,
yycrank+182,	yysvec+11,	yyvstop+123,
yycrank+186,	yysvec+11,	yyvstop+125,
yycrank+0,	yysvec+11,	yyvstop+127,
yycrank+171,	yysvec+11,	yyvstop+130,
yycrank+0,	yysvec+11,	yyvstop+132,
yycrank+189,	yysvec+11,	yyvstop+135,
yycrank+188,	yysvec+11,	yyvstop+137,
yycrank+0,	yysvec+11,	yyvstop+139,
yycrank+0,	yysvec+11,	yyvstop+142,
yycrank+182,	yysvec+11,	yyvstop+145,
yycrank+192,	yysvec+11,	yyvstop+147,
yycrank+185,	yysvec+11,	yyvstop+149,
yycrank+0,	yysvec+11,	yyvstop+151,
yycrank+193,	yysvec+11,	yyvstop+154,
yycrank+194,	yysvec+11,	yyvstop+156,
yycrank+180,	yysvec+11,	yyvstop+158,
yycrank+198,	yysvec+11,	yyvstop+160,
yycrank+0,	yysvec+11,	yyvstop+162,
yycrank+197,	yysvec+11,	yyvstop+165,
yycrank+269,	yysvec+11,	yyvstop+167,
yycrank+257,	yysvec+11,	yyvstop+169,
yycrank+0,	yysvec+11,	yyvstop+171,
yycrank+271,	yysvec+11,	yyvstop+174,
yycrank+257,	yysvec+11,	yyvstop+176,
yycrank+0,	yysvec+11,	yyvstop+178,
yycrank+258,	yysvec+11,	yyvstop+181,
yycrank+0,	yysvec+11,	yyvstop+183,
yycrank+275,	yysvec+11,	yyvstop+186,
yycrank+0,	yysvec+11,	yyvstop+188,
yycrank+275,	yysvec+11,	yyvstop+191,
yycrank+0,	yysvec+11,	yyvstop+193,
yycrank+277,	yysvec+11,	yyvstop+196,
yycrank+0,	yysvec+11,	yyvstop+198,
0,	0,	0};
struct yywork *yytop = yycrank+377;
struct yysvf *yybgin = yysvec+1;
char yymatch[] ={
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'T' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,'A' ,'T' ,'A' ,'A' ,'A' ,
'A' ,'A' ,'A' ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] ={
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	ncform	4.1	83/08/11	*/

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank){		/* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
