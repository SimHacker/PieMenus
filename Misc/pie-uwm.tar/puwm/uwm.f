cr .( Loading...) cr
requires clink.f
cr .( Linking...) cr
"" a.out clink
cr .( Done!) cr
