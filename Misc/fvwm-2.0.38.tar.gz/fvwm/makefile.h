/***************************************************************************
 * You should not need to change this file.
 * Putting things here is simpler then editing every Imakefile.
 * This does hint of GNU AutoConf.
 **************************************************************************/
#ifdef FVWM_COMPILER
CC = FVWM_COMPILER
#endif

#ifdef FVWM_BINDIR
BINDIR = FVWM_BINDIR
#endif

#ifdef FVWM_LIBDIR
LIBDIR = FVWM_LIBDIR
#endif

#ifdef FVWM_MANDIR
MANDIR = FVWM_MANDIR
#endif

#ifdef FVWM_MANSUFFIX
MANSUFFIX = FVWM_MANSUFFIX
#endif

#ifndef FVWM_MODULEDIR
#define FVWM_MODULEDIR FVWMDIR
#endif

LIB = FVWM

#ifndef XPM_INCLUDES
#define XPM_INCLUDES
#endif
#ifndef XPM_LIBRARIES
#define XPM_LIBRARIES
#else
XPMLIB = XPM_LIBRARIES
#endif
#ifndef AUDIO_INCLUDES
#define AUDIO_INCLUDES
#endif
#ifndef AUDIO_LIBRARIES
#define AUDIO_LIBRARIES
#endif

#ifdef FVWM_BUILD_RULES
EXTRA_INCLUDES = -I. -I$(FVWM_SRCDIR)/libs
DEPLIBS = $(DEPXLIB)  $(FVWM_SRCDIR)/libs/lib$(LIB).a

#ifdef AlphaArchitecture
LOCAL_LIBRARIES = XPM_LIBRARIES $(XLIB) -ldnet_stub -L$(FVWM_SRCDIR)/libs -l$(LIB)
#else
#if defined(SunArchitecture) && OSMajorVersion > 5
LOCAL_LIBRARIES = XPM_LIBRARIES $(XLIB) -L$(FVWM_SRCDIR)/libs -l$(LIB) -lsocket
#else
#ifdef HPArchitecture
LOCAL_LIBRARIES = XPM_LIBRARIES $(XLIB) -lV3 -L$(FVWM_SRCDIR)/libs -l$(LIB)
#else
#ifdef i386SVR4Architecture
LOCAL_LIBRARIES = XPM_LIBRARIES $(XLIB) -lnsl -lsocket -L$(FVWM_SRCDIR)/libs -l$(LIB)
#else
LOCAL_LIBRARIES = XPM_LIBRARIES $(XLIB) $(FVWM_SRCDIR)/libs/lib$(LIB).a
#endif /* i386SVR4Architecture */
#endif /* HPArchitecture */
#endif /* SunArchitecture && OSMajorVersion > 5 */
#endif /* AlphaArchitecture */

LINTLIBS = $(LINTXLIB)

#endif /* FVWM_BUILD_RULES */

#ifndef InstallNamedNonExec
#define InstallNamedNonExec(what,as,where) InstallNonExec(what,where/as)
#endif /* InstallNamedNonExec() */

#ifndef NullMake
#define NullMake()							@@\
all::									@@\
	@echo "make in $(CURRENT_DIR) done"
#endif /* NullMake */

#ifndef InstallExecTarget
#define InstallExecTarget(file,destdir)					@@\
install:: file								@@\
	$(INSTALL) -c $(INSTBINFLAGS) file $(DESTDIR)destdir
#endif /* InstallExecTarget */
