C: #define ROWBYTES_TAG 1
C: #define SYNC_TAG 2
#define ROWBYTES_TAG 1
#define SYNC_TAG 2

cdef ps_initialize(string SharedFile, Width, Height, LineBytes)
  => ROWBYTES_TAG(LineBytes)

  /height Height def
  /width Width def
  /sharedfile SharedFile def
  /canvas
    width height 8 [width 0 0 height neg 0 height] null buildimage 
  def
  canvas /RowBytes get ROWBYTES_TAG tagprint typedprint
  canvas /SharedFile sharedfile put

cdef ps_splat(x, y)
  gsave
    framebuffer setcanvas
    x y translate
    width height scale
    canvas imagecanvas
  grestore

cdef ps_sync(In, Out) => SYNC_TAG(Out)
  SYNC_TAG tagprint In typedprint
