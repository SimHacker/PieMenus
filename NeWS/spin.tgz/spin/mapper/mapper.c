/*
 * mapper.c
 * Copyright (C) 1990 by Don Hopkins
 * 
 * SunOS 4.0 memory mapping client for X11/NeWS
 * 
 * mapper InputFile SharedFile Width Height USleep SkipBytes
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/mman.h>
#include <sys/vadvise.h>
#include <stdio.h>
#include "mapper.h"

char *InputFile;
char *SharedFile;
int X, Y, Width, Height;
int USleep;
int SkipBytes;
int ImageBytes;
int RowBytes;
int Input;
char *Image;
char *Padding;

char *mmap_sharedfile();
int unmap_sharedfile();

main (argc, argv)
int	argc;
char	*argv[];
{
  if (argc != 9) {
    fprintf(stderr, 
      "usage: mapper InputFile SharedFile X Y Width Height USleep SkipBytes\n");
    exit(1);
  }

  InputFile = argv[1];
  SharedFile = argv[2];
  X = atoi(argv[3]);
  Y = atoi(argv[4]);
  Width = atoi(argv[5]);
  Height = atoi(argv[6]);
  USleep = atoi(argv[7]);
  SkipBytes = atoi(argv[8]);

  ImageBytes = Width * Height;

  if (strcmp(InputFile, "-") == 0) {
    Input = fileno(stdin);
  } else if ((Input = open(InputFile, O_RDONLY, 0)) < 0) {
    fprintf(stderr, "Can't open input file %s\n", InputFile);
    exit(1);
  }

  ps_open_PostScript();
  ps_initialize(SharedFile, Width, Height, &RowBytes);

  if ((Image = mmap_sharedfile(SharedFile, ImageBytes)) == (char *)-1) {
    fprintf(stderr, "Can't mmap %d byte file %\n", ImageBytes, SharedFile);
  }

  Padding = (char *)malloc(SkipBytes);

  pump();
}

/*
 * mmap_sharedfile - mmap the given absolute filename for memlen number
 * of bytes rounded to page boundary.  File will be mapped R/W.
 * Caller should check for validity of returned pointer.
 */

char *
mmap_sharedfile(absfn, memlen)
    char *absfn;
    int memlen;
{    
    struct stat statbuf;
    char *buf;
    register int wtemp, fd; 
    register int pagesize;
    static char ar[] = {0x0};
 
    pagesize = getpagesize();
    memlen = pagesize * ((memlen + pagesize - 1) / pagesize);
 
    if (!(fd = open(absfn, O_RDWR, 0666)))
        return((char *)-1);
    /* check out the filesize, extend if needed */
    if (stat(absfn, &statbuf))
        return((char *)-1);
    if (statbuf.st_size < memlen) {
        wtemp = lseek(fd, (off_t)(memlen-1), L_SET);
        if (wtemp == -1) {
            close(fd);
            return((char *)-1);
        }
        if (write(fd, ar, 1) != 1) {
            close(fd);
            return((char *)-1);
        }
    }
 
    /* Map the file pages */
    buf = (char *)mmap((caddr_t)0, memlen, PROT_READ|PROT_WRITE,
            MAP_SHARED, fd, (off_t)0);
    close(fd);
    return(buf);
}


/*
 * unmap_sharedfile - munmap the given pointer for memlen number of
 * bytes rounded to page boundary.  Caller should check for return
 * value.
 */

int
unmap_sharedfile(buf, memlen)
    caddr_t buf;
    int memlen;
{
    register int pagesize;

    pagesize = getpagesize();
    memlen = pagesize * ((memlen + pagesize - 1) / pagesize);
 
    if (msync(buf, memlen, MS_INVALIDATE) < 0)
        return(-1);
    if (munmap(buf, memlen) < 0)
        return(-1);

    return(0);
}

pump()
{
  char *p;
  int syncin, syncout;
  int n;
  int dontseek = 0;

  vadvise(VA_SEQL);

  while (1) {
    if (!dontseek && 
        (lseek(Input, (off_t)SkipBytes, L_INCR) < 0)) {
      fprintf(stderr, "Seek failed -- trying to read instead!\n");
      dontseek = 1;
    }
    if (dontseek && 
        ((n = read(Input, Padding, SkipBytes)) != SkipBytes)) {
      fprintf(stderr, "Read %d/%d skip bytes -- exiting!\n", n, SkipBytes);
      break;
    }

    if ((n = read(Input, Image, ImageBytes)) == ImageBytes) {
      ps_splat(X, Y);
      ps_sync(syncin,&syncout);
      syncin++;
      usleep(USleep);
    } else {
      fprintf(stderr, "Read %d/%d image bytes -- exiting!\n", n, ImageBytes);
      break;
    }
  }
}

