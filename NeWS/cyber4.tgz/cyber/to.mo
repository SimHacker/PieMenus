To: prisma!mo@uunet.UU.NET
In-reply-to: Mike O'Dell's message of Thu, 27 Apr 89 17:40:37 MDT <8904272340.AA19380@uunet.uu.net>
Subject: the postscript files....
--text follows this line--
I printed them out and saw that I have to fix the Isomorizer to stop
writing out 'controlpoint's, and write out 'arc's and 'lineto's
instead. It would look much better if all the circles weren't being
approximated as squares when they're printed! (I fixed it and now the
output files are even bigger.)

Yes, you could say that it's is a set of "data visualization" tools.
They're also for editing and manipulating data, and executing and
debugging code as well.  They're pretty general purpose. With the
addition of some more tools for translating various things into
PostScript data structures, it could be even *more* general purpose
and humans might even be able to use it!

The arpanet map is a network of PostScript dictionaries that I made by
emacs massaging a file that brescia@bbnccv sent to me. 

It used to look like:

address         endpoints (node, modem)     medium    speed
--------------- --------------------------- --------- ----- 
net 10 line   1 RCC5(5,5)     BBN63(63,1)   land       50
net 10 line   2 MIT6(6,0)     CCA(31,1)     land       50
net 10 line   3 UCLA(1,4)     ISI27(27,4)   land       50
net 10 line   4 SRI12(12,0)   SR107(107,3)  land       50
...

Now it looks like:

/ArpaMap 100 dict def
ArpaMap begin

/ARADC 20 dict def
  ARADC begin
    /hostname (ARADC) def
    /LINC /replaceme def
    /UROCH /replaceme def
  end % ARADC

%...

  /XEROX 20 dict def
  XEROX begin
    /hostname (XEROX) def
    /SUMEX /replaceme def
    /SRI2 /replaceme def
    /BERK /replaceme def
    /UCLA /replaceme def
  end % XEROX

end % ArpaMap

ArpaMap {
  begin pop
  currentdict {
    /replaceme eq {
      ArpaMap 1 index get def
    } { pop } ifelse
  } forall
  end
} forall

I've also got a shell script that translates a Unix file hierarchy
into nested PostScript dictionaries. A directory is a dictionary,
whose keys are file names, and whose values are files or directories.
Files are arrays whose keys are interesting file info:

{(/usr/NeWS/lib/NeWS/class.ps) (-rw-r--r--) don staff 9581 (May 26 1988)
 (class.ps)} dup 6 get exch def

The file names are strings, which are drawn as lines whose length is a
function of the length of the string, and since the absolute file name
is the 0'th element of the array, they all stick straight out away
from the middle of the directory they are in, so directories have all
these very regular spines bristling out of them. (Maybe the color of a
string should be a function of its first letter? I want to be able to
define those kinds of rules and attributes on the fly, as whim
dictates.)  File info arrays and directory dictionaries are mouse
sensative and selectable, and I've made functions that operate on the
selected file info array, so you can point at one of the circles,
select it, and click on a function to do something with that file (or
more generally, with whatever data structure you clicked on). 

I am going to make a tool for translating the structure of HyperTIES
hypertext databases into PostScript dictionaries, to see what they
look like, and hook it up to hyperties so you can define or go to a
node by clicking on its blob. I'm writing a HyperTIES authoring
environment with NeMACS [UniPress (Gosling) Emacs, with a fancy NeWS
interface, menu compiler, multiple windows, with title tabs, etc...]

In the circular graphical view, there is a popup pointing hand
that shows the object you just clicked on as text. (i.e.  a popup
window in the shape of a rounded rectangle with a hand sticking out of
it, the finger tip pointing to the cursor.) 

There's an x-ray feature for highlighting all the mouse sensative
targets at once, like the old exclusive-or-all-the-targets
hallucinogenetic color table pyrotechnics feature of before, except
that it does magic with the cg4 overlay plane to accomplish darkening
and lightening of the graphics (and appropriate buzzing and chirping
of the power supply). I want to make a conditional x-ray feature that
highlights every target object that passes some arbitrary test, so I
could hilite every file that is owed by don, or that is > 4096 bytes,
or every packet switching node that's three or fewer hops away from
DCEC, or every dictionary that's an instance of class PieMenu, or
every HyperTIES node that has a picture in it, or every executable
array, or every dictionary with a key that matches a pattern, or ... ! 

The circular graphical view of the pseudo-scientific visualizer is
useful in conjunction with the textual tree view of the "Spike" object
browser/editor that I was showing at Usenix. They both use the
selection mechanism (which is normally used to copy and paste text
into terminal windows, etc, except in this case you're copying and
pasting live PS objects [try to do that with X11!]), so you can click
on something in the graphical circular view window (which is round, of
course) to copy it to the primary selection, then go to the object
browser window and push it onto the stack, in its own little labled
subwindow (with a tab sticking out of it, showing the object's type
name, by which you can drag it around). You can open up the textual
tree views to any level, and the point size shrinks as you get deeper
into the tree.  Now there's a view menu, which you can pop up on any
piece of substructure, that changes the point size and the shrink
factor of individual pieces of substructure and its children, and you
can even make the shrink factor > 1 so it gets bigger as it gets
deeper!) Any part of the tree that's open, no matter how small, is
mouse sensative -- you can select it, paste something else into its
place, execute it, open it deeper, pop up a type-specific menu of
editing functions, convert it to other types, etc!  Right now the
graphical view is read-only, i.e.  you can select (copy) things from
it, but you can't paste stuff into it, since that involves redrawing,
which is expensive in that context. You can easily pop up another
round pseudo-scientific visualizer window on anything mouse-sensative
object in either domain, or push anything onto the stack in a tab
window view.  You can edit a reference to an object in a text view,
and then redraw a view of the same object in a graphical view, though.
My father suggested a direction for further research: inputting
PostScript data structures by sketching their circular graphical
representation!  ;-)

I can make color separations of the pseudo-scientific projections of
NeWS molecule hallucinations, using the "Isomorizor", a simple
PostScript optimizer for NeWS, in the spirit of Glen Reid's
"Distillery". It captures the calls to the drawing commands, and
writes them out as an unrolled, flat, optimized, low level PostScript
file.

It's not so easy to produce a PostScript file showing the magic
overlay plane highlighting and the pointing hand popup windows,
though.  For that, a photograph of the screen would be best.

As you can tell, I'm torn between implementing new features, and
writing about the ones I've already got working. But as you can see,
I'm am writing (though this is obviously pretty rough!), and I'll
incorporate this with the stuff I've already written and make an
attempt at translating it into English.

One thing I have to come up with is a consistant set of terminology
for all this stuff. This is an example of software development via
simulated annealing. Lots of surrealistic variable names. If any
snappy but meaningful buzz words come to mind, toss them my way!

	-Don
