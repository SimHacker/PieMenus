/////////////////////////////////////////////////////////////////////////////
//
// PieMenuPpg2.cpp : Implementation of the CPieMenuPropPage2 property page class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "PieMenuPpg2.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Dynamic OLE Control Creation

IMPLEMENT_DYNCREATE(CPieMenuPropPage2, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CPieMenuPropPage2, COlePropertyPage)
	//{{AFX_MSG_MAP(CPieMenuPropPage2)
	ON_WM_PAINT()
	ON_CBN_SELCHANGE(IDC_SHAPEWINDOW, OnSelchangeShapewindow)
	ON_CBN_SELCHANGE(IDC_MAXSLICESINDEX, OnSelchangeMaxslicesindex)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CPieMenuPropPage2, "PIEMENU.PieMenuPropPage2.1",
	0x87351bc4, 0x983f, 0x11cf, 0x9a, 0x4b, 0x54, 0xa4, 0xff, 0xc1, 0, 0)


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage2::CPieMenuPropPage2Factory::UpdateRegistry -
// Adds or removes system registry entries for CPieMenuPropPage

BOOL CPieMenuPropPage2::CPieMenuPropPage2Factory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_PIEMENU_PPG2);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage2::CPieMenuPropPage2 - Constructor

CPieMenuPropPage2::CPieMenuPropPage2() :
	COlePropertyPage(IDD, IDS_PIEMENU2_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CPieMenuPropPage2)
	m_BorderWidth = 0;
	m_Clockwise = FALSE;
	m_ExtraRadius = 0;
	m_FixedRadius = 0;
	m_InactiveRadius = 0;
	m_InitialAngle = 0;
	m_ItemBorderWidth = 0;
	m_MinRadius = 0;
	m_PopupDelay = 0;
	m_ShapeWindow = -1;
	m_ShrinkWrap = FALSE;
	m_DoubleBuffer = FALSE;
	m_ItemGap = 0;
	m_Bevel = FALSE;
	m_pieLong = 0;
	m_ShapeCenterX = 0;
	m_ShapeCenterY = 0;
	m_ShapeTransparentX = 0;
	m_ShapeTransparentY = 0;
	m_DynamicShaping = FALSE;
	m_SliceInset = 0;
	m_Shuffle = FALSE;
	m_scrollingMovesCursor = FALSE;
	m_maxSlicesIndex = -1;
	m_RoundRectRadius = 0;
	m_Stack = FALSE;
	//}}AFX_DATA_INIT

	revision = -1;
	m_pie = NULL;
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage2::DoDataExchange
	
void CPieMenuPropPage2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPieMenuPropPage2)
	DDX_Control(pDX, IDC_INITIALANGLE, m_InitialAngleControl);
	DDX_Control(pDX, IDC_CLOCKWISE, m_ClockwiseControl);
	DDX_Control(pDX, IDC_MAXSLICESINDEX, m_maxSlicesIndexControl);
	DDX_Control(pDX, IDC_SHAPEWINDOW, m_ShapeWindowControl);
	DDX_Control(pDX, IDC_SHAPETRANSPARENTY, m_ShapeTransparentYControl);
	DDX_Control(pDX, IDC_SHAPETRANSPARENTX, m_ShapeTransparentXControl);
	DDX_Control(pDX, IDC_SHAPECENTERY, m_ShapeCenterYControl);
	DDX_Control(pDX, IDC_SHAPECENTERX, m_ShapeCenterXControl);
	DDX_Control(pDX, IDC_EDIT1, m_pieText);
	DDP_Text(pDX, IDC_BORDERWIDTH, m_BorderWidth, _T("BorderWidth") );
	DDX_Text(pDX, IDC_BORDERWIDTH, m_BorderWidth);
	DDV_MinMaxLong(pDX, m_BorderWidth, 0, 100);
	DDP_Check(pDX, IDC_CLOCKWISE, m_Clockwise, _T("Clockwise") );
	DDX_Check(pDX, IDC_CLOCKWISE, m_Clockwise);
	DDP_Text(pDX, IDC_EXTRARADIUS, m_ExtraRadius, _T("ExtraRadius") );
	DDX_Text(pDX, IDC_EXTRARADIUS, m_ExtraRadius);
	DDV_MinMaxLong(pDX, m_ExtraRadius, 0, 500);
	DDP_Text(pDX, IDC_FIXEDRADIUS, m_FixedRadius, _T("FixedRadius") );
	DDX_Text(pDX, IDC_FIXEDRADIUS, m_FixedRadius);
	DDV_MinMaxLong(pDX, m_FixedRadius, 0, 500);
	DDP_Text(pDX, IDC_INACTIVERADIUS, m_InactiveRadius, _T("InactiveRadius") );
	DDX_Text(pDX, IDC_INACTIVERADIUS, m_InactiveRadius);
	DDV_MinMaxLong(pDX, m_InactiveRadius, 0, 500);
	DDP_Text(pDX, IDC_INITIALANGLE, m_InitialAngle, _T("InitialAngle") );
	DDX_Text(pDX, IDC_INITIALANGLE, m_InitialAngle);
	DDV_MinMaxLong(pDX, m_InitialAngle, 0, 359);
	DDP_Text(pDX, IDC_ITEMBORDERWIDTH, m_ItemBorderWidth, _T("ItemBorderWidth") );
	DDX_Text(pDX, IDC_ITEMBORDERWIDTH, m_ItemBorderWidth);
	DDV_MinMaxLong(pDX, m_ItemBorderWidth, 0, 100);
	DDP_Text(pDX, IDC_MINRADIUS, m_MinRadius, _T("MinRadius") );
	DDX_Text(pDX, IDC_MINRADIUS, m_MinRadius);
	DDV_MinMaxLong(pDX, m_MinRadius, 0, 500);
	DDP_Text(pDX, IDC_POPUPDELAY, m_PopupDelay, _T("PopupDelay") );
	DDX_Text(pDX, IDC_POPUPDELAY, m_PopupDelay);
	DDV_MinMaxLong(pDX, m_PopupDelay, 0, 100000);
	DDP_CBIndex(pDX, IDC_SHAPEWINDOW, m_ShapeWindow, _T("ShapeWindow") );
	DDX_CBIndex(pDX, IDC_SHAPEWINDOW, m_ShapeWindow);
	DDP_Check(pDX, IDC_SHRINKWRAP, m_ShrinkWrap, _T("ShrinkWrap") );
	DDX_Check(pDX, IDC_SHRINKWRAP, m_ShrinkWrap);
	DDP_Check(pDX, IDC_DOUBLEBUFFER, m_DoubleBuffer, _T("DoubleBuffer") );
	DDX_Check(pDX, IDC_DOUBLEBUFFER, m_DoubleBuffer);
	DDP_Text(pDX, IDC_ITEMGAP, m_ItemGap, _T("ItemGap") );
	DDX_Text(pDX, IDC_ITEMGAP, m_ItemGap);
	DDV_MinMaxLong(pDX, m_ItemGap, 0, 100);
	DDP_Check(pDX, IDC_BEVEL, m_Bevel, _T("Bevel") );
	DDX_Check(pDX, IDC_BEVEL, m_Bevel);
	DDP_Text(pDX, IDC_EDIT1, m_pieLong, _T("CPieMenuCtrl") );
	DDX_Text(pDX, IDC_EDIT1, m_pieLong);
	DDP_Text(pDX, IDC_SHAPECENTERX, m_ShapeCenterX, _T("ShapeCenterX") );
	DDX_Text(pDX, IDC_SHAPECENTERX, m_ShapeCenterX);
	DDV_MinMaxLong(pDX, m_ShapeCenterX, -1, 5000);
	DDP_Text(pDX, IDC_SHAPECENTERY, m_ShapeCenterY, _T("ShapeCenterY") );
	DDX_Text(pDX, IDC_SHAPECENTERY, m_ShapeCenterY);
	DDV_MinMaxLong(pDX, m_ShapeCenterY, -1, 5000);
	DDP_Text(pDX, IDC_SHAPETRANSPARENTX, m_ShapeTransparentX, _T("ShapeTransparentX") );
	DDX_Text(pDX, IDC_SHAPETRANSPARENTX, m_ShapeTransparentX);
	DDV_MinMaxLong(pDX, m_ShapeTransparentX, -1, 5000);
	DDP_Text(pDX, IDC_SHAPETRANSPARENTY, m_ShapeTransparentY, _T("ShapeTransparentY") );
	DDX_Text(pDX, IDC_SHAPETRANSPARENTY, m_ShapeTransparentY);
	DDV_MinMaxLong(pDX, m_ShapeTransparentY, -1, 5000);
	DDP_Check(pDX, IDC_DYNAMICSHAPING, m_DynamicShaping, _T("DynamicShaping") );
	DDX_Check(pDX, IDC_DYNAMICSHAPING, m_DynamicShaping);
	DDP_Text(pDX, IDC_SLICEINSET, m_SliceInset, _T("SliceInset") );
	DDX_Text(pDX, IDC_SLICEINSET, m_SliceInset);
	DDV_MinMaxLong(pDX, m_SliceInset, 0, 1000);
	DDP_Check(pDX, IDC_SHUFFLE, m_Shuffle, _T("Shuffle") );
	DDX_Check(pDX, IDC_SHUFFLE, m_Shuffle);
	DDP_Check(pDX, IDC_SCROLLINGMOVESCURSOR, m_scrollingMovesCursor, _T("ScrollingMovesCursor") );
	DDX_Check(pDX, IDC_SCROLLINGMOVESCURSOR, m_scrollingMovesCursor);
	DDP_CBIndex(pDX, IDC_MAXSLICESINDEX, m_maxSlicesIndex, _T("MaxSlicesIndex") );
	DDX_CBIndex(pDX, IDC_MAXSLICESINDEX, m_maxSlicesIndex);
	DDP_Text(pDX, IDC_RRECTRADIUS, m_RoundRectRadius, _T("RoundRectRadius") );
	DDX_Text(pDX, IDC_RRECTRADIUS, m_RoundRectRadius);
	DDV_MinMaxLong(pDX, m_RoundRectRadius, 0, 100);
	DDP_Check(pDX, IDC_STACK, m_Stack, _T("Stack") );
	DDX_Check(pDX, IDC_STACK, m_Stack);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);

	if (pDX->m_bSaveAndValidate) {
		revision = -1;
	} else {
		// This is the only way I could figure out how to get
		// ahold of the raw CPieMenuCtrl pointer...
		m_pie = (CPieMenuCtrl *)m_pieLong;
		revision = m_pie->revision;
		OnSelchangeShapewindow();
		OnSelchangeMaxslicesindex();
	}
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage2::OnPaint

void CPieMenuPropPage2::OnPaint() 
{
	if ((m_pie != NULL) &&
		(revision != m_pie->revision)) {
		UpdateData(FALSE);
		revision = m_pie->revision;
	}
	COlePropertyPage::OnPaint();
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage2::OnInitDialog

BOOL CPieMenuPropPage2::OnInitDialog() 
{
	COlePropertyPage::OnInitDialog();
	
	m_pieText.ShowWindow(0);

	return FALSE;  // return TRUE unless you set the focus to a control
	               // EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage2::OnSelchangeShapewindow

void CPieMenuPropPage2::OnSelchangeShapewindow() 
{
	int sel = m_ShapeWindowControl.GetCurSel();
	int enabled = (sel == 6);

	m_ShapeCenterXControl.EnableWindow(enabled);
	m_ShapeCenterYControl.EnableWindow(enabled);
	m_ShapeTransparentXControl.EnableWindow(enabled);
	m_ShapeTransparentYControl.EnableWindow(enabled);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage2::OnSelchangeMaxslicesindex

void CPieMenuPropPage2::OnSelchangeMaxslicesindex() 
{
	int sel = m_maxSlicesIndexControl.GetCurSel();
	int enabled;

	if (sel == 0) {
		enabled = 1;
	} else {
		enabled = 0;
		m_Clockwise = 1;
		m_ClockwiseControl.SetCheck(1);
		m_InitialAngleControl.SetWindowText("90");
		m_InitialAngle = 90;
	}
	m_ClockwiseControl.EnableWindow(enabled);
	m_InitialAngleControl.EnableWindow(enabled);
}


/////////////////////////////////////////////////////////////////////////////
