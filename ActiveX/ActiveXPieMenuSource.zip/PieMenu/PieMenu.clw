; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CPieMenuCtrl
LastTemplate=COlePropertyPage
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "piemenu.h"
CDK=Y

ClassCount=6
Class1=CPieMenuCtrl
Class2=CPieMenuPropPage
Class3=CPieMenuInfo
Class4=CPieMenuPropPage2
Class5=CPieMenuAboutBox
Class6=CPieMenuPropPage3

ResourceCount=5
Resource1=IDD_ABOUTBOX_PIEMENU
Resource2=IDD_PROPPAGE_PIEMENU
Resource3=IDD_PROPPAGE_PIEMENU_INFO
Resource4=IDD_PROPPAGE_PIEMENU3

LastPage=0
Resource5=IDD_PROPPAGE_PIEMENU2

[CLS:CPieMenuCtrl]
Type=0
HeaderFile=PieMenuCtl.h
ImplementationFile=PieMenuCtl.cpp
Filter=W
LastObject=CPieMenuCtrl
BaseClass=COleControl
VirtualFilter=WC

[DLG:IDD_ABOUTBOX_PIEMENU]
Type=1
Class=CPieMenuAboutBox
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Control5=IDC_INFO,edit,1352730820

[DLG:IDD_PROPPAGE_PIEMENU]
Type=1
Class=CPieMenuPropPage
ControlCount=3
Control1=IDC_TEXT,edit,1352732868
Control2=IDC_STATIC,static,1342308352
Control3=IDC_EDIT2,edit,1073752064

[CLS:CPieMenuPropPage]
Type=0
HeaderFile=PieMenuPpg.h
ImplementationFile=PieMenuPpg.cpp
LastObject=IDC_BUTTON1
BaseClass=COlePropertyPage
Filter=D
VirtualFilter=idWC

[DLG:IDD_PROPPAGE_PIEMENU_INFO]
Type=1
Class=CPieMenuInfo
ControlCount=2
Control1=IDC_STATIC,static,1342308352
Control2=IDC_INFO,edit,1352665284

[CLS:CPieMenuInfo]
Type=0
HeaderFile=PieMenuInfo.h
ImplementationFile=PieMenuInfo.cpp
BaseClass=COlePropertyPage
Filter=D
VirtualFilter=idWC
LastObject=IDC_INFO

[CLS:CPieMenuPropPage2]
Type=0
HeaderFile=PieMenuPpg2.h
ImplementationFile=PieMenuPpg2.cpp
BaseClass=COlePropertyPage
Filter=D
VirtualFilter=idWC
LastObject=IDC_STACK

[CLS:CPieMenuAboutBox]
Type=0
HeaderFile=PieMenuAboutBox.h
ImplementationFile=PieMenuAboutBox.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=CPieMenuAboutBox

[CLS:CPieMenuPropPage3]
Type=0
HeaderFile=PieMenuPpg3.h
ImplementationFile=PieMenuPpg3.cpp
BaseClass=COlePropertyPage
Filter=D
LastObject=CPieMenuPropPage3
VirtualFilter=idWC

[DLG:IDD_PROPPAGE_PIEMENU2]
Type=1
Class=CPieMenuPropPage2
ControlCount=41
Control1=IDC_SHAPEWINDOW,combobox,1344339971
Control2=IDC_CLOCKWISE,button,1342242819
Control3=IDC_SHRINKWRAP,button,1342242819
Control4=IDC_DYNAMICSHAPING,button,1342242819
Control5=IDC_DOUBLEBUFFER,button,1342242819
Control6=IDC_BEVEL,button,1342242819
Control7=IDC_SCROLLINGMOVESCURSOR,button,1342242819
Control8=IDC_SHUFFLE,button,1342242819
Control9=IDC_STACK,button,1342242819
Control10=IDC_MAXSLICESINDEX,combobox,1344339971
Control11=IDC_ITEMGAP,edit,1350639744
Control12=IDC_ITEMBORDERWIDTH,edit,1350639744
Control13=IDC_BORDERWIDTH,edit,1350639744
Control14=IDC_RRECTRADIUS,edit,1350639744
Control15=IDC_SHAPECENTERX,edit,1350631552
Control16=IDC_SHAPECENTERY,edit,1350631552
Control17=IDC_SHAPETRANSPARENTX,edit,1350631552
Control18=IDC_SHAPETRANSPARENTY,edit,1350631552
Control19=IDC_MINRADIUS,edit,1350639744
Control20=IDC_INACTIVERADIUS,edit,1350639744
Control21=IDC_FIXEDRADIUS,edit,1350639744
Control22=IDC_EXTRARADIUS,edit,1350639744
Control23=IDC_INITIALANGLE,edit,1350639744
Control24=IDC_SLICEINSET,edit,1350639744
Control25=IDC_POPUPDELAY,edit,1350639744
Control26=IDC_STATIC,static,1342308354
Control27=IDC_STATIC,static,1342308354
Control28=IDC_STATIC,static,1342308354
Control29=IDC_STATIC,static,1342308354
Control30=IDC_STATIC,static,1342308354
Control31=IDC_STATIC,static,1342308354
Control32=IDC_STATIC,static,1342308354
Control33=IDC_STATIC,static,1342308354
Control34=IDC_STATIC,static,1342308354
Control35=IDC_STATIC,static,1342308354
Control36=IDC_EDIT1,edit,1073752064
Control37=IDC_STATIC,static,1342308354
Control38=IDC_STATIC,static,1342308354
Control39=IDC_STATIC,static,1342308354
Control40=IDC_STATIC,static,1342308354
Control41=IDC_STATIC,static,1342308354

[DLG:IDD_PROPPAGE_PIEMENU3]
Type=1
Class=CPieMenuPropPage3
ControlCount=4
Control1=IDC_TREE1,SysTreeView32,1350631431
Control2=IDC_STATIC0,static,1342181383
Control3=IDC_EDIT1,edit,1073752064
Control4=IDC_MODE1,combobox,1344339971

