/////////////////////////////////////////////////////////////////////////////
//
// PieMenuPpg.cpp : Implementation of the CPieMenuPropPage property page class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "PieMenuPpg.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Dynamic OLE Control Creation

IMPLEMENT_DYNCREATE(CPieMenuPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CPieMenuPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CPieMenuPropPage)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CPieMenuPropPage, "PIEMENU.PieMenuPropPage.1",
	0x87351bc4, 0x983f, 0x11cf, 0x9a, 0x4b, 0x54, 0xa4, 0xff, 0xc0, 0, 0)


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage::CPieMenuPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CPieMenuPropPage

BOOL CPieMenuPropPage::CPieMenuPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_PIEMENU_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage::CPieMenuPropPage - Constructor

CPieMenuPropPage::CPieMenuPropPage() :
	COlePropertyPage(IDD, IDS_PIEMENU_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CPieMenuPropPage)
	m_items = _T("");
	m_pieLong = 0;
	//}}AFX_DATA_INIT

	revision = -1;
	m_pie = NULL;
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage::DoDataExchange - Moves data between page and properties

void CPieMenuPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CPieMenuPropPage)
	DDX_Control(pDX, IDC_EDIT2, m_pieText);
	DDX_Control(pDX, IDC_TEXT, m_ItemText);
	DDP_Text(pDX, IDC_TEXT, m_items, _T("Items") );
	DDX_Text(pDX, IDC_TEXT, m_items);
	DDP_Text(pDX, IDC_EDIT2, m_pieLong, _T("CPieMenuCtrl") );
	DDX_Text(pDX, IDC_EDIT2, m_pieLong);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage message handlers


BOOL CPieMenuPropPage::OnInitDialog() 
{
	COlePropertyPage::OnInitDialog();

	m_pieText.ShowWindow(0);

	return FALSE;  // return TRUE unless you set the focus to a control
	               // EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage::OnPaint

void CPieMenuPropPage::OnPaint() 
{
	if ((m_pie != NULL) &&
		(revision != m_pie->revision)) {
		UpdateData(FALSE);
		revision = m_pie->revision;
	}
	COlePropertyPage::OnPaint();
}


/////////////////////////////////////////////////////////////////////////////
