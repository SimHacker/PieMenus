/////////////////////////////////////////////////////////////////////////////
//
// PieMenuLevel.cpp : Pie Menu Level
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Item Mapping.
// Rearrange the order of the items according to the number of items.
//
// The index map is indexed by the actual number of menu items, 
// and returns an index mapping for that number of items.
// It describes the number of slices to use, greater or equal to
// the number of items, so that the number of slices is a power
// of two, to keep the menu symetrical. The index mappings also
// contain maps that rearrange the menu items around the pie menu,
// for left to right, top to bottom reading order, and so their
// direction stays as stable as possible when items are added or
// deleted. 
// 
// The arguments to the IndexMapping constructor are:
//		actual number of items, number of slices,
//		storage to direction map,
//		storage to display map,
//		display to storage map.
//
// The actual number of items goes from 0 to 8.
// Index mapping is not supported for menus of more then 8 items. 
// It could be done, but bigger menus are unwieldy.
//
// The number of slices is the power of 2 greater than 
// or equal to the number of slices. The number of slices
// in the pie menu is increased to make it symetrical.
// Instead of using six slice menus in the case of 5 or 6 items,
// the number of slices is increased to 8. This was an arbitrary 
// design decision to favor 8 items instead of 6, for aesthetic 
// reasons, as well as the fact that the two-fold symetry and the 
// use of powers of two simplifies the code somewhat (but that 
// problem has been somewhat alleviated through the use of lookup 
// tables). 
//
// The storage to direction map is indexed by an item index
// within a menu group, and returns a direction enum.
//
// The storage to display map is indexed by the item 
// index within a menu group, and returns a display index,
// which enumerates the actual displayed slices, 
// starting at 0 for North, rotating clockwise, 
// to slices-1 for the last slice, 
// whatever direction it may be. For a 2 slice menu,
// the max display index 1 refers to the South item. 
// For a 4 item menu, the max display index 3 refers 
// to the West item. For an Eight item menu, the max
// display index 7 refers to the NW item. 
//
// The display to storage map is indexed by a 
// displayed slice index, and returns the index of
// the item in storage (relative to the base of the
// group of items). It returns -1 for empty slices 
// that were added to keep the number of slices even.
//


static int gStorage2Direction1[] = {
					kNorth
};

static int gStorage2Direction2[] = {
					kNorth, 
					kSouth
};

static int gStorage2Direction3[] = {
					kNorth, 
				kWest,	kEast,
					kEmpty
};

static int gStorage2Direction4[] = {
					kNorth,
				kWest,	kEast, 
					kSouth
};

static int gStorage2Direction5[] = {
					kNorth,
			kNorthWest,	kNorthEast,
			kWest,			kEast,
				kEmpty,	kEmpty,
					kEmpty
};

static int gStorage2Direction6[] = {
					kNorth,
			kNorthWest,	kNorthEast,
			kWest,			kEast,
			kSouthWest,	kEmpty,
					kEmpty
};

static int gStorage2Direction7[] = {
					kNorth,
			kNorthWest,	kNorthEast,
			kWest,			kEast,
			kSouthWest,	kSouthEast,
					kEmpty
};

static int gStorage2Direction8[] = {
					kNorth,
			kNorthWest,	kNorthEast,
			kWest,			kEast,
			kSouthWest,	kSouthEast,
					kSouth
};


CPieMenuLevel::IndexMapping CPieMenuLevel::indexMap[9] = {
	CPieMenuLevel::IndexMapping(
		0, 0,
		NULL,
		NULL,
		NULL),
	CPieMenuLevel::IndexMapping(
		1, 1,
		gStorage2Direction1,
		"\000",
		"\000"),
	CPieMenuLevel::IndexMapping(
		2, 2,
		gStorage2Direction2,
		"\000\001",
		"\000\001"),
	CPieMenuLevel::IndexMapping(
		3, 4,
		gStorage2Direction3,
		"\000\003\001",
		"\000\002\377\001"),
	CPieMenuLevel::IndexMapping(
		4, 4,
		gStorage2Direction4,
		"\000\003\001\002",
		"\000\002\003\001"),
	CPieMenuLevel::IndexMapping(
		5, 8,
		gStorage2Direction5,
		"\000\007\001\006\002",
		"\000\002\004\377\377\377\003\001"),
	CPieMenuLevel::IndexMapping(
		6, 8,
		gStorage2Direction6,
		"\000\007\001\006\002\005",
		"\000\002\004\377\377\005\003\001"),
	CPieMenuLevel::IndexMapping(
		7, 8,
		gStorage2Direction7,
		"\000\007\001\006\002\005\003",
		"\000\002\004\006\377\005\003\001"),
	CPieMenuLevel::IndexMapping(
		8, 8,
		gStorage2Direction8,
		"\000\007\001\006\002\005\003\004",
		"\000\002\004\006\007\005\003\001")
};


/////////////////////////////////////////////////////////////////////////////
// CPieMenuLevel


CPieMenuLevel::~CPieMenuLevel()
{
	if (popupWindow != NULL) {
		::DestroyWindow(popupWindow);
	}
	if (windowRegion != NULL) {
		::DeleteObject(windowRegion);
	}
	if (entries != NULL) {
		delete [] entries;
	}
}


// This pie menu tracking code determines the slice the cursor 
// is in by representing slice edge angles as (quadrant, slope) 
// pairs that can be quickly computed and compared. 
//
// The slope is defined such that it is greater than or equal to zero,
// less than infinity, and increasing counter-clockwise around the menu. 
// Each of the four quadrants encompasses one range of slope.
//
//                 Y
//               ^
//               |     x>0, y>=0
//  x<=0, y>0 <--+       y/x
//    -x/y       |        ^
//        quad 1 | quad 0 |     X
// -----+--------+--------+----> 
//      | quad 2 | quad 3
//      V        |      -x/y
//   x<0, y<=0   +--> x>=0, y<0
//     y/x       |
//               |
// 
// The quadrants and slopes of the item edges are all precalculated,
// during menu layout.
// The quadrant and slope of the cursor must be calculated frequently
// during menu tracking, so we just calculate the numerator and
// denominator of the slope, and avoid an unnecessary division.
// Instead of calculating "slope = numerator / denominator" then
// testing "slope < it->slope", every time the cursor moves, we can
// just test "numerator < (denominator * it->slope)".
// Vaughan Pratt suggested that optimization.
//
// This algorithm works in a right-side-up coordinate space, but the final
// results are tranformed into X-windows's up-side-down coordinate system 
// by subtracting the y values from the window height. 


void CPieMenuLevel::CalcQuadNumDen(float x, 
								   float y, 
								   long &quad, 
								   float &num, 
								   float &den)
{
    if (y > 0) {
		quad = (x > 0) ? 0 : 1;
	} else if (y < 0) {
		quad = (x < 0) ? 2 : 3;
	} else {
		quad = (x > 0) ? 0 : 2;
	}

    if (quad & 1) {
		num = (float)fabs(x);
		den = (float)fabs(y);
    } else {
		num = (float)fabs(y);
		den = (float)fabs(x);
    }
}


// Returns 1 if cursor(quad1,num1,den1) is counter clockwise of edge2(quad2,slope2).
int CPieMenuLevel::CompareEdges(long quad1,
								float num1,
								float den1,
								long quad2,
								float slope2)
{
	int ccw;

	// Legend: c = cursor, e = edge
	//  <cursor quad>,<edge quad>
	//        quad 1 | quad 0
	//        -------+-------
	//        quad 2 | quad 3

	// Set order = 1, if shortest direction from edge to cursor is ccw
	switch ((quad1 - quad2) & 3) {

	case 0:
		//			0,0		 1,1	 2,2	 3,3
		//			 |ce	ce|		  |		  |
		//		   --+--	--+--	--+--	--+--
		//			 |		  |		ce|		  |ce
		// slope >= it->slope
		ccw = ((float)num1 >= (float)(den1 * slope2));
		break;

	case 1:
		//			1,0		 2,1	 3,2	 0,3
		//			c|e		 e|		  |		  |c
		//		   --+--	--+--	--+--	--+--
		//			 |		 c|		 e|c	  |e
		ccw = 1;
	break;

	case 2:
		//			2,0		 3,1	 0,2	 1,3
		//			 |e		 e|		  |c	 c|
		//		   --+--	--+--	--+--	--+--	
		//			c|		  |c	 e|		  |e
		// slope < it->slope
		ccw = ((float)num1 < (float)(den1 * slope2));
		break;

	case 3:
		//			3,0		 0,1	 1,2	 2,3
		//			 |e		 e|c	 c|		  |
		//		   --+--	--+--	--+--	--+--	
		//			 |c		  |		 e|		 c|e
		ccw = 0;
		break;

	} // switch

	return ccw;
}


int CPieMenuLevel::CalcPieMenuItem(long x, 
								   long y)
{
	long i, phase, quadrant;
	float numerator, denominator;
	int result = -1;
	CPieMenuEntry *it;
	int inactiveRadius2 = 
		pie->inactiveRadius * 
		pie->inactiveRadius;

	// By default the active group item is the first slice.
	// This is changed if the cursor is in a locational group.
	activeGroupItem = firstSlice;

	// If there are no menu items,
	// or we are within the inactive region in the menu center,
	// then there is no item selected.
	if ((numEntries == 0) ||
		(((x * x) + (y * y)) <
		 inactiveRadius2)) {
		activeItem = -1;
		return activeItem;
	}

	// Hit test against the locational menu items in window coordinates.
	long winx = x + popupCenterX;
	long winy = popupCenterY - y;
	for (i = beginningEntry; 
		 i < endingEntry; 
		 i++) {
		it = entries[i];

		if (it->locational) {
			// This item is locational, see if it contains the cursor.
			int fringe = 1;
			int x0 = it->x - fringe;
			int y0 = it->y - fringe;
			int x1 = it->x + it->width + fringe;
			int y1 = it->y + it->height + fringe;
			if ((winx >= x0) &&
				(winx < x1) &&
				(winy >= y0) &&
				(winy < y1)) {

				// Figure out the group we're in.
				for (activeGroupItem = i;
					 activeGroupItem > 0;
					 activeGroupItem--) {
					if (entries[activeGroupItem]->groupWidth != 0) {
						break;
					} // if
				} // for

				activeItem = i;
				return activeItem;
			} // if
		} // if (it->locational)
	} // for i

	// If the cursor's not over a label, 
	// but over a group of locational items, 
	// activate the group, but don't select any items.
	for (phase = 0; phase <= 1; phase++) {
		int from, to, step;

		if (phase == 0) {
			from = firstSlice - 1;
			to = -1;
			step = -1;
		} else {
			from = lastSlice;
			to = numEntries;
			step = 1;
		} // if

		for (i = from; 
			 i != to;
			 i += step) {
			CPieMenuEntry *it = entries[i];

			if ((it->locational != 0) &&
				(it->groupWidth != 0)) {
				int gw = it->groupWidth;
				int gh = it->groupHeight;
				int gx = it->groupX;
				int gy = it->groupY;

				if ((gx <= x) &&
					(gy <= y) &&
					(x < (gx + gw)) &&
					(y < (gy + gh))) {
					activeGroupItem = i;
					activeItem = -1;
					return activeItem;
				} // if
			} // if
		} // for i
	} // for phase

	// If there is only one slice in this level, 
	// and none of the locational items were hit,
	// then select first slice, the only non-locational item.
	if (slices == 1) {
		activeGroupItem = firstSlice;
		activeItem = firstSlice;
		return activeItem;
	}

	// Check to see if the cursor is in one of the pie slices.
	// Calculate the quadrant, slope numerator, and slope denominator of
	// the cursor slope, to be used for comparisons.
	CalcQuadNumDen((float)x, (float)y, 
				   quadrant, numerator, denominator);

	for (i = firstSlice; 
		 i < lastSlice; 
		 i++) {
		it = entries[i];

		activeGroupItem = firstSlice;

		// If the cursor is ccw of edge1, and cw of edge2,
		// then we're in the slice. 
		if (!it->locational &&
			(CompareEdges(
				quadrant, numerator, denominator,
				it->quadrant1, it->slope1) != 
			 clockwise) &&
			(CompareEdges(
				quadrant, numerator, denominator,
				it->quadrant2, it->slope2) ==
			 clockwise)) {
			result = i;
			break;
		}
	}

	if (result >= numEntries) {
		result = numEntries - 1;
	} // if

	activeItem = result;
	return activeItem;
}


void CPieMenuLevel::Paint(HDC dcWindow,
						  GState *g)
{
	HDC dc = dcWindow;
	HBITMAP buffer = NULL;
	HBITMAP lastBitmap = NULL;
	int shape = pie->shapeWindow;
	
	if (pie->doubleBuffer) {
		dc = ::CreateCompatibleDC(dcWindow);
		buffer = ::CreateCompatibleBitmap(dcWindow,
										  popupWidth,
										  popupHeight);
		lastBitmap = SelectBitmap(dc, buffer);
	} // if

	HPEN foregroundPen = g->GetForegroundPen();
	HPEN backgroundPen = g->GetBackgroundPen();
	HPEN lastHPen = (HPEN)::SelectObject(dc, foregroundPen);

	HBRUSH foregroundBrush = g->GetForegroundBrush();
	HBRUSH backgroundBrush = g->GetBackgroundBrush();
	HBRUSH lastHBrush = (HBRUSH)::SelectObject(dc, backgroundBrush);

	COLORREF lastBackColor = ::SetBkColor(dc, pie->GetBackColor());

	long lastBkMode = ::SetBkMode(dc, TRANSPARENT);

	HFONT lastFont = g->GetLastFont(dc);

	// Draw the background.
	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.right = popupWidth;
	rect.bottom = popupHeight;

	short bgType = pie->backgroundPicture.GetType();
	if ((bgType != PICTYPE_NONE) &&
		(bgType != PICTYPE_UNINITIALIZED)) {
		HRGN reg;

		if (((shape == kShapePicture) ||
			 (shape == kShapeAsshole)) &&
			((reg = pie->GetShapeRegion()) != NULL)) {

			::FillRect(dc, 
					   &rect, 
					   backgroundBrush);

			::OffsetRgn(reg,
						popupCenterX - shapeHotX,
						popupCenterY - shapeHotY);
			::SelectClipRgn(dc, reg);

			rect.left = popupCenterX - shapeHotX;
			rect.top = popupCenterY - shapeHotY;
			rect.right = rect.left + shapeWidth;
			rect.bottom = rect.top + shapeHeight;
			pie->backgroundPicture.Render(CDC::FromHandle(dc), 
										  &rect, 
										  &rect);

			::SelectClipRgn(dc, windowRegion);
			::DeleteObject(reg);
		} else {
			pie->backgroundPicture.Render(CDC::FromHandle(dc), 
										  &rect, 
										  &rect);
		} // if
	} else {
		::FillRect(dc, 
				   &rect, 
				   backgroundBrush);
	} // if

	if (!pie->bevel) {
		// This is the special pen to stroke the inside of the region.
		HPEN hPen = g->GetForegroundFramePen();
		::SelectObject(dc, hPen);

		if (windowRegion == NULL) {
			RECT r = rect;
			r.right--;
			r.bottom--;
			::FrameRect(dc, 
						&r, 
						foregroundBrush);
		} else {
			::FrameRgn(dc, 
					   windowRegion, 
					   foregroundBrush, 
					   1, 
					   1);
		} // if
		
		::SelectObject(dc, foregroundPen);
	} // if

	if ((shape != kShapeRectangular) &&
		(shape != kShapePunched) &&
		(pie->dynamicShaping != 0) &&
		((pie->buttonsDown != 0) ||
		 (child != NULL)) &&
		(activeItem != -1)) {

		// Only the single item visible. 

		entries[activeItem]->Paint(dc, g, 1);

	} else {
		
		// Draw all the items. 

		long i;
		for (i = beginningEntry; 
			 i < endingEntry;
			 i++) {
			entries[i]->Paint(dc, g, (i == activeItem));
		} // for i

		// Draw lines between slices in foreground pen.
		::SelectObject(dc, foregroundPen);
		::SelectObject(dc, foregroundBrush);
		PaintSlices(dc);

	} // if

	// If drawing beveled edges, 
	// paint the bevel with dark and light pens.
	if (pie->bevel) {
		HPEN darkPen = g->GetDarkPen();
		HPEN lightPen = g->GetLightPen();

		PaintBevel(dc,
				   g,
				   popupWidth, popupHeight, 
				   windowRegion, 
				   darkPen,
				   lightPen);
	} // if bevel

	::SetBkMode(dc, lastBkMode);
	::SelectObject(dc, lastFont);
	::SelectObject(dc, lastHPen);
	::SelectObject(dc, lastHBrush);

	// If double buffered, blit the buffer to the window,
	// and clean up the buffer. 
	if (pie->doubleBuffer) {
		BitBlt(dcWindow,
			   0, 0,
			   popupWidth, popupHeight,
			   dc,
			   0, 0,
			   SRCCOPY);

		SelectBitmap(dc, lastBitmap);
		::DeleteDC(dc);
		::DeleteObject(buffer);
	} // if doubleBuffer
}


void CPieMenuLevel::PaintSlices(HDC dc)
{
	int i;
	int shape = pie->shapeWindow;

	// Draw the slice lines around the menu center,
	// if appropriate.
	switch (shape) {

	case kShapeRectangular:
	case kShapeMinimal:
	case kShapeRound:
	case kShapePunched:
		{ // scope
			// Don't bother if only 1 slice.
			if (slices > 1) {
				long r = labelRadius;

				// Calculate the angular width of each slice.
				float twist = 
					((float)2.0 * (float)PI) / (float)slices;

				// Twist the other way if clockwise.
				if (clockwise) {
					twist = -twist;
				} // if

				// Point ang towards the center of the first slice.
				float ang = 
					(float)DEG_TO_RAD(initialAngle) - 
					(twist / (float)2.0);

				int lastEmpty = 
					display2storage
						? (display2storage[slices - 1] == -1)
						: 0;

				for (i = 0; 
					 i < slices; 
					 i++) {
					int drawLine = 1;
					int curEmpty =
						display2storage
							? (display2storage[i] == -1)
							: 0;

					if (curEmpty) {
						if (!lastEmpty) {
							drawLine = 1;
						} else {
							drawLine = 0;
						} // if
						lastEmpty = 1;
					} else {
						drawLine = 1;
						lastEmpty = 0;
					} // if

					if (drawLine) {
						float cosAngle = (float)cos(ang);
						float sinAngle = (float)-sin(ang);
						int x1 = (long)
							(popupCenterX +
							 (cosAngle * 
							  pie->inactiveRadius) +
							 (float)-0.5);
						int y1 = (long)
							(popupCenterY +
							 (sinAngle * 
							  pie->inactiveRadius) +
							 (float)-0.5);
						int x2 = (long)
							(popupCenterX +
							 (cosAngle * 
							  (labelRadius - 
							   pie->sliceInset)) + 
							 (float)-0.5);
						int y2 = (long)
							(popupCenterY + 
							 (sinAngle * 
							  (labelRadius - 
							   pie->sliceInset)) +
							 (float)-0.5);

						::MoveToEx(dc, x1, y1, NULL);
						::LineTo(dc, x2, y2);
					
					} // if (drawLine)

					// Twist around to the next slice.
					ang += twist;

				} // for i
			} // if (numEntries > 1)
		} // scope
		break;

	} // switch
}


void CPieMenuLevel::PaintBevel(HDC dc,
							   GState *g,
							   int width, 
							   int height,
							   HRGN region,
							   HPEN darkPen,
							   HPEN lightPen)
{
	char mem[sizeof(BITMAPINFO) + sizeof(RGBQUAD)*(256-1)];
	BITMAPINFO &bmi = *((BITMAPINFO*)mem);
	BITMAPINFOHEADER &bmih = bmi.bmiHeader;
	unsigned char *baseAddr = NULL;
	int rowBytes = 0;
	int fatHeight = height + 2;
	int fatWidth = width + 2;
	int depth;

	bmih.biSize = sizeof(bmih);
	bmih.biWidth = fatWidth;
	bmih.biHeight = -fatHeight; // top down!
	bmih.biPlanes = 1;
	bmih.biBitCount = 8;
	bmih.biCompression = BI_RGB;
	bmih.biSizeImage = 0;
	bmih.biXPelsPerMeter = 0;
	bmih.biYPelsPerMeter = 0;
	bmih.biClrUsed = 0;
	bmih.biClrImportant = 0;

	int i;
	LPPALETTEENTRY pal = (LPPALETTEENTRY)&bmi.bmiColors[0];

	for (i = 0; i < 256; i++) {
		pal[i].peRed = pal[i].peGreen = pal[i].peBlue = i;
		pal[i].peFlags = 0;
	} // for

	HDC dibdc = ::CreateCompatibleDC(dc);
	HBITMAP dib = ::CreateDIBSection(dibdc,
									 (BITMAPINFO*)&bmih, 
									 DIB_RGB_COLORS, 
									 (void **)&baseAddr, 
									 NULL, 
									 0);

	rowBytes = (bmih.biWidth + 3) & ~3;

	memset(baseAddr, 0, rowBytes * fatHeight);

	HBITMAP lastBitmap = 
		(HBITMAP)SelectObject(dibdc, dib);

	::SetWindowOrgEx(dibdc, -1, -1, NULL);

	HBRUSH blackBrush = 
		(HBRUSH)::GetStockObject(BLACK_BRUSH);
	HBRUSH whiteBrush = 
		(HBRUSH)::GetStockObject(WHITE_BRUSH);
	HBRUSH blackPen = 
		(HBRUSH)::GetStockObject(BLACK_PEN);
	HBRUSH whitePen = 
		(HBRUSH)::GetStockObject(WHITE_PEN);

	HFONT lastFont = g->GetLastFont(dibdc);
	COLORREF lastTextColor =
		::SetTextColor(dibdc, RGB(0, 0, 0));
	long lastBkMode =
	::SetBkMode(dibdc, TRANSPARENT);

	depth = 32;

	HBRUSH grayBrush = 
		pie->CreateABrush(
			RGB(depth, depth, depth));
	HPEN grayPen = 
		pie->CreateAPen(
			RGB(depth, depth, depth));

	HBRUSH lastBrush = 
		(HBRUSH)::SelectObject(dibdc, grayBrush);
	HPEN lastPen = 
		(HPEN)::SelectObject(dibdc, grayPen);

	if (region == NULL) {
		RECT r;
		r.left = r.top = 0;
		r.right = width - 1;
		r.bottom = height - 1;
		::FillRect(dibdc,
				   &r,
				   grayBrush);
	} else {
		::FillRgn(dibdc,
				  region,
				  grayBrush);
	} // if

	int isDynamicMenu =
		pie->dynamicShaping &&
		((pie->buttonsDown != 0) ||
		 (child != NULL));

	if ((!isDynamicMenu) ||
		(activeItem == -1)) {

		// Draw all the item groups. 

		int phase;
		for (phase = 0; phase <= 1; phase++) {
			int i, from, to, step, coveredGroups;

			if (phase == 0) {
//				from = firstSlice - 1;
//				to = beginningEntry - 1;
//				step = -1;
//				from = beginningEntry;
				from = 0;
				to = firstSlice;
				step = 1;
				coveredGroups = groupsStackedAbove;
			} else {
//				from = lastSlice;
//				to = endingEntry;
//				step = 1;
//				from = endingEntry - 1;
				from = numEntries - 1;
				to = lastSlice - 1;
				step = -1;
				coveredGroups = groupsStackedBelow;
			} // if

			depth = 128;

			for (i = from; 
				 i != to;
				 i += step) {
				CPieMenuEntry *it = entries[i];

				if ((it->locational != 0) &&
					(it->groupWidth != 0)) {

					int gw = it->groupWidth;
					int gh = it->groupHeight;
					int gx = popupCenterX + it->groupX;
					int gy = popupCenterY - (it->groupY + gh);
					int rrectrad = pie->roundRectRadius;

					gx -= 1;
					gy -= 1;

					// Step height so each group away from
					// center is lower, so bevels look nice.
					depth++;

					HBRUSH depthBrush = 
						pie->CreateABrush(
							RGB(depth, depth, depth));

					HRGN rgn = 
						::CreateRoundRectRgn(
							gx,
							gy,
							gx + gw,
							gy + gh,
							rrectrad, rrectrad);

					::FillRgn(
						dibdc,
						rgn,
						depthBrush);

					::DeleteObject(rgn);
					::DeleteObject(depthBrush);

				} // if
			} // for i
		} // for phase
	} // if

	::SetBkMode(dibdc, lastBkMode);
	::SetTextColor(dibdc, lastTextColor);
	::SelectObject(dibdc, lastFont);
	::SelectObject(dibdc, lastBrush);
	::SelectObject(dibdc, lastPen);
	::DeleteObject(grayBrush);
	::DeleteObject(grayPen);
	::SelectObject(dibdc, lastBitmap);
	::DeleteDC(dibdc);

	// For now...
	HPEN medDarkPen = darkPen;
	HPEN medLightPen = lightPen;

	PaintBevelFromDepthMap(
		dc,
		baseAddr,
		fatWidth,
		fatHeight,
		rowBytes,
		darkPen,
		medDarkPen,
		medLightPen,
		lightPen);

	::DeleteObject(dib);
}


// Scan over the pixels of an 8 bit dib depth map,
// and draw beveled edges in a dc, in the given colors.
// By Don Hopkins.
void CPieMenuLevel::PaintBevelFromDepthMap(HDC dc,
										   unsigned char *baseAddr,
											int fatWidth,
											int fatHeight,
											int rowBytes,
											HPEN darkPen,
											HPEN medDarkPen,
											HPEN medLightPen,
											HPEN lightPen)
{
	// Optimize adjacent points of the same color into lines. 
	int outputCol = 0;
	int outputPending = 0;
	HPEN outputPen = NULL;
	HPEN pen = NULL;

	// The image is offset by 1,1 and 2,2 bigger,
	// so we don't have to worry about the edge condition in the loop.
	int width = fatWidth - 2;
	int height = fatHeight - 2;
	unsigned char *from = baseAddr + 1 + rowBytes;

	// Scan over the pixels of the image,
	// and highlight and lowlight the edges.
	int x, y;
	for (y = 0; 
		 y < height; 
		 y++, from += rowBytes) {
		int nw, n, ne, w, c, e, sw, s, se;

		// Prime the pump.
		n = from[-rowBytes - 1];
		ne = from[-rowBytes];
		c = from[-1];
		e = from[0];
		s = from[rowBytes];
		se = from[rowBytes + 1];

		for (x = 0; 
			 x < width; 
			 x++) {

			// Pump the window.
			nw = n; n = ne;
			ne = from[x - rowBytes + 1];
			w = c; c = e;
			e = from[x + 1];
			sw = s; s = se;
			se = from[x + rowBytes + 1];

			if ((nw < c) ||
				(n < c) ||
				(w < c)) {

				pen = lightPen;
			
			} else if ((se < c) ||
					   (s < c) ||
					   (e < c)) {
			
				pen = darkPen;
			
			} else if (ne < c) {
			
				pen = medLightPen;
			
			} else if (sw < c) {
			
				pen = medDarkPen;
			
			} else {

				pen = NULL;

			}
			
			// The following hair optimizes adjacent 
			// points of the same color into a line.


			if (pen != NULL) {

				if (outputPending) {
				
					if ((pen == outputPen) &&
						(x == outputCol)) {
						outputCol++;
					} else {
						::LineTo(dc, outputCol, y);
						goto buffer_output;
					} // if
				
				} else {

buffer_output:
					if (outputPen != pen) {
						::SelectObject(dc, pen);
					}
					::MoveToEx(dc, x, y, NULL);
					outputCol = x + 1;
					outputPen = pen;
					outputPending = 1;
			
				} // if (outputPending)
			} // if (pen != NULL)
		} // for x

		if (outputPending) {

			::LineTo(dc, outputCol, y);
			outputPending = 0;

		} // if
	} // for y
}


CPieMenuLevel *CPieMenuLevel::GetLevel(int i)
{
	if (i <= 0) {
		return this;
	} else {
		if (next == NULL) {
			return NULL;
		} else {
			return next->GetLevel(i - 1);
		} // if
	} // if
}


void CPieMenuLevel::SetNeedsLayout()
{
	long i;

	levelNeedsLayout = 1;

	for (i = 0; i < numEntries; i++) {
		CPieMenuLevel *subLev = entries[i]->subLevel;
		if (subLev != NULL) {
			subLev->SetNeedsLayout();
		} // if
	} // for
}


void CPieMenuLevel::Layout()
{
	GState g(pie);

	if (!pie->pieNeedsLayout &&
		!levelNeedsLayout) {
		return;
	} // if

	levelNeedsLayout = 0;

	long i, radius;
	float ang = (float)0.0;
	CPieMenuEntry *it, *last;
	HDC dc = ::GetDC(pie->m_hWnd);
	HFONT lastFont = g.GetLastFont(dc);
	int maxSlices = pie->maxSlices;

	// User specified initial angle or clockwise flags
	// override fixed maxslices and enable normal circular layout.
	if (flags &
		(kLevelLayoutInitialAngle |
		 kLevelLayoutClockwise)) {
		maxSlices = 0;
	}

	// Default values, might be overridden by stacked groups.
	beginningEntry = 0;
	endingEntry = numEntries;
	groupsStackedAbove = 0;
	groupsStackedBelow = 0;

	// Initialize the entries to the default values.
	for (i = 0;
		 i < numEntries;
		 i++) {
		CPieMenuEntry *it = 
			entries[i];

		it->x = 0;
		it->y = 0;
		it->labelX = 0;
		it->labelY = 0;
		it->groupX = 0;
		it->groupY = 0;
		it->groupWidth = 0;
		it->groupHeight = 0;
		it->groupItems = 0;
		it->groupSlices = 0;
	} // for

	// If maxSlices is non-zero, then only allow that many different slices.
	if (maxSlices == 0) {

		topItem = 0;
		slices = numEntries;
		firstSlice = 0;
		lastSlice = numEntries;
		storage2direction = NULL;
		storage2display = NULL;
		display2storage = NULL;

	} else {
		// Enforce some policies to simplify what the code
		// has to deal with. Start layout with the north slice,
		// continuing around clockwise.
		initialAngle = 90;
		clockwise = 1;

		// Force topItem to have a reasonable value.
		// Must not be out of range.
		if (topItem < 0) {
			topItem = 0;
		}
		if (topItem >= numEntries) {
			topItem = numEntries - 1;
		}
		// Must be a multiple of maxSlices.
		topItem -= topItem % maxSlices;

		// Figure out the first and the last slices,
		// and the number of slices. 
		firstSlice = topItem;
		lastSlice = min(numEntries, firstSlice + maxSlices);
		slices = lastSlice - firstSlice;

		// Remember actual number of slices used, in case we increase
		// the number of slices with by adding one unused slice,
		// to make the number of slices even.
		slicesUsed = slices;

		// We only know how to do index mapping for 8 or fewer slices.
		if (slicesUsed <= 8) {
			// Set up the index mappings, and the effective number of slices.
			// What is index mapping, you may ask?
			// It's purpose is to adjust the number of slices 
			// so that it's always even, and map the order of
			// the items to different directions, so they have  
			// left to right, top to bottom reading order,
			// instead of circular. When items are appended
			// to the menu, they appear from left to right 
			// at the bottom, so that the directions of the 
			// original items don't change much.
			// The index map translates between display 
			// and storage indices. 
			storage2direction = indexMap[slicesUsed].storage2direction;
			storage2display = indexMap[slicesUsed].storage2display;
			display2storage = indexMap[slicesUsed].display2storage;
			slices = indexMap[slicesUsed].slices;
		}
	}

	// Calculate the subtend, angle, cosine, sine, quadrant, slope,
	// and size of each menu item.
	if (numEntries > 0) {

		// Calculate the angular width of each slice.
		float twist = 
			((float)2.0 * (float)PI) / (float)slices;

		// Twist the other way if clockwise.
		if (clockwise) {
			twist = -twist;
		} // if

		// First just calculate the size of the locational items.
		for (i = 0; i < numEntries; i++) {
			it = entries[i];

			// If this menu item is above or below the directional items.
			// If we're at the top, isLocational is 1,
			// if we're at the bottom, isLocational is 0.
			int isLocational = 
				(i < firstSlice) 
					? -1 
					: (i >= lastSlice)
						? 1
						: 0;

			if (isLocational) {
				// Figure out the angle towards the item.
				float upOrDownAngle =
					(isLocational == -1)
						? ((float)0.5 * (float)PI)
						: ((float)-0.5 * (float)PI);

				// Twist backwards half a slice.
				upOrDownAngle -= twist / (float)2.0;

				// Measure the item.
				it->Measure(
					upOrDownAngle,
					twist,
					1, // isLocational is true
					dc);
			} // if
		} // for

		// Point ang towards the center of the first slice.
		ang = (float)DEG_TO_RAD(initialAngle);

		// Twist backwards half a slice.
		ang -= twist / (float)2.0;

		// Now calculate the size and other properties of the pie items.
		for (i = 0; i < slices; i++) {
			// If index mapping is going on, then figure out
			// the storage index (item) from the display 
			// index (slice).
			int iMapped =
				display2storage
					? display2storage[i]
					: i;

			// If iMapped is -1, then the slice is empty. 
			if (iMapped != -1) {
				// Add topItem to get the item index. 
				iMapped += topItem;

				entries[iMapped]->Measure(
					ang,
					twist,
					0, // isLocational is false
 					dc);
			} // if

			// Twist to the next slice.
			ang += twist;
		} // for i
	} // if

	radius = fixedRadius;
	if (radius <= 0) {
		radius = pie->minRadius;
		if (numEntries > 1) {
			// Increase the radius until no two labels overlap.
			// Start by wrapping last arond to the end of the 
			// circular menu.

			// If index mapping is going on, then figure out
			// the storage index (item) from the display 
			// index (slice).
			int lastIndex = slices - 1;
			int lastIndexMapped =
				display2storage
					? display2storage[lastIndex]
					: lastIndex;

			// Careful not to test if the item overlaps itself,
			// in case there's only one slice!
			if ((slices == 1) ||
				(lastIndexMapped == -1)) {
				last = NULL;
			} else {
				last = entries[lastIndexMapped + topItem];
			}

			for (i = 0; i < slices; i++) {
				// Shuffle the index and measure the circular items.

				// If index mapping is going on, then figure out
				// the storage index (item) from the display 
				// index (slice).
				int iMapped = 
					display2storage
						? display2storage[i]
						: i;

				// The d2s index map contains -1 for empty slices,
				// since there can be more directions than items.
				if (iMapped == -1) {
					// Skip over empty slices.
					it = NULL;
				} else {
					// Measure occupied slices.
					it = entries[iMapped + topItem];
				} // if

				// Since some slice might be empty, there is no
				// possibility of overlapping with an adjacent empty
				// slices, and nothing to do between two empty slices.

				// If this and the last slice were occupied,
				// then make sure they don't overlap,
				// by pushing the radius out till they don't.
				if (it && last) {
					// Loop testing for overlap until they don't.
					while (1) {
						// Lay them out at the current radius.
						it->Layout(radius);
						last->Layout(radius);

						// Test for overlap. Takes two to tango.
						if (!it->Overlaps(last)) {
							// They are far enough out, so move on.
							break;
						} // if
						
						// Push the menu radius out a step and try again.
						radius++; // *Click*!

					} // while 1
				} // if (it & last)
				
				// Loop on to next menu item.
				last = it; // *Chunk*!
			} // for i
		} // if numEntries > 1

		// Puff it up a bit extra.
		radius += pie->extraRadius; // *Pffff*!
	} // if radius

	// The envelope, please.
	labelRadius = radius;

	// Finally position all the menu labels at the same radius.
	// Figure out the bounding box of the labels, and the max radius.
	long minx = -radius;
	long miny = -radius;
	long maxx = radius;
	long maxy = radius;

	maxRadius = 0;

	// Three phases of layout:
	// First loop forward and place the circular items.
	// Then loop backward and place the locational items above.
	// Finally loop forward and place the locational items below.
	int phase;
	for (phase = 0; phase < 3; phase++) {
		int from, to, step;

		long groupVisible = 1;

		// Set up for one phase of the real loop.
		switch (phase) {
		case 0:
			// First loop forward and place the circular items.
			from = firstSlice;
			to = lastSlice;
			step = 1;
			break;
		case 1:
			// Then loop backward and place the locational items above.
			from = firstSlice - 1;
			to = -1;
			step = -1;
			break;
		case 2:
			// Finally loop forward and place the locational items below.
			from = lastSlice;
			to = numEntries;
			step = 1;
			break;
		} // switch (phase)

		int lasty = 0;

		// Keep track of bounding box of scrolled groups of items.
		int minGroupX = 10000;
		int minGroupY = 10000;
		int maxGroupX = -10000;
		int maxGroupY = -10000;

		// Perform one phase of the loop,
		// looping over some (or none) of the items,
		// and laying them out appropriately.
		for (i = from;
			 i != to;
			 i += step) {
			it = entries[i];

			// Lay the item out at the final radius.
			it->Layout(radius);

			long border = pie->itemBorderWidth;
			long gap = pie->itemGap;
			int fluff = pie->borderWidth;
			long itw = it->width;
			long ith = it->height;
			long itx0, ity0, itx1, ity1;
			long direction = 0;

			// Figure out where to place the item.

			switch (phase) {

			case 0:
				// Place circular items around.
				{
					it->visible = 1;

					// i loops forward from firstSlice to (firstSlice - 1)
					itx0 = it->x;
					ity0 = it->y;
					itx1 = itx0 + itw;
					ity1 = ity0 + ith;

					// Figure out the direction.
					if (storage2direction != NULL) {
						direction = storage2direction[i];
					} else {
						direction = kOther;
					}

					// Update group bounding box.
					if (itx0 < minGroupX) {
						minGroupX = itx0;
					}
					if (ity0 < minGroupY) {
						minGroupY = ity0;
					}
					if (itx1 > maxGroupX) {
						maxGroupX = itx1;
					}
					if (ity1 > maxGroupY) {
						maxGroupY = ity1;
					}

					// If we've finished a group, set the bounding box.
					if (i == (lastSlice - 1)) {
						// Looping forward and reached last of group.
						// Set the group box of the first item of this group.

						// Turning the following off for the pie part.
#if 1
						// Adjust the bounding box to be horizontally symetrical.
						if (-minGroupX > maxGroupX) {
							maxGroupX = -minGroupX;
						} else if (maxGroupX > -minGroupX) {
							minGroupX = -maxGroupX;
						}

						if (minx > minGroupX) {
							minx = minGroupX;
						}
						if (maxx < maxGroupX) {
							maxx = maxGroupX;
						}
#endif

						CPieMenuEntry *it1 =
							entries[firstSlice];

						it1->groupX = 
							minGroupX - 
							(border + fluff);
						it1->groupY = 
							minGroupY - 
							(border + fluff);
						it1->groupWidth = 
							(maxGroupX + fluff + border + 1) - 
							it->groupX;
						it1->groupHeight = 
							(maxGroupY + fluff + border + 1) -
							it->groupY;
						it1->groupItems = 
							lastSlice - firstSlice;
						it1->groupSlices =
							slices;
						minGroupX = 10000;
						minGroupY = 10000;
						maxGroupX = -10000;
						maxGroupY = -10000;
					} // if

				} // scope
				break;
			
			case 1:
				// Place locational items above.
				if (groupVisible == 0) {
					it->locational = 1;
					it->visible = 0;
					it->x = 0;
					it->y = 0;
				} else {
					it->visible = groupVisible;

					// i loops backward from (firstSlice - 1) to 0

					// All groups above have maxSlices slices,
					// so this case is simpler.
					int ii = i % maxSlices;

					// Figure out the direction.
					// Use the storage2direction map apropriate for
					// the maxSlices number of slices. 
					direction = 
						indexMap[maxSlices].storage2direction[ii];

					if ((direction == kNorth) ||
						(direction == kSouth)) {
						// 1 item: case 0
						// 2 items: case 0 and 1
						// 4 items: case 0 and 3
						// 8 items: case 0 and 7
						itx0 = 0 - (itw / 2);
						ity0 = maxy + border + gap + border;

						// Leave vertical space between groups.
						if (direction == kSouth) {
							ity0 += fluff + border + 1;

							// fudge
							if (i == firstSlice - 1) {
								ity0 -= 2;
							}
						}
					} else {
						if ((direction == kNorthEast) ||
							(direction == kEast) ||
							(direction == kSouthEast)) {
							// 4 items: case 2
							// 8 items: case 6, 4 and 2
							if (direction == kEast) {
								itx0 = pie->inactiveRadius;
							} else {
								itx0 = 0;
							}
							itx0 += 
								gap + (border * 4);
							ity0 = 
								maxy + border + gap + border;
							lasty = ity0;
						} else {
							// 4 items: case 1
							// 8 items: case 5, 4 and 1
							if (direction == kWest) {
								itx0 = -pie->inactiveRadius;
							} else {
								itx0 = 0;
							}
							itx0 += 
								-itw - gap - border;
							ity0 = 
								lasty;
						} // if
					} // if

					// This is the actual bottom of the bounding
					// box, irregardless of the following adjustment.
					int ity0Bottom = ity0;

					// Leave some extra space for the menu center
					// in the special cases of 1 or 2 slices.
					if ((direction == kNorth) &&
						(maxSlices <= 2)) {
						ity0 += 2 * pie->inactiveRadius;
					}

					itx1 = itx0 + itw;
					ity1 = ity0 + ith;

					// Move the item.
					it->x = itx0;
					it->y = ity0;

					// Update the bounding box.
					if (ity1 > maxy) {
						maxy = ity1;
					}

					// Update group bounding box.
					if (itx0 < minGroupX) {
						minGroupX = itx0;
					}
					if (ity0Bottom < minGroupY) {
						minGroupY = ity0Bottom;
					}
					if (itx1 > maxGroupX) {
						maxGroupX = itx1;
					}
					if (ity1 > maxGroupY) {
						maxGroupY = ity1;
					}

					// If we've finished a group, set the bounding box.
					if (direction == kNorth) {
						// Looping backwards and reached first of group.
						// Set the group box of the first item of this group.

#if 1
						// Adjust the bounding box to be horizontally symetrical.
						if (-minGroupX > maxGroupX) {
							maxGroupX = -minGroupX;
						} else if (maxGroupX > -minGroupX) {
							minGroupX = -maxGroupX;
						}

						if (minx > minGroupX) {
							minx = minGroupX;
						}
						if (maxx < maxGroupX) {
							maxx = maxGroupX;
						}
#endif

						it->groupX = 
							minGroupX - 
							(border + fluff);
						it->groupY = 
							minGroupY - 
							(border + fluff);
						it->groupWidth = 
							(maxGroupX + fluff + border + 1) - 
							it->groupX;
						it->groupHeight = 
							(maxGroupY + fluff + border + 1) -
							it->groupY;
						it->groupItems = 
							maxSlices;
						it->groupSlices =
							maxSlices;
						minGroupX = 10000;
						minGroupY = 10000;
						maxGroupX = -10000;
						maxGroupY = -10000;

						// If we're stacking groups, then just make the rest of the labels invisible.
						if (pie->stack) {
							beginningEntry = i;
							groupVisible = false;

							groupsStackedAbove = 
								(i / maxSlices);

							int hh = it->groupHeight;
							int j;
							for (j = 0; j < groupsStackedAbove; j++) {
								CPieMenuEntry *gr = 
									entries[beginningEntry - ((j + 1) * maxSlices)];

								hh += kCollapsedGroupHeight;

								gr->groupX = it->groupX;
								gr->groupY = it->groupY;
								gr->groupHeight = hh;
								gr->groupWidth = it->groupWidth;
								gr->groupItems = maxSlices;
								gr->groupSlices = maxSlices;

							} // for j
							
							int yy = it->groupY + hh;
							if (yy > maxy) {
								maxy = yy;
							} // if
						} // if
					} // if
				} // if
				break;
			
			case 2:
				{
					// Place locational items below.
					if (groupVisible == 0) {
						it->locational = 1;
						it->visible = 0;
						it->x = 0;
						it->y = 0;
					} else {
						it->visible = 1;

						// i loops forward to numEntries - 1

						// The groups below might have less than maxSlices slices,
						// so we have to figure out the effective number of slices.
						int effectiveFirstSlice = 
							maxSlices * (i / maxSlices);
						int effectiveSlices = maxSlices;
						int effectiveItems = 
							numEntries - effectiveFirstSlice;
						if (effectiveItems < maxSlices) {
							// The menu group wasn't completely filled 
							// out, so figure out the effective slice count.
							// The index map tells us how many effective
							// slices to expand the menu to (to keep the 
							// number of slices even), given the actual 
							// number of active slices in that group. 
							effectiveSlices =
								indexMap[effectiveItems].slices;
						} else {
							// The group was completely filled out, 
							// so the actual number of slices is
							// the maximum number of slices. 
							effectiveItems = maxSlices;
						} // if

						// Figure out the group item index. 
						// Ok to mod with maxSlices since only the 
						// last group has less than maxSlices.
						int ii = i % maxSlices;

						// Figure out the direction.
						// Use the storage2direction map apropriate for
						// the actual number of slices. 
						direction = 
							indexMap[effectiveItems].storage2direction[ii];

						if ((direction == kNorth) ||
							(direction == kSouth)) {
							// 1 item: case 0
							// 2 items: case 0 and 1
							// 4 items: case 0 and 3
							// 8 items: case 0 and 7
							itx0 = 0 - (itw / 2);
							ity1 = miny - border - gap - border;

							// Leave vertical space between groups.
							if (direction == kNorth) {
								ity1 -= fluff + border + 1;
							}
						} else {
							if ((direction == kNorthEast) ||
								(direction == kEast) ||
								(direction == kSouthEast)) {
								// 4 items: case 2
								// 8 items: case 2, 4 and 6
								if (direction == kEast) {
									itx0 = pie->inactiveRadius;
								} else {
									itx0 = 0;
								}
								itx0 += 
									gap + (border * 4);
								ity1 = 
									lasty;
							} else {
								// 4 items: case 1
								// 8 items: case 1, 4 and 5
								if (direction == kWest) {
									itx0 = -pie->inactiveRadius;
								} else {
									itx0 = 0;
								}
								itx0 += 
									-itw - gap - border;
								ity1 = 
									miny - border - gap - border;
								lasty = ity1;
							} // if
						} // if

						itx1 = itx0 + itw;
						ity0 = ity1 - ith;

						// Move the item.
						it->x = itx0;
						it->y = ity0;

						// Leave some extra space for the menu center
						// in the special cases of 1 or 2 slices.
						if ((direction == kNorth) &&
							(effectiveItems <= 2)) {
							ity0 -= 2 * pie->inactiveRadius;
						}

						// Update the bounding box.
						if (ity0 < miny) {
							miny = ity0;
						}

						// Update group bounding box.
						if (itx0 < minGroupX) {
							minGroupX = itx0;
						}
						if (ity0 < minGroupY) {
							minGroupY = ity0;
						}
						if (itx1 > maxGroupX) {
							maxGroupX = itx1;
						}
						if (ity1 > maxGroupY) {
							maxGroupY = ity1;
						}

						// If we've finished a group, set the bounding box.
						if ((ii == (slicesUsed - 1)) ||
							(i == (numEntries - 1))) {
							// Looping forward and reached last of group.
							// Set the group box of the first item of this group.
							
#if 1
							// Adjust the bounding box to be horizontally symetrical.
							if (-minGroupX > maxGroupX) {
								maxGroupX = -minGroupX;
							} else if (maxGroupX > -minGroupX) {
								minGroupX = -maxGroupX;
							}

							if (minx > minGroupX) {
								minx = minGroupX;
							}
							if (maxx < maxGroupX) {
								maxx = maxGroupX;
							}
#endif

							CPieMenuEntry *it1 =
								entries[effectiveFirstSlice];

							it1->groupX = 
								minGroupX - 
								(border + fluff);
							it1->groupY = 
								minGroupY - 
								(border + fluff);
							it1->groupWidth = 
								(maxGroupX + fluff + border + 1) - 
								it1->groupX;
							it1->groupHeight = 
								(maxGroupY + fluff + border + 1) -
								it1->groupY;
							it1->groupItems = 
								effectiveItems;
							it1->groupSlices =
								effectiveSlices;
							minGroupX = 10000;
							minGroupY = 10000;
							maxGroupX = -10000;
							maxGroupY = -10000;


							// If we're stacking groups, then just make the rest of the labels invisible.
							if (pie->stack) {
								endingEntry = i + 1;
								groupVisible = false;

								int numEntriesLeft = 
									numEntries - endingEntry;
								groupsStackedBelow = 
									(numEntriesLeft + (maxSlices - 1)) / maxSlices;

								int yy = miny;
								int hh = it1->groupHeight;
								int j;
								for (j = 0; j < groupsStackedBelow; j++) {
									hh += kCollapsedGroupHeight;

									int ii =
										endingEntry + (j * maxSlices);
									CPieMenuEntry *gr = 
										entries[ii];
									yy = it1->groupY + it1->groupHeight - hh;
									gr->groupX = it1->groupX;
									gr->groupY = yy;
									gr->groupHeight = hh;
									gr->groupWidth = it1->groupWidth;

									// The groups below might have less than maxSlices slices,
									// so we have to figure out the effective number of slices.
									int effectiveFirstSliceGroup = 
										maxSlices * (ii / maxSlices);
									int effectiveSlicesGroup = maxSlices;
									int effectiveItemsGroup = 
										numEntries - effectiveFirstSliceGroup;
									if (effectiveItemsGroup < maxSlices) {
										// The menu group wasn't completely filled 
										// out, so figure out the effective slice count.
										// The index map tells us how many effective
										// slices to expand the menu to (to keep the 
										// number of slices even), given the actual 
										// number of active slices in that group. 
										effectiveSlicesGroup =
											indexMap[effectiveItemsGroup].slices;
									} else {
										// The group was completely filled out, 
										// so the actual number of slices is
										// the maximum number of slices. 
										effectiveItemsGroup = maxSlices;
									} // if

									gr->groupItems = effectiveItemsGroup;
									gr->groupSlices = effectiveSlicesGroup;
								} // for j

								if (yy < miny) {
									miny = yy;
								} // if
							} // if
						} // if
					} // if
				} // scope
				break;
			
			} // switch (phase)

			// Set the direction.
			it->direction = direction;

			// Adjust the label position.
			it->labelX = 
				(it->x + pie->itemBorderWidth) - 1;
			it->labelY = 
				(it->y - pie->itemBorderWidth) + 1;

			if (it->visible) {
				// Update the bounding box.
				if (itx0 < minx) minx = itx0;
				if (itx1 > maxx) maxx = itx1;
				if (ity0 < miny) miny = ity0;
				if (ity1 > maxy) maxy = ity1;

				if (!it->locational) {
					// Update the max radius, if not locational.
					int farx = max(abs(itx0), abs(itx1));
					int fary = max(abs(ity0), abs(ity1));
					int rad = farx * farx + fary * fary;
					if (rad > maxRadius) maxRadius = rad;
				} // if
			} // if it->visible
		} // for i
	} // for phase

	// Calculate the maximum radius.
	maxRadius = 
		(int)(0.95 + 
			  sqrt((float)maxRadius) + 
			  (float)pie->borderWidth);

	// Figure out which shape to actually use.
	int shape = pie->shapeWindow;

	if ((shape == kShapePicture) ||
		(shape == kShapeAsshole)) {

		// For a picture shape, use the region in
		// pie->shapePicture.

		// Presently the pie defines the shape for all the levels.
		// Per-level shapes are not yet supported.

		// Figure out the shape hot spot.
		// If no shape is defined, then shape the
		// window to the default bounding box.
		if (pie->GetShapeRegionSize(&shapeWidth,
									&shapeHeight) != 0) {

			// Figure out the hot spot. If shapeCenterX or shapeCenterY
			// are -1 (the default), the center of the shape is used. 
			if (pie->shapeCenterX == -1) {
				shapeHotX = shapeWidth / 2;
			} else {
				shapeHotX = pie->shapeCenterX;
			} // if

			if (pie->shapeCenterY == -1) {
				shapeHotY = shapeHeight / 2;
			} else {
				shapeHotY = pie->shapeCenterY;
			} // if

			// Make sure the bounding box encompasses the shape.
			// Modify the bounding box by the shape size.
			if (-shapeHotX < minx) {
				minx = -shapeHotX;
			} // if

			if (-shapeHotY < miny) {
				miny = -shapeHotY;
			} // if

			if ((shapeWidth - shapeHotX) > maxx) {
				maxx = (shapeWidth - shapeHotX);
			} // if

			if ((shapeHeight - shapeHotY) > maxy) {
				maxy = (shapeHeight - shapeHotY);
			} // if
		} // if GetShapeRegionSize

	} else if (shape == kShapeRound) {
	
		// Update the bounding box to include a circle of maxRadius.
		if (-maxRadius < minx) minx = -maxRadius;
		if (-maxRadius < miny) miny = -maxRadius;
		if (maxRadius > maxx) maxx = maxRadius;
		if (maxRadius > maxy) maxy = maxRadius;

	} // if (shape == kShapeRound)

	// Size non-symetrical windows to the bounding box of the labels et all.
	minx -= 2 * pie->borderWidth;
	miny -= 2 * pie->borderWidth;
	maxx += 2 * pie->borderWidth;
	maxy += 2 * pie->borderWidth;

	popupCenterX = -minx;
	popupCenterY = maxy; // y flip
	popupWidth = maxx - minx;
	popupHeight = maxy - miny;
	
	// Translate the menu items to the center of the menu, 
	// and flip y axis.
	for (i = beginningEntry; 
		 i < endingEntry; 
		 i++) {
		it = entries[i];
		it->x = (popupCenterX + it->x);
		it->y = (popupCenterY - it->y) - 
				it->height; // y flip
		it->labelX = (popupCenterX + it->labelX);
		it->labelY = (popupCenterY - it->labelY) - 
					 it->height; // y flip

	} // for i

	::SelectObject(dc, lastFont);
	::ReleaseDC(pie->m_hWnd, dc);
} // Layout


void CPieMenuLevel::MakeWindow()
{
	if (popupWindow == NULL) {
		// Create a new popup window with the appropriate event handler.
		popupWindow = 
			::CreateWindowEx(
				0,
				"PIEMENUPOPUP",
				"PIEMENUPOPUP",
				WS_POPUPWINDOW,
				0,
				0,
				100,
				100,
				NULL, // m_hWnd,
				NULL,
				CPieMenuCtrl::instanceHandle,
				NULL);

		SetWindowLong(popupWindow, GWL_USERDATA, (long)this);
	} // if
}


void CPieMenuLevel::ShapeWindow()
{
	long i, rad;
	HRGN reg1 = NULL, reg2 = NULL, reg3 = NULL;
	CPieMenuEntry *it;
	int shape = pie->shapeWindow;
	int gap = pie->itemGap;
	int rrectrad = pie->roundRectRadius;
	int isDynamicMenu =
		pie->dynamicShaping &&
		((pie->buttonsDown != 0) ||
		 (child != NULL));

	MakeWindow();

	switch (shape) {
	
	case kShapeRectangular:
		return;

	case kShapeMinimal:
		rad = labelRadius + 2;
		break;
	
	case kShapeRound:
		rad = maxRadius;
		break;
	
	case kShapeSpokes:
		rad = pie->inactiveRadius +
			  (2 * gap) +
			  3;
		break;

	case kShapePicture:
	case kShapeAsshole:
		{ // scope
			reg1 = pie->GetShapeRegion();

			if (reg1 == NULL) {
				return;
			} // if

			::OffsetRgn(reg1,
						popupCenterX - shapeHotX,
						popupCenterY - shapeHotY);

			rad = 0;
//			goto set_reg1;
			break;
		}  // scope

	case kShapePunched:
		reg1 = ::CreateRectRgn(1,
							   1,
							   popupWidth,
							   popupHeight);
		rad = labelRadius - 6;
		reg2 = ::CreateEllipticRgn(
			1 + popupCenterX - rad, 
			1 + popupCenterY - rad,
			1 + popupCenterX + rad, 
			1 + popupCenterY + rad);
		::CombineRgn(reg1, reg1, reg2, RGN_DIFF);
		::DeleteObject(reg2);

		goto set_reg1;
		break;

	default:
		rad = 0;
		break;

	} // switch (shape)

	if (isDynamicMenu &&
	    (activeItem != -1)) {

		// Shape to only the selected item.

		switch (shape) {

		case kShapeMinimal:
		case kShapeRound:
		case kShapeSpokes:
			reg1 = ::CreateEllipticRgn(
				1 + popupCenterX - rad, 
				1 + popupCenterY - rad,
				1 + popupCenterX + rad, 
				1 + popupCenterY + rad);

			reg2 = ::CreateRectRgn(
				0, 0, 
				popupWidth, 
				popupHeight);

			if ((shape == kShapeSpokes) ||
				(shape == kShapePicture) ||
				(shape == kShapeAsshole) ||
				(slices <= 1)) {

				::CombineRgn(reg2, 
							 reg1, 
							 NULL, 
							 RGN_COPY);

			} else {
			
				it = entries[activeItem];

				float angle = 
					it->angle;
				float subtend =
					((float)2.0 * (float)PI) / slices;
				float xtra =
					(slices == 2)
						? (float)3.0
						: (float)1.5;

				// Make a polygonal region, and use it to chop
				// out the slice.

				POINT PointList[4];

				PointList[0].x = 
					popupCenterX;
				PointList[0].y = 
					popupCenterY;
				
				PointList[1].x = 
					(int)(popupCenterX + 
						  (cos(angle - (subtend / 2.0)) * 
						   xtra * maxRadius));
				PointList[1].y = 
					(int)(popupCenterY - 
						  (sin(angle - (subtend / 2.0)) * 
						   xtra * maxRadius));
				
				PointList[2].x = 
					(int)(popupCenterX + 
						  (cos(angle) * 
						   xtra * maxRadius));
				PointList[2].y = 
					(int)(popupCenterY - 
						  (sin(angle) * 
						   xtra * maxRadius));
				
				PointList[3].x = 
					(int)(popupCenterX + 
						  (cos(angle + (subtend / 2.0)) * 
						   xtra * maxRadius));
				PointList[3].y = 
					(int)(popupCenterY - 
						  (sin(angle + (subtend / 2.0)) * 
						   xtra * maxRadius));

				reg3 = ::CreatePolygonRgn(PointList, 
										  4, 
										  WINDING);

				// Chop chop chop!
				::CombineRgn(reg2, 
							 reg1, 
							 reg3, 
							 RGN_AND);

				::DeleteObject(reg3); 
				reg3 = NULL;
			} // if

			// Create a circle in the middle inactive radius. 

			rad = pie->inactiveRadius + 1;
			reg3 = ::CreateEllipticRgn(
				popupCenterX - rad + 1, 
				popupCenterY - rad + 1,
				popupCenterX + rad + 1, 
				popupCenterY + rad + 1);

			::CombineRgn(reg1, 
						 reg2, 
						 reg3, 
						 RGN_OR);
			break;

		} // switch

	} else {

		// Shape to all the items. 

		switch (shape) {

		case kShapeMinimal:
		case kShapeRound:
		case kShapeSpokes:
			reg1 = ::CreateRectRgn(
				0, 0, 
				popupWidth, popupHeight);

			reg2 = ::CreateEllipticRgn(
				1 + popupCenterX - rad, 
				1 + popupCenterY - rad,
				1 + popupCenterX + rad, 
				1 + popupCenterY + rad);

			rad = pie->inactiveRadius;
			reg3 = ::CreateEllipticRgn(
				1 + popupCenterX - rad, 
				1 + popupCenterY - rad,
				1 + popupCenterX + rad, 
				1 + popupCenterY + rad);

			::CombineRgn(reg1, reg2, reg3, RGN_DIFF);
			break;

		} // switch

	} // if

	if (reg2) {
		::DeleteObject(reg2); 
		reg2 = NULL;
	} // if

	if (reg3) {
		::DeleteObject(reg3); 
		reg3 = NULL;
	} // if

	int last;
	int maxSlices;
	last = numEntries;
	maxSlices = pie->maxSlices;
	
	if ((maxSlices > 0) &&
		(last > maxSlices)) {
		last = maxSlices;
	} // if

	for (i = 0;
		 i < numEntries;
		 i++) {

		it = entries[i];

		int noneSelected =
			activeItem == -1;
		int isSelected =
			activeItem == i;
		int isLocational =
			it->locational;
		int isGroup =
			it->groupWidth != 0;
		int isVisible =
			it->visible;

		int isGroupItem =
			isGroup &&
			isLocational &&
			(!isDynamicMenu ||
			 noneSelected);

		int isVisibleItem =
			!isGroupItem &&
			(!isLocational ||
			 isSelected) &&
			isVisible &&
			(!isDynamicMenu ||
			 isSelected ||
			 noneSelected);

		rad = 4;

		// If this item is the first of a locational group,
		// then add a round rectangle around the bounding
		// box of the group to the window shape. 

		if (isGroupItem) {

			int gw = it->groupWidth;
			int gh = it->groupHeight;
			int gx = popupCenterX + it->groupX;
			int gy = popupCenterY - (it->groupY + gh);
			reg2 = ::CreateRoundRectRgn(
						gx,
						gy,
						gx + gw,
						gy + gh,
						rrectrad, rrectrad);

			if (reg1) {
				::CombineRgn(reg1, 
							 reg1, 
							 reg2, 
							 RGN_OR);
				::DeleteObject(reg2);
				reg2 = NULL;
			} else {
				reg1 = reg2;
				reg2 = NULL;
			} // if

		} else if (isVisibleItem) {

			// Should we draw an embellishment leading from
			// the menu center to the item? (i.e. a spoke,
			// a speech arrow, or thought bubbles, etc). 
			int isEmbellished =
				(!it->locational) ||
				(isDynamicMenu &&
				 (i == activeItem));

			reg2 = ::CreateRoundRectRgn(
						it->x - rad - gap + 1,
						it->y - rad - gap + 1,
						it->x + it->width + rad + gap - 0,
						it->y + it->height + rad + gap - 0,
						rrectrad, rrectrad);

			if (reg1) {
				::CombineRgn(reg1, 
							 reg1, 
							 reg2, 
							 RGN_OR);
				::DeleteObject(reg2);
				reg2 = NULL;
			} else {
				reg1 = reg2;
				reg2 = NULL;
			} // if

			switch (shape) {

			case kShapeThought: // thought balloon
				if (isEmbellished) {
					// This cx,cy is the center of the circle under the label.
					float cx = 
						((float)it->x + 
						 ((float)it->width / (float)2.0)) -
						popupCenterX;
					float cy =
						((float)it->y +
						 ((float)it->height / (float)2.0)) -
						popupCenterY;

					// This r is the center of the first thought bubble,
					// outside of the inactive radius.
					int d = 4; // How far outside. 
					float r = 
						(float)pie->inactiveRadius + d;

					float r1;
					float angle;
					
					if (it->locational == 0) {
						r1 = (float)labelRadius;
						angle = it->angle;
					} else {
						r1 = (float)sqrt((cx * cx) + (cy * cy));
						angle = (float)atan2(-cy, cx);
					} // if

					float sinAngle = (float)-sin(angle);
					float cosAngle = (float)cos(angle);

					while (r <= r1) {
						int x = 
							popupCenterX + 
							(int)(0.5 + (cosAngle * r));
						int y = 
							popupCenterY + 
							(int)(0.5 + (sinAngle * r));

						reg2 = ::CreateEllipticRgn(
							x - d, y - d, 
							x + d, y + d);

						::CombineRgn(reg1, 
									 reg1, 
									 reg2, 
									 RGN_OR);

						::DeleteObject(reg2);
						reg3 = NULL;

						d += 2;
						r += d + d;
					} // while

					break;
				} // if

			case kShapeSpeech: // speech balloon
				if (isEmbellished) {
					// This cx,cy is the center of the circle under the label.
					float cx = 
						((float)it->x + 
						 ((float)it->width / (float)2.0)) -
						popupCenterX;
					float cy =
						((float)it->y +
						 ((float)it->height / (float)2.0)) -
						popupCenterY;

					float r1;
					float angle;
					
					// This is the final radius if the speech anchor,
					// of a circle completely covered by the item.
					float r = min(32,
								  min(it->width, 
									  it->height)) * 
							  (float)0.5;
					
					if (it->locational == 0) {
						r1 = (float)labelRadius + r;
						angle = it->angle;
					} else {
						r1 = (float)sqrt((cx * cx) + (cy * cy));
						angle = (float)atan2(-cy, cx);
					} // if

					float sinAngle = (float)-sin(angle);
					float cosAngle = (float)cos(angle);

					// This dx,dy is perpendicular to the spoke angle,
					// the offset from the center of the circle under
					// the label.
					// to which we draw the lines. 
					float dx = r * sinAngle;
					float dy = r * -cosAngle;

					int x =
						(popupCenterX +
						 (int)(cosAngle * r1) +
						 0);
					int y =
						(popupCenterY +
						 (int)(sinAngle * r1) +
						 0);
					
					int tx = 
						(int)((float)0.5 +
							  (float)popupCenterX +
							  (cosAngle * pie->inactiveRadius));
					int ty = 
						(int)((float)0.5 +
							  (float)popupCenterY +
							  (sinAngle * pie->inactiveRadius));

					// Make a polygonal region for the speech anchor,
					// consisting of 3 points.
					POINT PointList[3];
					PointList[0].x = (int)(x - dx);
					PointList[0].y = (int)(y - dy);
					PointList[1].x = (int)(x + dx);
					PointList[1].y = (int)(y + dy);
					PointList[2].x = tx;
					PointList[2].y = ty;

					reg2 = ::CreatePolygonRgn(PointList, 
											  3, 
											  WINDING);

					::CombineRgn(reg1, 
								 reg1, 
								 reg2, 
								 RGN_OR);

					::DeleteObject(reg2); 
					reg3 = NULL;

					break;
				} // if

			case kShapeSpokes: // Space Station Spokes
				if (isEmbellished) {
					float cx = 
						((float)it->x + 
						 ((float)it->width / (float)2.0)) -
						popupCenterX;
					float cy =
						((float)it->y +
						 ((float)it->height / (float)2.0)) -
						popupCenterY;

					float r1;
					float angle;

					if (it->locational == 0) {
						r1 = (float)labelRadius + 4;
						angle = it->angle;
					} else {
						r1 = (float)sqrt((cx * cx) + (cy * cy));
						angle = (float)atan2(-cy, cx);
					} // if

					float sinAngle = (float)-sin(angle);
					float cosAngle = (float)cos(angle);

					// This r is half the width of the spoke,
					// the radius of a circle under the center of the item.
					float r = (float)pie->itemGap +
							  (float)1.5;

					// This dx,dy is perpendicular to the spoke: its width.
					float dx = r * sinAngle;
					float dy = r * -cosAngle;

					int x =
						(popupCenterX +
						 (int)(cosAngle * r1) +
						 1);
					int y =
						(popupCenterY +
						 (int)(sinAngle * r1) +
						 1);
					
					int tx = 
						(popupCenterX +
						 (int)(cosAngle * pie->inactiveRadius) +
						 1);
					int ty = 
						(popupCenterY +
						 (int)(sinAngle * pie->inactiveRadius) +
						 1);

					// Make a polygonal region for the spoke,
					// consisting of 4 points.
					POINT PointList[4];
					PointList[0].x = (int)(x - dx);
					PointList[0].y = (int)(y - dy);
					PointList[1].x = (int)(x + dx);
					PointList[1].y = (int)(y + dy);
					PointList[2].x = (int)(tx + dx);
					PointList[2].y = (int)(ty + dy);
					PointList[3].x = (int)(tx - dx);
					PointList[3].y = (int)(ty - dy);

					reg2 = ::CreatePolygonRgn(PointList, 
											  4,
											  WINDING);

					::CombineRgn(reg1, 
								 reg1, 
								 reg2, 
								 RGN_OR);

					::DeleteObject(reg2); 
					reg3 = NULL;
					break;
				} // if

			} // switch
		} // if isVisible
	} // for i

set_reg1:

	if (windowRegion != NULL) {
		::DeleteObject(windowRegion);
	} // if

	reg2 = ::CreateRectRgn(0,
						   0,
						   popupWidth + 2,
						   popupHeight + 2);
	::CombineRgn(reg2,
				 reg1,
				 NULL,
				 RGN_COPY);
	::OffsetRgn(reg2,
				-1, -1);
	windowRegion = reg2;

	::SetWindowRgn(popupWindow, 
				   reg1, 
				   TRUE);

	// Make that whole sucker repaint. 
	RECT r;
	r.left = 0;
	r.top = 0;
	r.right = popupWidth + 1;
	r.bottom = popupHeight + 1;

	::InvalidateRect(popupWindow, 
					 &r, 
					 FALSE);
} // ShapeWindow


void CPieMenuLevel::PopUp(long x, long y)
{
	pie->PropogateNeedsLayout();

	MakeWindow();
	Layout();

	popupDownX = x;
	popupDownY = y;
	popupX = x - popupCenterX;
	popupY = y - popupCenterY;
	activeItem = -1;
	activeGroupItem = -1;
	child = NULL;

	UpdateCursor();

	pie->poppedUp = 0;
	pie->StartPopupTimer();

	CString action("");
	pie->FirePreview(action, action, 0, 0);
}


void CPieMenuLevel::Show()
{
	if (!shown) {
		shown = 1;

		int screenWidth = GetSystemMetrics(SM_CXSCREEN);
		int screenHeight = GetSystemMetrics(SM_CYSCREEN);
		int dx = 0;
		int dy = 0;
		int x = popupX;
		int y = popupY;
		int w = popupWidth + 1;
		int h = popupHeight + 1;

		if (w < screenWidth) {
			int offScreen = (x + w) - screenWidth;
			if (offScreen > 0) {
				dx -= offScreen;
			} else if (x < 0) {
				dx -= x;
			} // if
		} // if

		if (h < screenHeight) {
			int offScreen = (y + h) - screenHeight;
			if (offScreen > 0) {
				dy -= offScreen;
			} else if (y < 0) {
				dy -= y;
			} // if
		} // if

		if (dx || dy) {
			x += dx;
			popupX += dx;
			popupDownX += dx;
			y += dy;
			popupY += dy;
			popupDownY += dy;

			if (child == NULL) {
				POINT pt;
				::GetCursorPos(&pt);
				pt.x += dx;
				pt.y += dy;
				::SetCursorPos(pt.x, pt.y);
				pie->TrackMove(pt.x, pt.y);
			} // if child == NULL
		} // if dx || dy

//		::SetForegroundWindow(pie->captureWindow);
//		::BringWindowToTop(pie->captureWindow);
//		::ShowWindow(pie->captureWindow, 1);

		::SetForegroundWindow(popupWindow);
		::BringWindowToTop(popupWindow);
		::SetWindowPos(popupWindow,
					   HWND_TOP,
					   x, 
					   y,
					   w,
					   h,
					   0);

		ShapeWindow();

//		::SetCapture(pie->captureWindow);
//		::SetCapture(GetDesktopWindow());
		::SetCapture(pie->m_hWnd);

		::ShowWindow(popupWindow, 1);

	} // if !shown
}


void CPieMenuLevel::Hide()
{
	if (shown) {
		shown = 0;
		::ShowWindow(popupWindow, 0);
	}
}


void CPieMenuLevel::Home(int dx,
						 int dy)
{
	POINT pt;
	
	::GetCursorPos(&pt);

#if 0
	if ((popupDownX != (pt.x + dx)) ||
		(popupDownY != (pt.y + dy))) {
		popupDownX = pt.x + dx;
		popupDownY = pt.y + dy;
		popupX = popupDownX - popupCenterX;
		popupY = popupDownY - popupCenterY;

		if (shown) {
			Hide();
			Show();
		}

		::GetCursorPos(&pt);
		pie->TrackMove(pt.x, pt.y);
		UpdateCursor();
	}
#else
	if ((pt.x != (popupDownX + dx)) ||
		(pt.y != (popupDownY + dy))) {
		pt.x = popupDownX + dx;
		pt.y = popupDownY + dy;

		if (shown) {
			Hide();
			Show();
		}

		::SetCursorPos(pt.x, pt.y);
		pie->TrackMove(pt.x, pt.y);
		UpdateCursor();
	}
#endif
}


void CPieMenuLevel::NextItem(int steps)
{
	int dx = 0;
	int dy = 0;

	if (numEntries > 0) {
		int newItem = 
			(activeItem == -1)
				? ((steps < 0)
					? (numEntries - 1)
					: 0)
				: (activeItem + steps);
		
		while (newItem < 0) newItem += numEntries;
		
		while (newItem >= numEntries) newItem -= numEntries;

		ScrollToShow(newItem, 1);
		
		CPieMenuEntry *ent = entries[newItem];
		
		if (ent->locational) {
			dx = (ent->x - popupCenterX) + (ent->width / 2);
			dy = (ent->y - popupCenterY) + (ent->height / 2);
		} else {
			dx = ent->xOffset;
			dy = -ent->yOffset;
		}
	}

	Home(dx, dy);
}


void CPieMenuLevel::NextItemKey(int key)
{
	int tries = 0;
	bool found = false;
	int dx = 0;
	int dy = 0;

	key = toupper(key);

	if (numEntries > 0) {
		int wasShown = shown;
		int newItem = 
			(activeItem == -1)
				? 0 
				: (activeItem + 1);
		while (tries < numEntries) {
			while (newItem >= numEntries) newItem -= numEntries;

			CPieMenuEntry *ent = entries[newItem];
			char *label = ent->cookedLabel;
			if (label != NULL) {
				int firstChar = toupper(label[0]);
				
				if (firstChar == key) {
					if (shown) {
						Hide();
					}
					ScrollToShow(newItem, 1);

					if (ent->locational) {
						dx = (ent->x - popupCenterX) + (ent->width / 2);
						dy = (ent->y - popupCenterY) + (ent->height / 2);
					} else {
						dx = ent->xOffset;
						dy = -ent->yOffset;
					} // if

					break;
				} // if
			} // if
			tries++;
			newItem++;
		} // while

		if (wasShown && !shown) {
			Show();
		} // if
	} // if

	Home(dx, dy);
}


static int cursorIds1[] = {
	IDC_FLOWER1, 
		IDC_FLOWER1_0
};

static int cursorIds2[] = {
	IDC_FLOWER2, 
		IDC_FLOWER2_0, IDC_FLOWER2_1
};

static int cursorIds3[] = {
	IDC_FLOWER3, 
		IDC_FLOWER3_0, IDC_FLOWER3_1, IDC_FLOWER3_2
};

static int cursorIds4[] = {
	IDC_FLOWER4, 
		IDC_FLOWER4_0, IDC_FLOWER4_1, IDC_FLOWER4_2, IDC_FLOWER4_3
};

static int cursorIds5[] = {
	IDC_FLOWER5, 
		IDC_FLOWER5_0, IDC_FLOWER5_1, IDC_FLOWER5_2, IDC_FLOWER5_3, 
		IDC_FLOWER5_4
};

static int cursorIds6[] = {
	IDC_FLOWER6, 
		IDC_FLOWER6_0, IDC_FLOWER6_1, IDC_FLOWER6_2, IDC_FLOWER6_3, 
		IDC_FLOWER6_4, IDC_FLOWER6_5
};

static int cursorIds7[] = {
	IDC_FLOWER7, 
		IDC_FLOWER7_0, IDC_FLOWER7_1, IDC_FLOWER7_2, IDC_FLOWER7_3, 
		IDC_FLOWER7_4, IDC_FLOWER7_5, IDC_FLOWER7_6
};

static int cursorIds8[] = {
	IDC_FLOWER8, 
		IDC_FLOWER8_0, IDC_FLOWER8_1, IDC_FLOWER8_2, IDC_FLOWER8_3, 
		IDC_FLOWER8_4, IDC_FLOWER8_5, IDC_FLOWER8_6, IDC_FLOWER8_7
};

static int *cursorIds[] = {
	cursorIds1, cursorIds2, cursorIds3, cursorIds4, 
	cursorIds5, cursorIds6, cursorIds7, cursorIds8
};

void CPieMenuLevel::UpdateCursor()
{
	int id = IDC_FLOWER;

	if ((initialAngle == 90) &&
		(clockwise != 0) &&
		(slices > 0) &&
		(slices <= 8)) {
		int groupIndex = 
			(activeGroupItem == -1) 
				? 0
				: activeGroupItem;
		int groupItems = entries[groupIndex]->groupItems;
		int groupSlices = entries[groupIndex]->groupSlices;
		int groupDisplayIndex = -1;

		if (groupSlices > 0) {
			if (activeItem != -1) {
				CPieMenuEntry *it = entries[activeItem];
				int groupOffset = 
					activeItem - groupIndex;

				if (it->locational == 0) {
					// The index is of a slice, so figure out the display index.
					if (storage2display == NULL) {
						// No index mapping.
						groupDisplayIndex = groupOffset;
					} else {
						// Map index from storage to display.
						groupDisplayIndex = 
							storage2display[groupOffset];
					} // if
				} else {
					// In a locational group, the number of items might be
					// different than the number of slices in the pie,
					// so go back to the index map to figure out the
					// storage to dispay mapping. 
					groupDisplayIndex =
						indexMap[groupItems].storage2display[groupOffset];
				} // if
			} // if

			id = cursorIds[groupSlices - 1][groupDisplayIndex + 1];
		} // if
	} // if

	pie->UpdateCursor(id);
}


int CPieMenuLevel::TryScroll(long x, long y)
{
	int phase, i;
	int wx = x - popupDownX;
	int wy = popupDownY - y;

	for (phase = 0; phase <= 1; phase++) {
		int from, to, step;

		if (phase == 0) {
			from = firstSlice - 1;
			to = -1;
			step = -1;
		} else {
			from = lastSlice;
			to = numEntries;
			step = 1;
		} // if

		for (i = from; 
			 i != to;
			 i += step) {
			CPieMenuEntry *it = entries[i];

			if ((it->locational != 0) &&
				(it->groupWidth != 0)) {

				int gw = entries[i]->groupWidth;
				int gh = entries[i]->groupHeight;
				int gx = entries[i]->groupX;
				int gy = entries[i]->groupY;

				if ((gx <= wx) &&
					(gy <= wy) &&
					(wx < (gx + gw)) &&
					(wy < (gy + gh))) {
					topItem = i;

					activeItem = -1;
					levelNeedsLayout = 1;
					Layout();

					if (pie->scrollingMovesCursor) {
						x = popupDownX;
						y = popupDownY;
						::SetCursorPos(x, y);
					} else {
						popupDownX = x;
						popupDownY = y;
					}

					popupX = popupDownX - popupCenterX;
					popupY = popupDownY - popupCenterY;

					if (shown) {
						Hide();
						Show();
					} // if (shown)

					POINT pt;
					::GetCursorPos(&pt);
					pie->TrackMove(pt.x, pt.y);

					UpdateCursor();

					return 1;
				} // if
			} // if
		} // for i
	} // for phase

	return 0;
}


void CPieMenuLevel::ScrollItems(int dir, int dist)
{
	if (dist == 0) {
		dist = pie->maxSlices;
	}

	int top = 
		topItem + 
		(dir * dist);

	if (top >= numEntries) {
		return;
	}

	if (top < 0) {
		top = 0;
	}

	if (top != topItem) {
		topItem = top;

		levelNeedsLayout = 1;
		Layout();

		popupX = popupDownX - popupCenterX;
		popupY = popupDownY - popupCenterY;

		if (shown) {
			Hide();
			Show();
		} // if shown

		POINT pt;
		::GetCursorPos(&pt);

		pie->TrackMove(pt.x, pt.y);
		UpdateCursor();

	} // if
}


void CPieMenuLevel::ScrollToShow(int index, int encompass)
{
	if (numEntries > 0) {
		int wasShown = shown;

		if (index < 0) {
			index = 0;
		} // if
		
		if (index >= numEntries) {
			index = numEntries - 1;
		} // if

		if (encompass) {
			while (index < firstSlice) {
				if (shown) {
					Hide();
				}
				ScrollItems(-1);
			} // while
			
			while (index >= lastSlice) {
				if (shown) {
					Hide();
				}
				ScrollItems(1);
			} // while
		} else {
			while (index < beginningEntry) {
				if (shown) {
					Hide();
				}
				ScrollItems(-1);
			} // while
			
			while (index >= endingEntry) {
				if (shown) {
					Hide();
				}
				ScrollItems(1);
			} // while
		} // if

		if (wasShown && !shown) {
			Show();
		} // if
	} // if
}


CPieMenuLevel *CPieMenuLevel::Back()
{
	CPieMenuLevel *result = parent;

	Hide();

	if (parent != NULL) {
		parent->child = NULL;
	} // if

	parent->UpdateCursor();

	return result;
}


void CPieMenuLevel::Cancel()
{
	Hide();

	if (parent != NULL) {
		parent->Cancel();
	} // if
}


CPieMenuEntry *CPieMenuLevel::CurrentEntry()
{
	if (activeItem == -1) {
		int i;
		if ((parent != NULL) &&
			((i = parent->activeItem) != -1)) {
			return parent->entries[i];
		} else {
			return NULL;
		} // if
	} else {
		return entries[activeItem];
	} // if
}


void CPieMenuLevel::AddEntry(CPieMenuEntry *ent, int index)
{
	numEntries++;
	if (numEntries > maxEntries) {
		// Expand the entries array if necessary.
		maxEntries += 8;
		if (entries == NULL) {
			entries = new CPieMenuEntry*[maxEntries];
		} else {
			CPieMenuEntry **oldEntries = entries;
			entries = new CPieMenuEntry*[maxEntries];
			int i;
			
			for (i = 0; i < maxEntries - 8; i++) {
				entries[i] = oldEntries[i];
			} // for

			for (; i < maxEntries; i++) {
				entries[i] = NULL;
			} // for
			
			delete [] oldEntries;
		} // if
	} // if

	// Hook this entry up to the current level.
	if (index == -1) {
		entries[numEntries - 1] = ent;
	} else {
		memmove(&entries[index + 1],
				&entries[index],
				(numEntries - index - 1) * sizeof(CPieMenuEntry *));
		entries[index] = ent;
	} // if
	ent->parentLevel = this;
}


void CPieMenuLevel::Shrink()
{
	// Shrink the entries array.
	if (numEntries > maxEntries) {
		CPieMenuEntry **oldEntries = entries;

		entries = new CPieMenuEntry*[numEntries];
		maxEntries = numEntries;
		
		int i;
		for (i = 0; i < numEntries; i++) {
			entries[i] = oldEntries[i];
		} // for

		delete [] oldEntries;
	} // if
}


void CPieMenuLevel::Decompile(CString &str,
							  int indent)
{
	int i, j, n = numEntries;

	for (i = 0; i < n; i++) {
		CPieMenuEntry *ent = entries[i];

		for (j = 0; j < indent; j++) {
			str += " ";
		} // for

		char buf[256];
		int len = ent->labelLength;
		memcpy(buf, ent->label, len);
		buf[len] = '\0';
		str += buf;

		// Emit the level properties as annotations of the first entry.
		if (i == 0) {
			char buf[256];

			if (flags & kLevelLayoutInitialAngle) {

				switch (initialAngle) {
				case 0:
					str += "@e";
					break;
				case 45:
					str += "@ne";
					break;
				case 90:
					str += "@n";
					break;
				case 90 + 45:
					str += "@nw";
					break;
				case 180:
					str += "@w";
					break;
				case 180 + 45:
					str += "@sw";
					break;
				case 180 + 90:
					str += "@s";
					break;
				case 180 + 90 + 45:
					str += "@se";
					break;
				default:
					str += "@";
					sprintf(buf, "%d", initialAngle);
					str += buf;
					break;
				} // switch
			} // if

			if (flags & kLevelLayoutClockwise) {
				if (clockwise) {
					str += "@cw";
				} else {
					str += "@ccw";
				} // if
			} // if
			
			if (flags & kLevelLayoutFixedRadius) {
				str += "@r";
				sprintf(buf, "%d", fixedRadius);
				str += buf;
			} // if

		} // if i == 0

		if (ent->flags & kEntryAction) {
			memcpy(buf, ent->action, ent->actionLength);
			buf[ent->actionLength] = '\0';
			str += "=";
			str += buf;
		} // if

		str += "\r\n";

		// Recursively decompile sublevels, indented.
		CPieMenuLevel *subLevel = ent->subLevel;
		if (subLevel != NULL) {
			int tab = 4;
			subLevel->Decompile(str, indent + tab);
		} // if

	} // for i
}


long CPieMenuLevel::PieLevelWindowProc(HWND hWnd, UINT message, 
									   WPARAM wParam, LPARAM lParam)
{
	long result = 1;

    switch (message) {

	case WM_PAINT:
		{ // scope
			PAINTSTRUCT ps;
			HDC dc = ::BeginPaint(popupWindow, &ps);
			GState g(pie);

			Paint(dc, &g);

			::EndPaint(popupWindow, &ps);
			DeleteDC(dc);
		} // scope
		break;

	case WM_NCPAINT:
		// We must absorb these, or else the rectangular borders are drawn.
		break;

	case WM_CHAR:
		pie->OnChar(wParam, 
					(int)(short)LOWORD(lParam),
					(UINT)HIWORD(lParam));
		break;

	case WM_KEYDOWN:
		pie->OnKeyDown(wParam, 
					   (int)(short)LOWORD(lParam),
					   (UINT)HIWORD(lParam));
		break;

	case WM_KEYUP:
		pie->OnKeyUp(wParam, 
					 (int)(short)LOWORD(lParam),
					 (UINT)HIWORD(lParam));
		break;

	case 0xcccb: // I don't know why I'm getting this but I am...
	case WM_MOUSEWHEEL:
		pie->OnMouseWheel(LOWORD(wParam),
						  (int)HIWORD(wParam),
						  CPoint(LOWORD(lParam), HIWORD(lParam)));
		break;

	// Ignore these
	case WM_ACTIVATEAPP:
	case WM_NCCREATE:
	case WM_NCDESTROY:
	case WM_NCCALCSIZE:
	case WM_CREATE:
	case WM_DESTROY:
	case WM_SIZE:
	case WM_MOVE:
	case WM_WINDOWPOSCHANGING:
	case WM_WINDOWPOSCHANGED:
	case WM_NCACTIVATE:
	case WM_ACTIVATE:
	case WM_SETFOCUS:
	case WM_KILLFOCUS:
	case WM_SHOWWINDOW:
	case WM_ERASEBKGND:
	case WM_NCHITTEST:
	case WM_AFXFIRST + 0x0e: // 36e
		result = DefWindowProc(hWnd, message, wParam, lParam);
		break;

	default:
		result = DefWindowProc(hWnd, message, wParam, lParam);
		break;

    } // switch

    return result;
}


/////////////////////////////////////////////////////////////////////////////
