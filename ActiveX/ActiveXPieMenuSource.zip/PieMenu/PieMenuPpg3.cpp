/////////////////////////////////////////////////////////////////////////////
//
// PieMenuPpg3.cpp : Implementation of the CPieMenuPropPage3 property page class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "PieMenuPpg3.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Dynamic OLE Control Creation

IMPLEMENT_DYNCREATE(CPieMenuPropPage3, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////


#define STR(s) s

static char *GalleryPropNames[] = {
//	STR("BackColor"),
//	STR("ForeColor"),
//	STR("Font"),
//	STR("Items"),
//	STR("Direction"),
//	STR("Distance"),
//	STR("Index"),
//	STR("Action"),
//	STR("BackgroundPicture"),
//	STR("TargetPicture"),
//	STR("ItemCount"),
	STR("InactiveRadius"),
	STR("MinRadius"),
	STR("Clockwise"),
	STR("InitialAngle"),
	STR("BorderWidth"),
	STR("ItemBorderWidth"),
	STR("ExtraRadius"),
	STR("FixedRadius"),
//	STR("CurrentItem"),
	STR("ShrinkWrap"),
	STR("ShapeWindow"),
	STR("PopupDelay"),
	STR("DoubleBuffer"),
//	STR("CPieMenuCtrl"),
	STR("ItemGap"),
//	STR("Revision"),
//	STR("DarkColor"),
//	STR("LightColor"),
//	STR("Bevel"),
//	STR("ShapeCenterX"),
//	STR("ShapeCenterY"),
//	STR("ShapePicture"),
	STR("DynamicShaping"),
//	STR("ShapeTransparentX"),
//	STR("ShapeTransparentY"),
	STR("SliceInset"),
//	STR("UserData"),
	STR("MaxSlices"),
	STR("LayerRadius"),
	STR("AutoScroll"),
	STR("Shuffle")
};


/////////////////////////////////////////////////////////////////////////////


// I'm making my own darn window with its own freaking window proc, 
// to get just the behavior I want around the back of OLE and MFingC.

LRESULT CALLBACK
EditPieMenuWindowProc(HWND hWnd, 
					  UINT message,
					  WPARAM wParam,
					  LPARAM lParam);


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CPieMenuPropPage3, COlePropertyPage)
	//{{AFX_MSG_MAP(CPieMenuPropPage3)
	ON_WM_PAINT()
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree)
	ON_NOTIFY(TVN_ENDLABELEDIT, IDC_TREE1, OnEndlabeleditTree)
	ON_NOTIFY(TVN_DELETEITEM, IDC_TREE1, OnDeleteitemTree)
	ON_NOTIFY(NM_CLICK, IDC_TREE1, OnClickTree)
	ON_NOTIFY(TVN_BEGINDRAG, IDC_TREE1, OnBegindragTree)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_NOTIFY(TVN_BEGINLABELEDIT, IDC_TREE1, OnBeginlabeleditTree1)
	ON_NOTIFY(NM_RCLICK, IDC_TREE1, OnRclickTree1)
	ON_CBN_SELCHANGE(IDC_MODE1, OnSelchangeMode1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CPieMenuPropPage3, "PIEMENU.CPieMenuPropPage3",
	0xa63154a1, 0x484, 0x11d1, 0x9a, 0x4c, 0x54, 0xa4, 0xff, 0xc0, 0x0, 0x0)


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage3::CPieMenuPropPage3Factory::UpdateRegistry -
// Adds or removes system registry entries for CPieMenuPropPage3

BOOL CPieMenuPropPage3::CPieMenuPropPage3Factory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_PIEMENU_PPG3);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage3::CPieMenuPropPage3 - Constructor

CPieMenuPropPage3::CPieMenuPropPage3() :
	COlePropertyPage(IDD, IDS_PIEMENU3_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CPieMenuPropPage3)
	m_pieLong = 0;
	m_pie = NULL;
	m_pieEditor = NULL;
	//}}AFX_DATA_INIT
	curLevel = 0;
	curSel = -1;
	draggingTree = 0;
	dragItem = NULL;
	revision = -1;
	editorMouseDown = 0;
	editorLastX = 0;
	editorLastY = 0;
	editorRepaint = 0;
	mode = 0;
}


CPieMenuPropPage3::~CPieMenuPropPage3()
{
	if (m_pieEditor != NULL) {
		::DestroyWindow(m_pieEditor);
		m_pieEditor = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage3::DoDataExchange - Moves data between page and properties

void CPieMenuPropPage3::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CPieMenuPropPage3)
	DDX_Control(pDX, IDC_MODE1, m_mode);
	DDX_Control(pDX, IDC_TREE1, m_Tree);
	DDX_Control(pDX, IDC_STATIC0, m_picture);
	DDX_Control(pDX, IDC_EDIT1, m_pieText);
	DDP_Text(pDX, IDC_EDIT1, m_pieLong, _T("CPieMenuCtrl") );
	DDX_Text(pDX, IDC_EDIT1, m_pieLong);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);

	// By the way, the trick to getting the wizard to make the above 
	// DDX_Control of class CStatic m_picture for a static field, 
	// is to rename the IDC_STATIC resource id to IDC_STATIC0 
	// (i.e. give it a trailing digit),
	// then the wizard will recognize it as a control you're allowed 
	// to bind to a CStatic member variable of the control panel.
	// Otherwise, if it doesn't end in a digit, 
	// it just doesn't show up in the scrolling list.
	// Go figure.

	if (!pDX->m_bSaveAndValidate) {

		// This is the only way I could figure out how to 
		// get ahold of the raw CPieMenuCtrl pointer...
		// IDC_EDIT1 is a static text field 
		// that's bound to an integer 
		// as well as a CEdit control that gets hidden. 
		// The integer gets the value of the long CPieMenuCtrl property 
		// (which exposes a raw pointer to the CPieMenuCtrl object itself).
		// The CEdit m_pieText binding is so OnInitDialog can it. 
		// We cast the integer into a nice pointer, now.
		m_pie = (CPieMenuCtrl *)m_pieLong;
		revision = -1;
		UpdateTree();
		UpdateGallery();

	} else {
		revision = -1;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage3 message handlers


void CPieMenuPropPage3::OnPaint() 
{
	if ((m_pie != NULL) &&
		(m_pie->tracking == 0) &&
		(revision != m_pie->revision)) {
		UpdateTree();
		UpdateGallery();
	}

	COlePropertyPage::OnPaint();
}


BOOL CPieMenuPropPage3::OnInitDialog()
{
	COlePropertyPage::OnInitDialog();

	RECT r;
	m_picture.GetClientRect(&r);
	m_picture.ClientToScreen(&r);
	ScreenToClient(&r);
	int x = r.left + 1;
	int y = r.top + 1;
	int w = (r.right - r.left) - 2;
	int h = (r.bottom - r.top) - 2;

	m_pieEditor = CreateWindowEx(
        0,
        "EDITPIEMENUWINDOW",
        "Edit Pie Menu",
        WS_CHILD | WS_VISIBLE,
        x, y, w, h,
		m_hWnd,
        NULL,
		AfxGetInstanceHandle(),
        NULL);

	::SetWindowLong(m_pieEditor, GWL_USERDATA, (long)this);

	m_pieText.ShowWindow(0);
	SetMode(mode);

	return FALSE;  // return TRUE unless you set the focus to a control
	               // EXCEPTION: OCX Property Pages should return FALSE
}


void CPieMenuPropPage3::FillTree(CTreeCtrl *tree,
								 int *id,
								 HTREEITEM parentItem,
								 CPieMenuLevel *lev)
{
	int i;
	HTREEITEM item;

	if (lev != NULL) {
		for (i = 0; i < lev->numEntries; i++) {
			CPieMenuEntry *ent = lev->entries[i];
			
			char str[256];
			int len = ent->labelLength;
			if (len > 255) len = 255;
			memcpy(str, ent->label, len);
			str[len] = '\0';

			item = tree->InsertItem(str, parentItem);
			tree->SetItemData(item, (unsigned long)*id);
			(*id)++;

			FillTree(tree, id, item, ent->subLevel);
		}
	}
}


void CPieMenuPropPage3::UpdateTree()
{
	if ((mode != 0) ||
		(m_pie->tracking != 0) ||
		(revision == m_pie->revision)) {
		return;
	}

	revision = m_pie->revision;

	m_Tree.SetRedraw(0);

	m_Tree.DeleteAllItems();

	if ((m_pie == NULL) ||
		(m_pie->tracking != 0)) {
		curLevel = -1;
		curSel = -1;
	} else {
		curLevel = 0;
		curSel = 0;

		m_pie->UpdateProps();
		m_pie->CreateLevels();

		revision = m_pie->revision;

		int id = 0;

		FillTree(&m_Tree,
				 &id,
				 NULL,
				 m_pie->rootLevel);
	}

	m_Tree.SetRedraw(1);
	m_Tree.Invalidate();
}


void CPieMenuPropPage3::UpdateTreeSel()
{
	if ((mode != 0) ||
		(m_pie->tracking != 0)) {
		return;
	}

	m_pie->CreateLevels();

	CPieMenuLevel *lev = m_pie->level;

	if (lev == NULL) {
		lev = m_pie->rootLevel;
	}

	int activeItem = -1;
	CPieMenuEntry *ent = NULL;

	if (lev != NULL) {
		activeItem = lev->activeItem;
		if (activeItem != -1) {
			ent = lev->entries[lev->activeItem];
		}
	}

	if (ent != NULL) {
		HTREEITEM rootItem = m_Tree.GetRootItem();
//		HTREEITEM childItem = m_Tree.GetChildItem(rootItem);
//		HTREEITEM it = FindEntryItem(ent, childItem);
		HTREEITEM it = FindEntryItem(ent, rootItem);
		m_Tree.SelectItem(it);
	} else {
		m_Tree.SelectItem(NULL);
	}

	m_Tree.Invalidate();
}


HTREEITEM CPieMenuPropPage3::FindEntryItem(CPieMenuEntry *ent, 
										   HTREEITEM it)
{
	HTREEITEM result = NULL;

	while (it != NULL) {
		int data = (int)m_Tree.GetItemData(it);

		if (data == ent->index) {
			return it;
		}

		HTREEITEM childItem = m_Tree.GetChildItem(it);
		if (childItem != NULL) {
			result = FindEntryItem(ent, childItem);

			if (result != NULL) {
				return result;
			}

		}

		it = m_Tree.GetNextSiblingItem(it);
	}

	return NULL;
}


void CPieMenuPropPage3::UpdateGallery()
{
	int numProps = sizeof(GalleryPropNames) / sizeof(LPOLESTR);
	int i;

	if (mode != 1) {
		return;
	}

	m_Tree.DeleteAllItems();

	for (i = 0; i < numProps; i++) {
		char *name = GalleryPropNames[i];
		HTREEITEM item = m_Tree.InsertItem(name, NULL);
		m_Tree.SetItemData(item, (unsigned long)name);
	}
}


void CPieMenuPropPage3::PaintEditor()
{
#if 0
	HDC dc = ::GetDC(m_pieEditor);

	PaintPieMenuEditor(dc);

	::DeleteObject(dc);
#else
	RECT rect;
	::GetClientRect(m_pieEditor, &rect);
	::InvalidateRect(m_pieEditor, &rect, FALSE);
	editorRepaint = 1;
#endif
}


/////////////////////////////////////////////////////////////////////////////
// PieMenuEditorWindow handlers


LRESULT CALLBACK
EditPieMenuWindowProc(HWND hWnd, 
					  UINT message,
					  WPARAM wParam,
					  LPARAM lParam)
{
	CPieMenuPropPage3 *dlg = 
		(CPieMenuPropPage3 *)::GetWindowLong(hWnd, GWL_USERDATA);

	if (dlg) {
		return dlg->EditPieMenuWindowProc(hWnd, 
										  message,
										  wParam,
										  lParam);
	}

    return DefWindowProc(hWnd, message, wParam, lParam);
}


LRESULT CPieMenuPropPage3::EditPieMenuWindowProc(HWND hWnd, 
												 UINT message,
												 WPARAM wParam,
												 LPARAM lParam)
{
	long result = 1;
	int x = LOWORD(lParam);
	int y = HIWORD(lParam);

	switch (message) {

	case WM_NCPAINT:
	case WM_ERASEBKGND:
		// Absorb these messages.
		break;

	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC dc = ::BeginPaint(hWnd, &ps);

			if ((m_pie != NULL) &&
				(m_pie->tracking != 0) &&
				(editorRepaint != 0)) {
//				editorRepaint = 0;

//				RECT rect;
//				::GetClientRect(m_pieEditor, &rect);
//				::InvalidateRect(m_pieEditor, &rect, FALSE);

				PaintPieMenuEditor(dc);

				::EndPaint(hWnd, &ps);

			} else {
				PaintPieMenuEditor(dc);

				::EndPaint(hWnd, &ps);
			}

			break;
		}

	case WM_MOUSEMOVE:
		if (editorMouseDown) {
			if ((x != editorLastX) ||
				(y != editorLastY)) {
				editorLastX = x;
				editorLastY = y;
				TrackPieMenuEditor(x, y);
			}
		}
		break;

		// This code that actually pops up the real pie menu is currently disabled,
		// because it confuses the hell out of visual basic for some reason.
		// It seems to reset the property page and lose the capture after the menu pops up.
#if 0
	case WM_LBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
#if 0
		editorMouseDown = 1;
//		x = 0; y = 0;
		editorLastX = x;
		editorLastY = y;
		TrackPieMenuEditor(x, y, 1);
#else
		// Sometimes in visual basic there's no m_hWnd, so the SetCapture bombs.
		if  (m_pie->m_hWnd != NULL) {
			m_pie->PopUp(x, y);

			editorRepaint = 1;

			RECT rect;
			::GetClientRect(m_pieEditor, &rect);
			::InvalidateRect(m_pieEditor, &rect, FALSE);
		}
#endif
		break;

	case WM_LBUTTONUP:
#if 0
		TrackPieMenuEditor(x, y);
		editorMouseDown = 0;
#else
#endif
		break;
#endif

	// Channel the left button into here for now.
	case WM_LBUTTONDOWN:
	case WM_LBUTTONDBLCLK:

	case WM_RBUTTONDOWN:
	case WM_RBUTTONDBLCLK:
		editorMouseDown = 1;
//		x = 0; y = 0;
		editorLastX = x;
		editorLastY = y;
		TrackPieMenuEditor(x, y, 1);
		break;

	// Channel the left button into here for now.
	case WM_LBUTTONUP:

	case WM_RBUTTONUP:
		TrackPieMenuEditor(x, y);
		editorMouseDown = 0;
		break;

	default:
	    result = ::DefWindowProc(hWnd, message, wParam, lParam);
		break;

	}

	return result;
}


void CPieMenuPropPage3::PaintPieMenuEditor(HDC dc)
{
	COLORREF background = RGB(128, 128, 128);
	LOGBRUSH backgroundLogBrush;
	backgroundLogBrush.lbStyle = BS_SOLID;
	backgroundLogBrush.lbColor = background;
	backgroundLogBrush.lbHatch = 0;
	HBRUSH backgroundBrush = ::CreateBrushIndirect(&backgroundLogBrush);
	HBRUSH oldBrush = (HBRUSH)::SelectObject(dc, backgroundBrush);

	RECT rect;

	::GetClientRect(m_pieEditor, &rect);

	HRGN winReg = ::CreateRectRgn(rect.left,
								  rect.top, 
								  rect.right, 
								  rect.bottom);
	::SelectClipRgn(dc, winReg);
	::DeleteObject(winReg);

	if ((m_pie == NULL) ||
		(m_pie->tracking != 0)) {
		
		::FillRect(dc, &rect, backgroundBrush);

	} else if (editorRepaint != 0) {
	
		editorRepaint = 0;

		RECT rect;
		::GetClientRect(m_pieEditor, &rect);
		::InvalidateRect(m_pieEditor, &rect, FALSE);

	} else {

		m_pie->CreateLevels();

		CPieMenuLevel *lev = m_pie->GetLevel(curLevel);

		lev->activeItem = curSel;
		lev->Layout();
		lev->ShapeWindow();

		::FillRect(dc, &rect, backgroundBrush);

		int dx = lev->popupCenterX - (rect.right / 2);
		int dy = lev->popupCenterY - (rect.bottom / 2);

		::SetWindowOrgEx(dc, dx, dy, NULL);

		HRGN levelReg = lev->windowRegion;

		if (levelReg == NULL) {
			HRGN rectReg = ::CreateRectRgn(0,
										   0,
										   lev->popupWidth - 1,
										   lev->popupHeight - 1);
			::SelectClipRgn(dc, rectReg);
			::DeleteObject(rectReg);
		} else {
			::SelectClipRgn(dc, levelReg);
		}
		::OffsetClipRgn(dc, -dx, -dy);
		::IntersectClipRect(dc,
							dx, 
							dy, 
							rect.right + dx, 
							rect.bottom + dy);

		GState g(m_pie);
		lev->Paint(dc, &g);

		::SetWindowOrgEx(dc, 0, 0, NULL);

	}

	::SelectObject(dc, oldBrush);

	::DeleteObject(backgroundBrush);
}


void CPieMenuPropPage3::TrackPieMenuEditor(int x, 
										   int y, 
										   int movecur)
{
	RECT rect;

	::GetClientRect(m_pieEditor, &rect);

	if (m_pie != NULL) {
		m_pie->CreateLevels();

		CPieMenuLevel *lev = m_pie->GetLevel(curLevel);
		m_pie->level = lev;

		lev->Layout();

		if (movecur) {
			POINT pt;
			pt.x = x + rect.right / 2;
			pt.y = y + rect.bottom / 2;
			::ClientToScreen(m_pieEditor, &pt);
//			::SetCursorPos(pt.x, pt.y);
		}

		int curx = x - (rect.right / 2);
		int cury = -(y - (rect.bottom / 2));
		int lastSel = lev->activeItem;

		curSel = m_pie->CalcPieMenuItem(curx, cury);

		if (curSel != lastSel) {
			lev->activeItem = curSel;

			// XXX: TODO: Update the tree view
			UpdateTreeSel();

			PaintEditor();
		}
	}
}

void CPieMenuPropPage3::OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if (mode != 0) {
		return;
	}

//	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM item = m_Tree.GetSelectedItem();
	CPieMenuEntry *ent = NULL;
	CPieMenuLevel *lev = NULL;

	// XXX: This is dubious...
	if ((m_pie != NULL) &&
		(m_pie->revision != revision) ||
		(m_pie->rootLevel == NULL)) {
		return;
	}

	if (item == NULL) {
		curSel = -1;
	} else {
		int id = (int)m_Tree.GetItemData(item);
		if (id == -1) {
			HTREEITEM item2 = m_Tree.GetPrevSiblingItem(item);
			if (item2 == NULL) {
				item2 = m_Tree.GetParentItem(item);
				if (item2 != NULL) {
					id = (int)m_Tree.GetItemData(item2);
					item = item2;
				}
			} else {
				id = (int)m_Tree.GetItemData(item2);
				if (id >= 0) {
					ent = m_pie->entriesTree[id];
					lev = ent->parentLevel;

					id = -1;
					curSel = -1;
					curLevel = -1;
					int i, levels = m_pie->CountLevels();
					for (i = 0; i < levels; i++) {
						if (m_pie->GetLevel(i) == lev) {
							curLevel = i;
							break;
						}
					}
				}
			}
		}
		if (id != -1) {
			ent = m_pie->entriesTree[id];
			lev = ent->parentLevel;

			curLevel = -1;
			int i, levels = m_pie->CountLevels();
			for (i = 0; i < levels; i++) {
				if (m_pie->GetLevel(i) == lev) {
					curLevel = i;
					break;
				}
			}

			for (curSel = -1;
				 item != NULL;
				 item = m_Tree.GetPrevSiblingItem(item), curSel++) {
			}
		}
	}

	PaintEditor();

	*pResult = 0;
}

void CPieMenuPropPage3::OnEndlabeleditTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;
	// TODO: AddString your control notification handler code here
	
	*pResult = 0;
}

void CPieMenuPropPage3::OnDeleteitemTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CPieMenuPropPage3::OnClickTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CPieMenuPropPage3::OnBegindragTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if (mode != 0) {
		return;
	}

	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM item = pNMTreeView->itemNew.hItem;
	int id = m_Tree.GetItemData(item);

	m_Tree.SelectItem(item);

	// Drag and drop editing of the menu tree is not currently implemented.
	// There are some skeletal handlers and a few functions written to support it.
	if (id < 0) {
		// ...
	} else {

//		CImageList *imageList = m_Tree.CreateDragImage(item);

//		imageList->BeginDrag(0, pNMTreeView->ptDrag);

//		ShowCursor(FALSE);

		SetCapture();

		draggingTree = 1;
		dragItem = pNMTreeView->itemNew.hItem;
	}

	*pResult = 0;
}

void CPieMenuPropPage3::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (draggingTree) {
		ClientToScreen(&point);
		m_Tree.ScreenToClient(&point);

//		m_Tree.DragMove(point);

//		UINT flags = TVHT_ONITEM;
		UINT flags = TVHT_ONITEMLABEL;

		if ((dragTarget = m_Tree.HitTest(point, &flags)) != NULL) {
#if 0
			// This prevents dropping onto child nodes
			HTREEITEM item = dragTarget;

			while (item != NULL) {
				if (item == dragItem) {
					dragTarget = NULL;
					break;
				}
				item = m_Tree.GetParentItem(item);
			}
#endif
		}
//		m_Tree.SelectDropTarget(dragTarget);
		m_Tree.SelectItem(dragTarget);
	} else {
		COlePropertyPage::OnMouseMove(nFlags, point);
	}
}


// This is needed for drag and drop editing of the tree.
HTREEITEM CPieMenuPropPage3::CopyItems(CTreeCtrl *tree, 
									   HTREEITEM src, 
									   HTREEITEM dst,
									   HTREEITEM par)
{
	TV_ITEM tvi;
	char label[256];
	int id = (int)tree->GetItemData(src);
	tvi.mask = TVIF_HANDLE | TVIF_TEXT | TVIF_STATE;
	tvi.hItem = src;
	tvi.pszText = label;
	tvi.cchTextMax = 256;
	tree->GetItem(&tvi);

	HTREEITEM newItem = NULL;
	if (dst != NULL) {
		TV_INSERTSTRUCT tvis;
		tvis.hParent = tree->GetParentItem(dst);
		tvis.hInsertAfter = tree->GetPrevSiblingItem(dst);
		if (tvis.hInsertAfter == NULL) {
			tvis.hInsertAfter = TVI_FIRST;
		}
		tvis.item.mask = TVIF_TEXT | TVIF_STATE;
		tvis.item.pszText = label;
		tvis.item.stateMask = TVIS_EXPANDED;
		tvis.item.state = tvi.state;

		newItem = tree->InsertItem(&tvis);
	} else {
		newItem = tree->InsertItem(label, par);
	}

	tree->SetItemData(newItem, (unsigned long)id);

	HTREEITEM child = tree->GetChildItem(src);

	while (child != NULL) {
		CopyItems(tree, child, NULL, newItem);
		child = tree->GetNextSiblingItem(child);
	}

	return newItem;
}


void CPieMenuPropPage3::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (mode != 0) {
		return;
	}

	if (draggingTree) {
		ClientToScreen(&point);
		m_Tree.ScreenToClient(&point);

//		m_Tree.DragMove(point);

//		UINT flags = TVHT_ONITEM;
		UINT flags = TVHT_ONITEMLABEL;

		if ((dragTarget = m_Tree.HitTest(point, &flags)) != NULL) {
			m_Tree.SelectItem(dragTarget);
		} else {
			m_Tree.SelectItem(NULL);
		}
//		m_Tree.SelectDropTarget(NULL);

		if (dragTarget != NULL) {
			int id = m_Tree.GetItemData(dragItem);
			CPieMenuEntry *ent = m_pie->entriesTree[id];
			CPieMenuLevel *lev = ent->parentLevel;

			id = m_Tree.GetItemData(dragTarget);

			CPieMenuEntry *ent2 = NULL;
			CPieMenuLevel *lev2 = NULL;

			if (id == -1) {
				HTREEITEM item2 = m_Tree.GetPrevSiblingItem(dragTarget);
				if (item2 == NULL) {
					item2 = m_Tree.GetParentItem(dragTarget);
					if (item2 == NULL) {
						ent2 = NULL;
						lev2 = m_pie->rootLevel;
					} else {
						id = m_Tree.GetItemData(item2);
						ent2 = NULL;
						lev2 = m_pie->entriesTree[id]->subLevel;
					}
				} else {
					id = m_Tree.GetItemData(item2);
					ent2 = NULL;
					lev2 = m_pie->entriesTree[id]->subLevel;
				}
			} else {
				ent2 = m_pie->entriesTree[id];
				lev2 = ent->parentLevel;
			}

#if 0
			int index, index2;

			for (index = 0; index < lev->numEntries; index++) {
				if (lev->entries[index] == ent) {
					break;
				}
			}

			for (index2 = 0; index2 < lev2->numEntries; index2++) {
				if (lev2->entries[index2] == ent2) {
					break;
				}
			}

			if (lev == lev2) {
				if (index != index2) {
					if (index < index2) {
						// Scroll back, move item forward.
						memcpy(&lev->entries[index],
							   &lev->entries[index + 1],
							   (index2 - index) * 
							   sizeof(CPieMenuEntry *));
					} else {
						// Scroll forward, move item back.
						memcpy(&lev->entries[index + 1],
							   &lev->entries[index],
							   (index - index2) * 
							   sizeof(CPieMenuEntry *));
					}
					lev->entries[index2] = ent;
				}
			} else {
#if 0
				// Insert new item
				lev2->numEntries++;
				lev2->maxEntries++;
				lev2->entries = (CPieMenuEntry **)realloc(lev2->entries,
														  lev2->numEntries * sizeof(CPieMenuEntry *));
				if (ent2 == NULL) {
					// Insert at end
					lev2->entries[index2] = ent;
				} else {
					// Scroll forward, insert entry
					memcpy(&lev2->entries[index2 + 1],
						   &lev2->entries[index2],
						   (lev2->numEntries - index2) *
						   sizeof(CPieMenuEntry *));
				}
#endif
			}

			m_pie->DecompileItems();
#endif

#if 0
			HTREEITEM newItem = CopyItems(&m_Tree, dragItem, dragTarget, NULL);

			m_Tree.DeleteItem(dragItem);
			m_Tree.SelectItem(newItem);
#else
//			m_Tree.SelectItem(dragTarget);
#endif
		}

		dragItem = NULL;

		ReleaseCapture();
//		ShowCursor(TRUE);

		draggingTree = 0;
	} else {
		COlePropertyPage::OnLButtonUp(nFlags, point);
	}
}


void CPieMenuPropPage3::OnBeginlabeleditTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;
	
	*pResult = 0;
}


void CPieMenuPropPage3::OnRButtonDown(UINT nFlags, CPoint point) 
{
	m_Tree.SelectItem(NULL);
}


void CPieMenuPropPage3::OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	m_Tree.SelectItem(NULL);
	
	*pResult = 0;
}


void CPieMenuPropPage3::SetMode(int m)
{
	mode = m;

	if (m_mode.GetCurSel() != m) {
		m_mode.SetCurSel(m);
	}

	revision = -1;
	UpdateTree();
	UpdateGallery();
}


void CPieMenuPropPage3::OnSelchangeMode1() 
{
	// not yet
//	SetMode(m_mode.GetCurSel());
	SetMode(0); 
}


/////////////////////////////////////////////////////////////////////////////
