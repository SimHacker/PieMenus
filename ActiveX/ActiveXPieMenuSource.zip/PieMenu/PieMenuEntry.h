/////////////////////////////////////////////////////////////////////////////
//
// PieMenuEntry.h : Pie Menu Entry
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// Class CPieMenuEntry


enum {
	kEntryLayoutInitialAngle = 1,
	kEntryLayoutClockwise = 2,
	kEntryLayoutFixedRadius = 4,
	kEntryAction = 16
};


class CPieMenuEntry {
	friend class CPieMenuLevel;
	friend class CPieMenuCtrl;

public:

	CPieMenuEntry() :
		label(NULL),
		labelLength(0),
		action(NULL),
		actionLength(0),
		cookedLabel(NULL),
		labelLines(0),
		indent(0),
		index(0),
		flags(0),
		direction(0),
		parentLevel(NULL),
		subLevel(NULL),
		labelWidth(0), 
		labelHeight(0),
		width(0), 
		height(0),
		x(0),
		y(0),
		xOffset(0), 
		yOffset(0),
		labelX(0), 
		labelY(0),
		edge1dx((float)0.0), 
		edge1dy((float)0.0),
		edge2dx((float)0.0),
		edge2dy((float)0.0),
		locational(0),
		angle((float)0.0),
		dx((float)0.0), 
		dy((float)0.0),
		quadrant1(0),
		slope1((float)0.0),
		quadrant2(0),
		slope2((float)0.0),
		layoutClockwise(0),
		layoutInitialAngle(0),
		layoutFixedRadius(0),
		layoutExtra(0),
		groupX(0),
		groupY(0),
		groupWidth(0),
		groupHeight(0),
		groupSlices(0),
		groupItems(0),
		visible(1)
	{
	}

	~CPieMenuEntry();

	void Measure(float ang,
				 float twist,
				 long isLocational,
				 HDC dc);
	int Overlaps(CPieMenuEntry *ent);
	void Layout(long radius);
	void Paint(HDC dc,
			   GState *g,
			   long hilite);
	void PaintBackground(HDC dc);
	void PaintLabel(HDC dc);
	void SetLabel(char *label0, int len0);
	void CookLabel();
	void SetAction(char *action0, int len0);

	char *label;
    long labelLength;
	long labelLines;
	char *cookedLabel;
	char *action;
	long actionLength;
	long indent;
	long index;
	long flags;
	long direction;

	CPieMenuLevel *parentLevel;
	CPieMenuLevel *subLevel;

	// Information related to displaying entry:

	long labelWidth, labelHeight;
    long width, height;
    long x, y;
    long xOffset, yOffset;
    long labelX, labelY;
	float edge1dx, edge1dy;
	float edge2dx, edge2dy;

	// Information used for pie menu layout & tracking:

	long locational;
    float angle;
    float dx, dy;
    long quadrant1;
    float slope1;
    long quadrant2;
    float slope2;
	long layoutClockwise;
	long layoutInitialAngle;
	long layoutFixedRadius;
	long layoutExtra;
	long groupX;
	long groupY;
	long groupWidth;
	long groupHeight;
	long groupSlices;
	long groupItems;
	long visible;
};


/////////////////////////////////////////////////////////////////////////////
