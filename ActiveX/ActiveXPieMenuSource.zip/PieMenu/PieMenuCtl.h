/////////////////////////////////////////////////////////////////////////////
//
// PieMenuCtl.h : Declaration of the CPieMenuCtrl OLE control class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl : See PieMenuCtl.cpp for implementation.


#define PI 3.1415926535897932
#define TWO_PI 6.2831853071795865
#define DEG_TO_RAD(d) (((d) * TWO_PI) / 360.0)
#define RAD_TO_DEG(d) (((d) * 360.0) / TWO_PI)

#define DEFAULT_ITEMS					CString("North\r\nWest\r\nEast\r\nSouth\r\n")
#define DEFAULT_CLOCKWISE				1
#define DEFAULT_INITIALANGLE			90
#define DEFAULT_MAXSLICES				8
#define DEFAULT_SCROLLINGMOVESCURSOR	1
#define DEFAULT_SHUFFLE					1
#define DEFAULT_STACK					1
#define DEFAULT_AUTOSCROLL				0
#define DEFAULT_LAYERRADIUS				0
#define DEFAULT_INACTIVERADIUS			8
#define DEFAULT_MINRADIUS				24
#define DEFAULT_BORDERWIDTH				8
#define DEFAULT_ITEMBORDERWIDTH			1
#define DEFAULT_ITEMGAP					1
#define DEFAULT_EXTRARADIUS				0
#define DEFAULT_FIXEDRADIUS				0
#define DEFAULT_ROUNDRECTRADIUS			12
#define DEFAULT_SLICEINSET				4
#define DEFAULT_SHRINKWRAP				0
#define DEFAULT_SHAPEWINDOW				kShapeRound
#define DEFAULT_DYNAMICSHAPING			1
#define DEFAULT_POPUPDELAY				250
#define DEFAULT_DOUBLEBUFFER			1
#define DEFAULT_BEVEL					1
#define DEFAULT_SHAPECENTERX			-1
#define DEFAULT_SHAPECENTERY			-1
#define DEFAULT_SHAPETRANSPARENTX		0
#define DEFAULT_SHAPETRANSPARENTY		0
#define DEFAULT_FOREGROUNDCOLOR			RGB(0, 0, 0)
#define DEFAULT_BACKGROUNDCOLOR			RGB(128, 128, 128)
#define DEFAULT_PIEFOREGROUNDCOLOR		RGB(0, 0, 0)
#define DEFAULT_PIEBACKGROUNDCOLOR		RGB(150, 200, 150)
#define DEFAULT_DARKCOLOR				RGB(0, 50, 0)
#define DEFAULT_LIGHTCOLOR				RGB(180, 255, 180)


class CPieMenuLevel;
class CPieMenuEntry;
class CPieMenuCtrl;
class GState;


/////////////////////////////////////////////////////////////////////////////
// Class CPieMenuCtrl


enum {
	kShapeRectangular,
	kShapeMinimal,
	kShapeRound,
	kShapeThought,
	kShapeSpeech,
	kShapeSpokes,
	kShapePicture,
	kShapePunched,
	kShapeAsshole,
	kNumShapes
};


class CPieMenuCtrl : public COleControl
{
	friend class CPieMenuLevel;
	friend class CPieMenuEntry;

	DECLARE_DYNCREATE(CPieMenuCtrl)

// Constructor
public:
	void Init();

	CPieMenuCtrl() :
		items(DEFAULT_ITEMS),
		clockwise(DEFAULT_CLOCKWISE),
		initialAngle(DEFAULT_INITIALANGLE),
		maxSlices(DEFAULT_MAXSLICES),
		scrollingMovesCursor(DEFAULT_SCROLLINGMOVESCURSOR),
		shuffle(DEFAULT_SHUFFLE),
		stack(DEFAULT_STACK),
		autoScroll(DEFAULT_AUTOSCROLL),
		layerRadius(DEFAULT_LAYERRADIUS),
		inactiveRadius(DEFAULT_INACTIVERADIUS),
		minRadius(DEFAULT_MINRADIUS),
		borderWidth(DEFAULT_BORDERWIDTH),
		itemBorderWidth(DEFAULT_ITEMBORDERWIDTH),
		itemGap(DEFAULT_ITEMGAP),
		extraRadius(DEFAULT_EXTRARADIUS),
		fixedRadius(DEFAULT_FIXEDRADIUS),
		roundRectRadius(DEFAULT_ROUNDRECTRADIUS),
		sliceInset(DEFAULT_SLICEINSET),
		shrinkWrap(DEFAULT_SHRINKWRAP),
		shapeWindow(DEFAULT_SHAPEWINDOW),
		dynamicShaping(DEFAULT_DYNAMICSHAPING),
		popupDelay(DEFAULT_POPUPDELAY),
		doubleBuffer(DEFAULT_DOUBLEBUFFER),
		itemsClean(0),
		pieNeedsLayout(1),
		firstLevel(NULL),
		rootLevel(NULL),
		level(NULL),
		numLevels(0),
		entriesTree(NULL),
		numEntriesTree(0),
		buttonsDown(0),
		trackingButton(0),
		pinnedUp(0),
		tracking(0),
		dx(0),
		dy(0),
		direction(0),
		distance(0),
		popupTimer(0),
		poppedUp(0),
		revision(0),
		bevel(1),
		shapeCenterX(DEFAULT_SHAPECENTERX),
		shapeCenterY(DEFAULT_SHAPECENTERY),
		shapeTransparentX(DEFAULT_SHAPETRANSPARENTX),
		shapeTransparentY(DEFAULT_SHAPETRANSPARENTY),
		shapeRegionValid(0),
		shapeRegion(NULL),
		pieForeground(DEFAULT_PIEFOREGROUNDCOLOR),
		pieBackground(DEFAULT_PIEBACKGROUNDCOLOR),
		light(DEFAULT_LIGHTCOLOR),
		dark(DEFAULT_DARKCOLOR),
		pieCursor(NULL),
		pieCursorID(-1),
		userData(NULL),
		ignoreNextChar(NULL),
		captureWindow(NULL)
	{
			Init();
	}

// Overrides

	// Drawing function
	virtual void OnDraw(
				CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);

	// Persistence
	virtual void DoPropExchange(CPropExchange* pPX);

	// Reset control state
	virtual void OnResetState();

// Implementation
protected:
	~CPieMenuCtrl();

	DECLARE_OLECREATE_EX(CPieMenuCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CPieMenuCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CPieMenuCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CPieMenuCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CPieMenuCtrl)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
// Dispatch maps
	//{{AFX_DISPATCH(CPieMenuCtrl)
	afx_msg BSTR GetItems();
	afx_msg void SetItems(LPCTSTR lpszNewValue);
	afx_msg long GetDirection();
	afx_msg void SetDirection(long nNewValue);
	afx_msg long GetDistance();
	afx_msg void SetDistance(long nNewValue);
	afx_msg long GetIndex();
	afx_msg void SetIndex(long nNewValue);
	afx_msg BSTR GetAction();
	afx_msg void SetAction(LPCTSTR lpszNewValue);
	afx_msg LPPICTUREDISP GetBackgroundPicture();
	afx_msg void SetBackgroundPicture(LPPICTUREDISP newValue);
	afx_msg LPPICTUREDISP GetTargetPicture();
	afx_msg void SetTargetPicture(LPPICTUREDISP newValue);
	afx_msg long GetItemCount();
	afx_msg void SetItemCount(long nNewValue);
	afx_msg long GetInactiveRadius();
	afx_msg void SetInactiveRadius(long nNewValue);
	afx_msg long GetMinRadius();
	afx_msg void SetMinRadius(long nNewValue);
	afx_msg long GetClockwise();
	afx_msg void SetClockwise(long nNewValue);
	afx_msg long GetInitialAngle();
	afx_msg void SetInitialAngle(long nNewValue);
	afx_msg long GetBorderWidth();
	afx_msg void SetBorderWidth(long nNewValue);
	afx_msg long GetItemBorderWidth();
	afx_msg void SetItemBorderWidth(long nNewValue);
	afx_msg long GetExtraRadius();
	afx_msg void SetExtraRadius(long nNewValue);
	afx_msg long GetFixedRadius();
	afx_msg void SetFixedRadius(long nNewValue);
	afx_msg BSTR GetCurrentItem();
	afx_msg void SetCurrentItem(LPCTSTR lpszNewValue);
	afx_msg long GetShrinkWrap();
	afx_msg void SetShrinkWrap(long nNewValue);
	afx_msg long GetShapeWindow();
	afx_msg void SetShapeWindow(long nNewValue);
	afx_msg long GetPopupDelay();
	afx_msg void SetPopupDelay(long nNewValue);
	afx_msg long GetDoubleBuffer();
	afx_msg void SetDoubleBuffer(long nNewValue);
	afx_msg long GetCPieMenuCtrl();
	afx_msg void SetCPieMenuCtrl(long nNewValue);
	afx_msg long GetItemGap();
	afx_msg void SetItemGap(long nNewValue);
	afx_msg long GetRevision();
	afx_msg void SetRevision(long nNewValue);
	afx_msg OLE_COLOR GetPieForegroundColor();
	afx_msg void SetPieForegroundColor(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetDarkColor();
	afx_msg void SetDarkColor(OLE_COLOR nNewValue);
	afx_msg OLE_COLOR GetLightColor();
	afx_msg void SetLightColor(OLE_COLOR nNewValue);
	afx_msg long GetBevel();
	afx_msg void SetBevel(long nNewValue);
	afx_msg long GetShapeCenterX();
	afx_msg void SetShapeCenterX(long nNewValue);
	afx_msg long GetShapeCenterY();
	afx_msg void SetShapeCenterY(long nNewValue);
	afx_msg LPPICTUREDISP GetShapePicture();
	afx_msg void SetShapePicture(LPPICTUREDISP newValue);
	afx_msg long GetDynamicShaping();
	afx_msg void SetDynamicShaping(long nNewValue);
	afx_msg long GetShapeTransparentX();
	afx_msg void SetShapeTransparentX(long nNewValue);
	afx_msg long GetShapeTransparentY();
	afx_msg void SetShapeTransparentY(long nNewValue);
	afx_msg long GetSliceInset();
	afx_msg void SetSliceInset(long nNewValue);
	afx_msg LPDISPATCH GetUserData();
	afx_msg void SetUserData(LPDISPATCH newValue);
	afx_msg long GetMaxSlices();
	afx_msg void SetMaxSlices(long nNewValue);
	afx_msg long GetLayerRadius();
	afx_msg void SetLayerRadius(long nNewValue);
	afx_msg long GetShuffle();
	afx_msg void SetShuffle(long nNewValue);
	afx_msg long GetAutoScroll();
	afx_msg void SetAutoScroll(long nNewValue);
	afx_msg OLE_COLOR GetPieBackgroundColor();
	afx_msg void SetPieBackgroundColor(OLE_COLOR nNewValue);
	afx_msg long GetScrollingMovesCursor();
	afx_msg void SetScrollingMovesCursor(long nNewValue);
	afx_msg long GetMaxSlicesIndex();
	afx_msg void SetMaxSlicesIndex(long nNewValue);
	afx_msg long GetRoundRectRadius();
	afx_msg void SetRoundRectRadius(long nNewValue);
	afx_msg BOOL GetStack();
	afx_msg void SetStack(BOOL bNewValue);
	afx_msg void PopUp(long xx, long yy);
	afx_msg void Clear();
	afx_msg BSTR GetItem(long index);
	afx_msg void SetItem(long index, LPCTSTR lpszNewValue);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

protected:
// Event maps
	//{{AFX_EVENT(CPieMenuCtrl)
	void FireAction(LPCTSTR item, LPCTSTR action, long direction, long distance)
		{FireEvent(eventidAction,EVENT_PARAM(VTS_BSTR  VTS_BSTR  VTS_I4  VTS_I4), item, action, direction, distance);}
	void FirePreview(LPCTSTR item, LPCTSTR action, long direction, long distance)
		{FireEvent(eventidPreview,EVENT_PARAM(VTS_BSTR  VTS_BSTR  VTS_I4  VTS_I4), item, action, direction, distance);}
	void FireChange(LPCTSTR item, LPCTSTR action, long direction, long distance)
		{FireEvent(eventidChange,EVENT_PARAM(VTS_BSTR  VTS_BSTR  VTS_I4  VTS_I4), item, action, direction, distance);}
	void FireCancel()
		{FireEvent(eventidCancel,EVENT_PARAM(VTS_NONE));}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

public:
	static HINSTANCE instanceHandle;

	CString items;
	long direction;
	long distance;

	long pieNeedsLayout;
	long itemsClean;

	CPieMenuLevel *firstLevel;
	CPieMenuLevel *rootLevel;
	CPieMenuLevel *level;
	long numLevels;
	CPieMenuEntry **entriesTree;
	long numEntriesTree;

    long dx, dy;
	long buttonsDown;
	long trackingButton;
	long pinnedUp;
	long tracking;

	// Information used when displaying widget:

    long borderWidth;
    long itemBorderWidth;
	long itemGap;

	// Information used to layout pie menu:

	long clockwise;
    long initialAngle;
	long maxSlices;
	long scrollingMovesCursor;
	long shuffle;
	long stack;
	long autoScroll;
	long layerRadius;
    long inactiveRadius;
    long minRadius;
    long extraRadius;
	long fixedRadius;
	long roundRectRadius;
	long sliceInset;
	long shrinkWrap;
	long shapeWindow;
	long dynamicShaping;
	long doubleBuffer;
	UINT popupTimer;
	long popupDelay;
	long poppedUp;
	long revision;
	long bevel;
	long shapeCenterX;
	long shapeCenterY;
	long shapeTransparentX;
	long shapeTransparentY;
	int shapeRegionValid;
	HRGN shapeRegion;

	COLORREF pieForeground;
	COLORREF pieBackground;
	COLORREF light;
	COLORREF dark;

	char *fontName;
	long fontSize;

	HCURSOR pieCursor;
	int pieCursorID;

	CPictureHolder backgroundPicture;
	CPictureHolder targetPicture;
	CPictureHolder shapePicture;

	LPDISPATCH userData;

	int ignoreNextChar;

	HWND captureWindow;

	// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CPieMenuCtrl)
	dispidItems = 1L,
	dispidDirection = 2L,
	dispidDistance = 3L,
	dispidIndex = 4L,
	dispidAction = 5L,
	dispidBackgroundPicture = 6L,
	dispidTargetPicture = 7L,
	dispidItemCount = 8L,
	dispidInactiveRadius = 9L,
	dispidMinRadius = 10L,
	dispidClockwise = 11L,
	dispidInitialAngle = 12L,
	dispidBorderWidth = 13L,
	dispidItemBorderWidth = 14L,
	dispidExtraRadius = 15L,
	dispidFixedRadius = 16L,
	dispidCurrentItem = 17L,
	dispidShrinkWrap = 18L,
	dispidShapeWindow = 19L,
	dispidPopupDelay = 20L,
	dispidDoubleBuffer = 21L,
	dispidCPieMenuCtrl = 22L,
	dispidItemGap = 23L,
	dispidRevision = 24L,
	dispidDarkColor = 26L,
	dispidLightColor = 27L,
	dispidBevel = 28L,
	dispidShapeCenterX = 29L,
	dispidShapeCenterY = 30L,
	dispidShapePicture = 31L,
	dispidDynamicShaping = 32L,
	dispidShapeTransparentX = 33L,
	dispidShapeTransparentY = 34L,
	dispidSliceInset = 35L,
	dispidUserData = 36L,
	dispidMaxSlices = 37L,
	dispidLayerRadius = 38L,
	dispidShuffle = 39L,
	dispidAutoScroll = 40L,
	dispidPieForegroundColor = 25L,
	dispidPieBackgroundColor = 41L,
	dispidScrollingMovesCursor = 42L,
	dispidMaxSlicesIndex = 43L,
	dispidRoundRectRadius = 44L,
	dispidStack = 45L,
	dispidPopUp = 46L,
	dispidClear = 47L,
	dispidItem = 48L,
	eventidAction = 1L,
	eventidPreview = 2L,
	eventidChange = 3L,
	eventidCancel = 4L,
	//}}AFX_DISP_ID
	};

	afx_msg void AboutBox();
	void ResetPieMenu();
	void PropogateNeedsLayout();
	long CalcPieMenuItem(long x, long y);
	void CreateLevels();
	void DestroyLevels();
	void CleanItems();
	void UpdateProps();
	void UpdateCursor(int id);
	HBRUSH CreateABrush(COLORREF color);
	HBRUSH CreateAnOleForegroundBrush();
	HBRUSH CreateAnOleBackgroundBrush();
	HBRUSH CreateAForegroundBrush();
	HBRUSH CreateABackgroundBrush();
	HBRUSH CreateALightBrush();
	HBRUSH CreateADarkBrush();
	HPEN CreateAPen(COLORREF color,
					int width = 1,
					int frame = 0);
	HPEN CreateAForegroundPen();
	HPEN CreateAForegroundFramePen();
	HPEN CreateABackgroundPen();
	HPEN CreateALightPen();
	HPEN CreateADarkPen();
	void CancelPopupTimer();
	void StartPopupTimer();
	void PopUpNow();
	void TrackDown(int x, int y);
	void TrackMove(int x, int y);
	void TrackUp(int x, int y);
	void TrackBack();
	void TrackCancel();
	void OnAnyButtonDown(UINT nFlags, CPoint point, int button);
	void OnAnyButtonUp(UINT nFlags, CPoint point, int button);
	void OnFontChanged();
	CPieMenuEntry *CurrentEntry();
	int CountLevels();
	CPieMenuLevel *GetLevel(int i);
	int GetLevelIndex(CPieMenuLevel *level);
	void DecompileItems();
	int GetShapeRegionSize(long *widthp,
						   long *heightp);
	HRGN GetShapeRegion();
	void InvalidateShapeRegion();
	int GetPictureSize(HDC dc,
					   CPictureHolder *pictHolder,
					   long *widthp,
					   long *heightp);
	HRGN MakePictureRegion(HDC dc,
						   CPictureHolder *pictHolder,
						   int transparentX,
						   int transparentY);
	long PieMenuCaptureProc(HWND hWnd, 
							UINT message, 
							WPARAM wParam, 
							LPARAM lParam);
};


/////////////////////////////////////////////////////////////////////////////
