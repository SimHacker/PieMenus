/////////////////////////////////////////////////////////////////////////////
//
// PieMenuAboutBox.cpp : About Box
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "PieMenuAboutBox.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////


extern CString PieMenuInfo;
extern CString PieMenuNotice;
extern CString PieMenuInstructions1;
extern CString PieMenuInstructions2;
extern CString PieMenuInstructions3;
extern CString PieMenuInstructions4;


/////////////////////////////////////////////////////////////////////////////
// CPieMenuAboutBox dialog


CPieMenuAboutBox::CPieMenuAboutBox(CWnd* pParent /*=NULL*/)
	: CDialog(CPieMenuAboutBox::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPieMenuAboutBox)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPieMenuAboutBox::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPieMenuAboutBox)
	DDX_Control(pDX, IDC_INFO, m_Info);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPieMenuAboutBox, CDialog)
	//{{AFX_MSG_MAP(CPieMenuAboutBox)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CPieMenuAboutBox message handlers

BOOL CPieMenuAboutBox::OnInitDialog() 
{
	CString info;
	CString msg =
		PieMenuInfo + 
		PieMenuNotice +
		PieMenuInstructions1 +
		PieMenuInstructions2 +
		PieMenuInstructions3 +
		PieMenuInstructions4 +
		PieMenuInfo;
 
	CDialog::OnInitDialog();

	m_Info.SetWindowText(msg);
	m_Info.SetFocus();
	m_Info.SetSel(0, 0);

	return FALSE; // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
