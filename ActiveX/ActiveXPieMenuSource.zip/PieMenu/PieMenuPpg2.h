/////////////////////////////////////////////////////////////////////////////
//
// PieMenuPpg2.h : Header for the CPieMenuPropPage2 property page class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage2 : See PieMenuPpg2.cpp for implementation.

class CPieMenuPropPage2 : public COlePropertyPage
{
	friend class CPieMenuCtrl;
	friend class CPieMenuLevel;
	friend class CPieMenuEntry;

	DECLARE_DYNCREATE(CPieMenuPropPage2)
	DECLARE_OLECREATE_EX(CPieMenuPropPage2)

// Construction
public:
	CPieMenuPropPage2();

// Dialog Data
	//{{AFX_DATA(CPieMenuPropPage2)
	enum { IDD = IDD_PROPPAGE_PIEMENU2 };
	CEdit	m_InitialAngleControl;
	CButton	m_ClockwiseControl;
	CComboBox	m_maxSlicesIndexControl;
	CComboBox	m_ShapeWindowControl;
	CEdit	m_ShapeTransparentYControl;
	CEdit	m_ShapeTransparentXControl;
	CEdit	m_ShapeCenterYControl;
	CEdit	m_ShapeCenterXControl;
	CEdit	m_pieText;
	long	m_BorderWidth;
	BOOL	m_Clockwise;
	long	m_ExtraRadius;
	long	m_FixedRadius;
	long	m_InactiveRadius;
	long	m_InitialAngle;
	long	m_ItemBorderWidth;
	long	m_MinRadius;
	long	m_PopupDelay;
	int		m_ShapeWindow;
	BOOL	m_ShrinkWrap;
	BOOL	m_DoubleBuffer;
	long	m_ItemGap;
	BOOL	m_Bevel;
	long	m_pieLong;
	long	m_ShapeCenterX;
	long	m_ShapeCenterY;
	long	m_ShapeTransparentX;
	long	m_ShapeTransparentY;
	BOOL	m_DynamicShaping;
	long	m_SliceInset;
	BOOL	m_Shuffle;
	BOOL	m_scrollingMovesCursor;
	int		m_maxSlicesIndex;
	long	m_RoundRectRadius;
	BOOL	m_Stack;
	//}}AFX_DATA

	int		m_maxSlices;

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CPieMenuPropPage2)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeShapewindow();
	afx_msg void OnSelchangeMaxslicesindex();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	CPieMenuCtrl *m_pie;
	int revision;
};


/////////////////////////////////////////////////////////////////////////////
