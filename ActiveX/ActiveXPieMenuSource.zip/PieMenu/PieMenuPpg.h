/////////////////////////////////////////////////////////////////////////////
//
// PieMenuPpg.h : Header for the CPieMenuPropPage property page class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage : See PieMenuPpg.cpp.cpp for implementation.

class CPieMenuPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CPieMenuPropPage)
	DECLARE_OLECREATE_EX(CPieMenuPropPage)

// Construction
public:
	CPieMenuPropPage();

// Dialog Data
	//{{AFX_DATA(CPieMenuPropPage)
	enum { IDD = IDD_PROPPAGE_PIEMENU };
	CEdit	m_pieText;
	CEdit	m_ItemText;
	CString	m_items;
	long	m_pieLong;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CPieMenuPropPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	long revision;
	CPieMenuCtrl *m_pie;

};


////////////////////////////////////////////////////////////////////////////
