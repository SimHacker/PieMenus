/////////////////////////////////////////////////////////////////////////////
//
// PieMenu.h : Header for CPiemenuApp and DLL registration
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "Resource.h"       // main symbols


/////////////////////////////////////////////////////////////////////////////
// CPiemenuApp : See PieMenu.cpp for implementation.

class CPiemenuApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
	void RegisterClasses();
	void UnregisterClasses();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;


/////////////////////////////////////////////////////////////////////////////
