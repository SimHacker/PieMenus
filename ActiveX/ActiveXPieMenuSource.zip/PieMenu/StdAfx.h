/////////////////////////////////////////////////////////////////////////////
//
// StdAfx.h : Include file for standard system and project include files.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <windowsx.h>
#include <afxctl.h>         // MFC support for OLE Controls
#include <afxcmn.h>
#include <afxres.h>
#include <Afxdisp.h>		// OLE Control container

#include <math.h>

#include "PieMenu.h"
#include "GState.h"
#include "PieMenuCtl.h"
#include "PieMenuLevel.h"
#include "PieMenuEntry.h"


/////////////////////////////////////////////////////////////////////////////
