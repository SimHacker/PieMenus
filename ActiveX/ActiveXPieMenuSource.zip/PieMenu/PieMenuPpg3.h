/////////////////////////////////////////////////////////////////////////////
//
// PieMenuPpg3.h : Header for the CPieMenuPropPage3 property page class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CPieMenuPropPage3 : See PieMenuPpg3.cpp for implementation.

class CPieMenuPropPage3 : public COlePropertyPage
{
	friend class CPieMenuCtrl;
	friend class CPieMenuLevel;
	friend class CPieMenuEntry;

	DECLARE_DYNCREATE(CPieMenuPropPage3)
	DECLARE_OLECREATE_EX(CPieMenuPropPage3)

// Constructors
public:
	CPieMenuPropPage3();
	~CPieMenuPropPage3();

	LRESULT EditPieMenuWindowProc(HWND hWnd, 
								  UINT message,
								  WPARAM wParam,
								  LPARAM lParam);
// Dialog Data
	//{{AFX_DATA(CPieMenuPropPage3)
	enum { IDD = IDD_PROPPAGE_PIEMENU3 };
	CComboBox	m_mode;
	CButton	m_itemsMode;
	CButton	m_presetsMode;
	CTreeCtrl	m_Tree;
	CStatic	m_picture;
	CEdit	m_pieText;
	int			m_pieLong;
	CPieMenuCtrl	*m_pie;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);        // DDX/DDV support

	HWND m_pieEditor;
	int curLevel;
	int curSel;
	int draggingTree;
	long revision;
	HTREEITEM dragItem;
	HTREEITEM dragTarget;
	HIMAGELIST imageList;
	int editorMouseDown;
	int editorLastX;
	int editorLastY;
	int editorRepaint;
	int mode;

	void UpdateTree();
	void UpdateTreeSel();
	void UpdateGallery();
	HTREEITEM FindEntryItem(CPieMenuEntry *ent, 
							HTREEITEM it);
	void PaintEditor();
	void PaintPieMenuEditor(HDC dc);
	void TrackPieMenuEditor(int x, 
							int y, 
							int movecur = 0);
	void FillTree(CTreeCtrl *tree,
				  int *id,
				  HTREEITEM parentItem,
				  CPieMenuLevel *lev);
	HTREEITEM CopyItems(CTreeCtrl *tree, 
					    HTREEITEM src, 
					    HTREEITEM dst,
					    HTREEITEM par);

	void SetMode(int m);

// Message maps
protected:
	//{{AFX_MSG(CPieMenuPropPage3)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeleditTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeleteitemTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBegindragTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnBeginlabeleditTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemsmode1();
	afx_msg void OnPresetsmode1();
	afx_msg void OnSelchangeMode1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
