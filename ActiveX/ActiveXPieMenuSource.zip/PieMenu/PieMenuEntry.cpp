/////////////////////////////////////////////////////////////////////////////
//
// PieMenuEntry.cpp : Pie Menu Entry
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPieMenuEntry


CPieMenuEntry::~CPieMenuEntry()
{
	if (cookedLabel != NULL) {
		delete [] cookedLabel;
		cookedLabel = NULL;
	} // if
}


void CPieMenuEntry::Measure(float ang,
							float twist,
							long isLocational,
							HDC dc)
{
	CPieMenuLevel *lev = parentLevel;
	CPieMenuCtrl *pie = lev->pie;
	SIZE labelSize;
	char *cp = cookedLabel;
	char c;

	labelWidth = 0;

	while ((c = *cp) != '\0') {
		char *end = strchr(cp, '\r');
		int len;
		if (end == NULL) {
			len = strlen(cp);
			end = cp + len;
		} else {
			len = end - cp;
			while ((*end == '\r') ||
				   (*end == '\n')) {
				end++;
			}
		} // if (end == NULL)

		::GetTextExtentPoint32(dc, 
							   cp,
							   len,
							   &labelSize);

		if (labelSize.cx > labelWidth) {
			labelWidth = labelSize.cx;
		} // if

		cp = end;
	} // while

	// Ask Windows to measure the text. Doesn't actually draw.
	RECT r;
	r.left = 0;
	r.top = 0;
	r.right = labelWidth;
	r.bottom = 9999;
	labelHeight = 
		::DrawText(dc,
				   cookedLabel,
				   -1,
				   &r,
				   DT_CENTER | DT_NOPREFIX | DT_CALCRECT);

	// Add in the border. 
	width = labelWidth + (2 * pie->itemBorderWidth);
	height = labelHeight + (2 * pie->itemBorderWidth);

	// Remember if this is a locational item.
	locational = isLocational;

	// Calculate the angle and delta of the slice center.
	angle = ang + (twist / (float)2.0);
	dx = (float)cos(angle);
	dy = (float)sin(angle);

	// Calculate the deltas of the edges. 
	edge1dx = (float)cos(ang);
	edge1dy = (float)sin(ang);
	edge2dx = (float)cos(ang + twist);
	edge2dy = (float)sin(ang + twist);

	// Calculate the quadrants and slopes of the edges.

	float numerator, denominator;

	lev->CalcQuadNumDen(
		edge1dx, edge1dy,
		quadrant1, numerator, denominator);
	slope1 = (float)numerator / (float)denominator;

	lev->CalcQuadNumDen(
		edge2dx, edge2dy,
		quadrant2, numerator, denominator);
	slope2 = (float)numerator / (float)denominator;

}


int CPieMenuEntry::Overlaps(CPieMenuEntry *you)
{
	CPieMenuCtrl *pie = parentLevel->pie;
	long fringe = pie->itemGap + 4;
	long myLeft = x - fringe;
	long myRight = x + width + fringe;
	long yourLeft = you->x - fringe;
	long yourRight = yourLeft + you->width + fringe;

	if ((yourLeft < myRight) &&
		(yourRight > myLeft)) {
		long myTop = y - fringe;
		long myBottom = y + height + fringe;
		long yourTop = you->y - fringe;
		long yourBottom = yourTop + you->height + fringe;

		if ((yourTop < myBottom) &&
			(yourBottom > myTop)) {
			return 1;
		} // if
	} // if

	return 0;
}


void CPieMenuEntry::Layout(long radius)
{
	CPieMenuCtrl *pie = parentLevel->pie;
	long gap = 1;
	float rdx = (float)(radius * dx);
	float rdy = (float)(radius * dy);

	xOffset = (long)(rdx + 0.5);
	yOffset = (long)(rdy + 0.5);

	// Special cases for top, bottom, left, and right
	if (((long)(rdx + (float)0.5)) == 0) { // top or bottom

		rdx -= (width / (float)2.0) + 1;
		if (rdy > 0) {
			rdy += gap - 3; // top
		} else {
			rdy -= height + gap - 2; // bottom
		} // if

	} else {
	
		if (((long)(rdy + (float)0.5)) == 0) { // left or right
		
			rdy -= (height / (float)2.0) + (float)0.5;
			if (rdx < 0) {
				rdx -= width + gap - 2;
			} else {
				rdx += gap - 3;
			} // if
		
		} else { // everwhere else
			
			if (pie->shrinkWrap) {
			
				// nestle the label into the spokes
				float dx1 = (edge1dx * radius);
				float dy1 = (edge1dy * radius);
				float dx2 = (edge2dx * radius);
				float dy2 = (edge2dy * radius);
				
				if (rdx < 0) {
					rdx = (min(-4, max(dx1, dx2)) - width - gap - 1);
				} else {
					rdx = (max(4, min(dx1, dx2)) + gap + 1);
				} // if
				
				if (rdy < 0) {
					rdy = (min(2, max(dy1, dy2)) - height - gap - (float)0.5);
				} else {
					rdy = (max(-2, min(dy1, dy2)) + gap - (float)0.5);
				} // if
			
			} else {
			
				// Justify the label according to its quadrant.
				int fudge = 2;

				if (rdx < 0) {
					rdx -= width - fudge;
				} else {
					rdx -= fudge;
				} // if
				
				if (rdy < 0) {
					rdy -= height - fudge;
				} else {
					rdy -= fudge;
				} // if
			
			} // if
		} // if
	} // if

	x = (long)(rdx + 0.5);
	y = (long)(rdy + 0.5);
}


void CPieMenuEntry::Paint(HDC dc,
						  GState *g,
						  long hilite)
{
	CPieMenuCtrl *pie = parentLevel->pie;
	int rrectrad = pie->roundRectRadius - 4;
	HPEN foregroundPen = g->GetForegroundPen();
	HPEN backgroundPen = g->GetBackgroundPen();
	HBRUSH foregroundBrush = g->GetForegroundBrush();
	HBRUSH backgroundBrush = g->GetBackgroundBrush();
	HFONT lastFont = g->GetLastFont(dc);
	HPEN lastHPen =
		(HPEN)::SelectObject(dc, (hilite ? foregroundPen
										 : backgroundPen));	
	HBRUSH lastHBrush =
		(HBRUSH)::SelectObject(dc, (hilite ? foregroundBrush
										   : backgroundBrush));
	COLORREF lastTextColor =
		::SetTextColor(dc, (hilite ? pie->GetBackColor()
								   : pie->GetForeColor()));
	COLORREF lastBackColor = 
		::SetBkColor(dc, (hilite ? pie->GetForeColor()
								 : pie->GetBackColor()));
	long lastBkMode =
		::SetBkMode(dc, TRANSPARENT);

	PaintBackground(dc);

	// Paint a frame if there's a submenu.
	if (subLevel != NULL) {
		HRGN rgn = ::CreateRoundRectRgn(
					x - 2,
					y - 2,
					x + width + 1,
					y + height + 1,
					rrectrad, rrectrad);
		
		::FrameRgn(dc, rgn, 
				   (hilite ? foregroundBrush 
						   : foregroundBrush),
				   1, 1);
		::DeleteObject(rgn);
	}

	PaintLabel(dc);

	::SetBkColor(dc, lastBackColor);
	::SetTextColor(dc, lastTextColor);
	::SetBkMode(dc, lastBkMode);
	::SelectObject(dc, lastFont);
	::SelectObject(dc, lastHPen);
	::SelectObject(dc, lastHBrush);
}


void CPieMenuEntry::PaintBackground(HDC dc)
{
	CPieMenuCtrl *pie = parentLevel->pie;
	int rrectrad = pie->roundRectRadius - 4;

#if 0
	if (subLevel == NULL) {
		::RoundRect(dc,
					x - 2,
					y - 2,
					x + width + 0,
					y + height + 0,
					rrectrad, rrectrad);
	} else {
#endif
		::RoundRect(dc,
					x - 3,
					y - 3,
					x + width + 1,
					y + height + 1,
					rrectrad, rrectrad);
#if 0
	} // if
#endif
}


void CPieMenuEntry::PaintLabel(HDC dc)
{
	RECT r;
	r.left = labelX;
	r.top = labelY;
	r.right = labelX + labelWidth;
	r.bottom = labelY + labelHeight;
	::DrawText(dc,
			   cookedLabel,
			   -1,
			   &r,
			   DT_CENTER | DT_NOPREFIX);
}


void CPieMenuEntry::SetLabel(char *label0, int len0)
{
	label = label0;
	labelLength = len0;

	CookLabel();
}


void CPieMenuEntry::CookLabel()
{
	if (cookedLabel != NULL) {
		delete [] cookedLabel;
		cookedLabel = NULL;
	} // if

	// Allocate just more than enough for the worst case.
	char *buf = new char[(labelLength + 2) * 2];

	// Change back-quotes to cr/lf pairs.
	int c, i, j;
	for (i = 0, j = 0, labelLines = 0; 
		 i < labelLength;
		 i++) {
		c = label[i];
		if (c == '`') {
			labelLines++;
			buf[j++] = '\r';
			c = '\n';
		} // if
		buf[j++] = c;
	} // for
	
	buf[j++] = '\0';

	if (c != '\n') {
		labelLines++;
	} // if

	cookedLabel = new char[j];
	strcpy(cookedLabel, buf);
	delete [] buf;
}


void CPieMenuEntry::SetAction(char *action0, int len0)
{
	action = action0;
	actionLength = len0;
}


/////////////////////////////////////////////////////////////////////////////
