/////////////////////////////////////////////////////////////////////////////
//
// PieMenuInfo.cpp : Implementation of the CPieMenuInfo property page class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "PieMenuInfo.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Dynamic OLE Control Creation

IMPLEMENT_DYNCREATE(CPieMenuInfo, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////


CString PieMenuInfo = "\
ActiveX Pie Menus, Copyright (C) 1997 by Don Hopkins\r\n\
(don@toad.com). All rights reserved.\r\n\
For more info, check out the Pie Menu Web Page:\r\n\
http://www.catalog.com/hopkins/piemenus/index.html\r\n\
\r\n\
";

CString PieMenuNotice = "\
NOTICE:\r\n\
\r\n\
This program is provided for unrestricted use,\r\n\
provided that this copyright message is preserved.\r\n\
There is no warranty, and no author or distributer\r\n\
accepts responsibility for any damage caused by\r\n\
this program.\r\n\
\r\n\
The ideas behind pie menus are NOT patented or\r\n\
restricted in any way, and the interface and\r\n\
algorithms may be freely copied and improved upon.\r\n\
\r\n\
This code and the ideas behind it were developed\r\n\
over time by Don Hopkins, thanks to the support of:\r\n\
University of Maryland, UniPress Software,\r\n\
Sun Microsystems, DUX Software, Turing Institute,\r\n\
Carnegie Mellon University, Kaleida Labs,\r\n\
Interval Research Corporation, and Maxis Software.\r\n\
Special thanks to Mike Gallaher, Mark Weiser, \r\n\
Ben Shneiderman, Jack Callahan, Mitch Bradley, \r\n\
Owen Densmore, John Gilmore, Ted Selker, \r\n\
Arthur van Hoff, Josh Siegel, Jutta Degener, \r\n\
Julia Menapace, Hugh Daniel, Erik Messick, \r\n\
James Gosling, Robin Schaufler, Stan Switzer, \r\n\
Brad Myers, David Levitt, Don Woods, Jim Mackraz,\r\n\
Will Wright, Ray Valdez, Bob Adams, and Vaughan Pratt.\r\n\
Pie menus were brought to earth by the number Delta-9,\r\n\
and the letters THC.\r\n\
\r\n\
";

CString PieMenuInstructions1 = "\
INSTRUCTIONS:\r\n\
\r\n\
The \"Items\" property defines a tree of nested pie\r\n\
menu items, using a very simple menu definition syntax.\r\n\
The \"Items\" property page (that you can pop up with an\r\n\
OLE control editing tool like tstcon32, Visual Basic,\r\n\
Developer Studio, or the ActiveX Control Pad) has a\r\n\
text editor into which you can type an indented\r\n\
outline of pie menu items.\r\n\
\r\n\
The indentation defines the nested menu structure.\r\n\
Each line corresponds to a menu item, that is\r\n\
grouped into a submenu according to its indentation,\r\n\
like so:\r\n\
\r\n\
File\r\n\
  New\r\n\
  Load\r\n\
  Save\r\n\
Edit\r\n\
  Cut\r\n\
  Copy\r\n\
  Paste\r\n\
\r\n\
";

CString PieMenuInstructions2 = "\
You can indent submenus by any number of spaces.\r\n\
Consecutive items with the same indentation are grouped\r\n\
together into the same submenu, like you'd expect.\r\n\
\r\n\
As a shorthand, you can list several menu items on one line,\r\n\
so they are grouped together into the same menu.\r\n\
\r\n\
File\r\n\
  New;Load;Save\r\n\
Edit\r\n\
  Cut;Copy;Paste\r\n\
\r\n\
Each menu item has a label, and an optional action, \r\n\
that defaults to the label if not specified. \r\n\
To define an action different that the label \r\n\
(which may be more convenient for your menu handler), \r\n\
use the format \"label=action\", like so:\r\n\
\r\n\
Ace=1;2;3;4;5;6;7;8;9;10;Jack=11;Queen=12;King=13\r\n\
\r\n\
";

CString PieMenuInstructions3 = "\
There are several layout formatting tags that you can\r\n\
use on the first item of a menu, to control the initial\r\n\
angle, layout direction, and inner radius of the menu.\r\n\
They start with the \"@\" character, and are followed\r\n\
by letters or numbers. To set the initial angle, you\r\n\
can use a compass direction or numeric degrees, like\r\n\
\"@n\" for North, \"@sw\" for SouthWest, or \"@90\" for 90\r\n\
degrees. \"@90\" is the same as \"@n\", and \"@0\" is the\r\n\
same as \"@e\". The default is \"@n\". It enables you to\r\n\
set the initial angle of the first menu item, like so:\r\n\
\r\n\
Up@n\r\n\
  Helter@nw\r\n\
  Skelter\r\n\
Down\r\n\
  Left@w\r\n\
  Right\r\n\
\r\n\
";

CString PieMenuInstructions4 = "\
You can set the layout direction with \"@cw\" or \"@ccw\",\r\n\
for Clockwise and Counter Clockwise. The layout routine\r\n\
places the first item at the inital angle, and subsequent\r\n\
items are evenly spaced from there, clockwise around the \r\n\
circle by default. Then the inner radius is inflated until\r\n\
none of the labels overlap. You can override the layout\r\n\
routine's calculation by specifying an internal radius\r\n\
like \"@r50\", for an internal radius of 50 pixels.\r\n\
This is the radius around which the labels are justified,\r\n\
not the outer radius of the menu, which is automatically\r\n\
calculated to encompass all of the labels.\r\n\
\r\n\
You can apply several of these formatting tags\r\n\
to one menu label by typing them consecutively, like\r\n\
the following clock face:\r\n\
\r\n\
12@n@cw;1;2;3;4;5;6;7;8;9;10;11\r\n\
\r\n\
Formatting tags are part of the label,\r\n\
not the action, so if you're using formatting\r\n\
tags and an action, the label comes first,\r\n\
then formatting tags, then the action, like so:\r\n\
\r\n\
Ace@n@ccw=1;Queen=12;King=13\r\n\
\r\n\
";


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CPieMenuInfo, COlePropertyPage)
	//{{AFX_MSG_MAP(CPieMenuInfo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CPieMenuInfo, "PIEMENU.PieMenuInfo.1",
	0x87351bc4, 0x983f, 0x11cf, 0x9a, 0x4b, 0x54, 0xa4, 0xff, 0xc2, 0, 0)


/////////////////////////////////////////////////////////////////////////////
// CPieMenuInfo::CPieMenuInfoFactory::UpdateRegistry -
// Adds or removes system registry entries for CPieMenuPropPage

BOOL CPieMenuInfo::CPieMenuInfoFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_PIEMENU_INFO);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuInfo::CPieMenuInfo - Constructor

CPieMenuInfo::CPieMenuInfo() :
	COlePropertyPage(IDD, IDS_PIEMENUINFO_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CPieMenuInfo)
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuInfo::DoDataExchange message handler
	
void CPieMenuInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPieMenuInfo)
	DDX_Control(pDX, IDC_INFO, m_Info);
	//}}AFX_DATA_MAP
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuInfo message handlers

BOOL CPieMenuInfo::OnInitDialog() 
{
	COlePropertyPage::OnInitDialog();
	CString msg = 
		PieMenuInfo + 
		PieMenuNotice +
		PieMenuInstructions1 +
		PieMenuInstructions2 +
		PieMenuInstructions3 +
		PieMenuInstructions4 +
		PieMenuInfo;
 
	m_Info.SetWindowText(msg);
	m_Info.SetFocus();
	m_Info.SetSel(0, 0);

	return FALSE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
