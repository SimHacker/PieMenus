# Microsoft Developer Studio Project File - Name="piemenu" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 5.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

CFG=piemenu - Win32 Release
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "PieMenu.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "PieMenu.mak" CFG="piemenu - Win32 Release"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "piemenu - Win32 Release" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE "piemenu - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "piemenu - Win32 Profile" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE 

# Begin Project
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "piemenu - Win32 Release"

# PROP BASE Use_MFC 2
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir ".\Release"
# PROP BASE Intermediate_Dir ".\Release"
# PROP BASE Target_Ext "ocx"
# PROP BASE Target_Dir ""
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 0
# PROP Output_Dir ".\Release"
# PROP Intermediate_Dir ".\Release"
# PROP Target_Ext "ocx"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 /nologo /subsystem:windows /dll /machine:I386
# Begin Custom Build - Registering OLE control...
OutDir=.\.\Release
TargetPath=.\Release\PieMenu.ocx
InputPath=.\Release\PieMenu.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)"

# End Custom Build

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

# PROP BASE Use_MFC 2
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir ".\Debug"
# PROP BASE Intermediate_Dir ".\Debug"
# PROP BASE Target_Ext "ocx"
# PROP BASE Target_Dir ""
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 1
# PROP Output_Dir ".\Debug"
# PROP Intermediate_Dir ".\Debug"
# PROP Target_Ext "ocx"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "_DEBUG" /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /dll /debug /machine:I386
# ADD LINK32 /nologo /subsystem:windows /dll /debug /machine:I386
# Begin Custom Build
OutDir=.\.\Debug
TargetPath=.\Debug\PieMenu.ocx
InputPath=.\Debug\PieMenu.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)"

# End Custom Build

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

# PROP BASE Use_MFC 2
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir ".\piemenu_"
# PROP BASE Intermediate_Dir ".\piemenu_"
# PROP BASE Target_Ext "ocx"
# PROP BASE Target_Dir ""
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 0
# PROP Output_Dir ".\Profile"
# PROP Intermediate_Dir ".\Profile"
# PROP Target_Ext "ocx"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR /Yu"stdafx.h" /c
# ADD CPP /nologo /MD /W3 /GX /Zi /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 /nologo /subsystem:windows /dll /profile /map /debug /machine:I386
# Begin Custom Build - Registering OLE control...
OutDir=.\.\Profile
TargetPath=.\Profile\PieMenu.ocx
InputPath=.\Profile\PieMenu.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	regsvr32 /s /c "$(TargetPath)"

# End Custom Build

!ENDIF 

# Begin Target

# Name "piemenu - Win32 Release"
# Name "piemenu - Win32 Debug"
# Name "piemenu - Win32 Profile"
# Begin Group "Documentation"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Doc\ActiveXPieMenus.html
# End Source File
# Begin Source File

SOURCE=.\Doc\PieMenuDemo.html
# End Source File
# Begin Source File

SOURCE=.\Doc\PieMenuDescription.html
# End Source File
# Begin Source File

SOURCE=.\Doc\PieMenuDocumentation.html
# End Source File
# Begin Source File

SOURCE=.\Doc\PieMenuEditor.html
# End Source File
# Begin Source File

SOURCE=.\Doc\PieMenuInstructions.html
# End Source File
# Begin Source File

SOURCE=.\README.txt
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl;fi;fd"
# Begin Source File

SOURCE=.\GState.h
# End Source File
# Begin Source File

SOURCE=.\piemenu.def
# End Source File
# Begin Source File

SOURCE=.\PieMenu.h
# End Source File
# Begin Source File

SOURCE=.\piemenu.odl
# End Source File
# Begin Source File

SOURCE=.\PieMenuAboutBox.h
# End Source File
# Begin Source File

SOURCE=.\PieMenuCtl.h
# End Source File
# Begin Source File

SOURCE=.\PieMenuEntry.h
# End Source File
# Begin Source File

SOURCE=.\PieMenuInfo.h
# End Source File
# Begin Source File

SOURCE=.\PieMenuLevel.h
# End Source File
# Begin Source File

SOURCE=.\PieMenuPpg.h
# End Source File
# Begin Source File

SOURCE=.\PieMenuPpg2.h
# End Source File
# Begin Source File

SOURCE=.\PieMenuPpg3.h
# End Source File
# Begin Source File

SOURCE=.\resource.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# End Group
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;hpj;bat;for;f90"
# Begin Source File

SOURCE=.\GState.cpp
# End Source File
# Begin Source File

SOURCE=.\piemenu.cpp
# End Source File
# Begin Source File

SOURCE=.\PieMenuAboutBox.cpp
# End Source File
# Begin Source File

SOURCE=.\PieMenuCtl.cpp
# End Source File
# Begin Source File

SOURCE=.\PieMenuEntry.cpp
# End Source File
# Begin Source File

SOURCE=.\PieMenuInfo.cpp
# End Source File
# Begin Source File

SOURCE=.\PieMenuLevel.cpp
# End Source File
# Begin Source File

SOURCE=.\PieMenuPpg.cpp
# End Source File
# Begin Source File

SOURCE=.\PieMenuPpg2.cpp
# End Source File
# Begin Source File

SOURCE=.\PieMenuPpg3.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;cnt;rtf;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\Resources\AboutDLL.ico
# End Source File
# Begin Source File

SOURCE=.\Resources\bitmap1.bmp
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00001.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00002.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00003.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00004.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00005.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00006.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00007.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00008.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00009.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00010.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00011.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00012.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00013.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00014.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00015.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00016.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00017.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00018.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00019.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00020.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00021.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00022.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00023.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00024.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00025.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00026.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00027.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cur00028.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Cursor1.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower1.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower10.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower11.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower12.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower13.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower14.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower15.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower16.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower2.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower3.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower4.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower5.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower6.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower7.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower8.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Flower9.cur
# End Source File
# Begin Source File

SOURCE=.\Resources\Ico00001.ico
# End Source File
# Begin Source File

SOURCE=.\Resources\PieMenu.ico
# End Source File
# Begin Source File

SOURCE=.\piemenu.rc

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Resources\PieMenu2.bmp
# End Source File
# Begin Source File

SOURCE=.\Resources\PieMenuCtl.bmp
# End Source File
# End Group
# End Target
# End Project
# Section piemenu : {87351BC1-983F-11CF-9A4B-54A4FFC00000}
# 	2:5:Class:CPieMenu
# 	2:10:HeaderFile:piemenuwrapper.h
# 	2:8:ImplFile:piemenuwrapper.cpp
# End Section
# Section piemenu : {BEF6E003-A874-101A-8BBA-00AA00300CAB}
# 	2:5:Class:COleFont
# 	2:10:HeaderFile:font.h
# 	2:8:ImplFile:font.cpp
# End Section
# Section piemenu : {87351BC3-983F-11CF-9A4B-54A4FFC00000}
# 	0:9:Picture.h:C:\USERS\DHopkins\piemenu\Picture.h
# 	0:8:Font.cpp:C:\USERS\DHopkins\piemenu\Font.cpp
# 	0:6:Font.h:C:\USERS\DHopkins\piemenu\Font.h
# 	0:11:Picture.cpp:C:\USERS\DHopkins\piemenu\Picture.cpp
# 	0:11:PieMenu.cpp:C:\USERS\DHopkins\piemenu\PieMenu1.cpp
# 	0:9:PieMenu.h:C:\USERS\DHopkins\piemenu\PieMenu1.h
# 	2:21:DefaultSinkHeaderFile:piemenuwrapper.h
# 	2:16:DefaultSinkClass:CPieMenu
# End Section
# Section piemenu : {7BF80981-BF32-101A-8BBB-00AA00300CAB}
# 	2:5:Class:CPicture
# 	2:10:HeaderFile:picture.h
# 	2:8:ImplFile:picture.cpp
# End Section
# Section OLE Controls
# 	{87351BC3-983F-11CF-9A4B-54A4FFC00000}
# End Section
