/////////////////////////////////////////////////////////////////////////////
//
// PieMenuCtl.cpp : Pie Menu ActiveX Control.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
// mailto:don@toad.com
// mailto:dhopkins@maxis.com
// http://www.catalog.com/hopkins
// http://www.catalog.com/hopkins/piemenus/index.html
//
// This program is provided for unrestricted use, 
// provided that this copyright message is preserved. 
// There is no warranty, and no author or distributer 
// accepts responsibility for any damage caused by 
// this program. 
// 
// This code and the ideas behind it were developed 
// over time by Don Hopkins, thanks to the support of:
// University of Maryland, UniPress Software, 
// Sun Microsystems, DUX Software, Turing Institute, 
// Carnegie Mellon University, Kaleida Labs, 
// Interval Research Corporation, and Maxis Software.
//
// The ideas behind pie menus are not patented or 
// restricted in any way, and the interface and 
// algorithms may be freely copied and improved upon. 
// Don't bother patenting the idea yourself, because 
// it's been around for a long time, and your patent
// will be easy to challenge. 
//
// Pie menus are the natural result of optimizing an 
// interface with respect to Fitt's Law, which states 
// that the time it takes to hit a target (and the error 
// rate) is lower, the bigger and closer the target. 
// So all the pie menu targets are big and close. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"


// Headers for property pages etc.
#include "PieMenuInfo.h"
#include "PieMenuPpg.h"
#include "PieMenuPpg2.h"
#include "PieMenuPpg3.h"
#include "PieMenuAboutBox.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Dynamic OLE Control Creation

IMPLEMENT_DYNCREATE(CPieMenuCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CPieMenuCtrl, COleControl)
	//{{AFX_MSG_MAP(CPieMenuCtrl)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_TIMER()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MBUTTONDOWN()
	ON_WM_MBUTTONUP()
	ON_WM_CHAR()
	ON_WM_KEYDOWN()
	ON_WM_KEYUP()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_MOUSEWHEEL()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_EDIT, OnEdit)
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CPieMenuCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CPieMenuCtrl)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Items", GetItems, SetItems, VT_BSTR)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Direction", GetDirection, SetDirection, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Distance", GetDistance, SetDistance, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Index", GetIndex, SetIndex, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Action", GetAction, SetAction, VT_BSTR)
	DISP_PROPERTY_EX(CPieMenuCtrl, "BackgroundPicture", GetBackgroundPicture, SetBackgroundPicture, VT_PICTURE)
	DISP_PROPERTY_EX(CPieMenuCtrl, "TargetPicture", GetTargetPicture, SetTargetPicture, VT_PICTURE)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ItemCount", GetItemCount, SetItemCount, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "InactiveRadius", GetInactiveRadius, SetInactiveRadius, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "MinRadius", GetMinRadius, SetMinRadius, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Clockwise", GetClockwise, SetClockwise, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "InitialAngle", GetInitialAngle, SetInitialAngle, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "BorderWidth", GetBorderWidth, SetBorderWidth, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ItemBorderWidth", GetItemBorderWidth, SetItemBorderWidth, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ExtraRadius", GetExtraRadius, SetExtraRadius, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "FixedRadius", GetFixedRadius, SetFixedRadius, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "CurrentItem", GetCurrentItem, SetCurrentItem, VT_BSTR)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ShrinkWrap", GetShrinkWrap, SetShrinkWrap, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ShapeWindow", GetShapeWindow, SetShapeWindow, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "PopupDelay", GetPopupDelay, SetPopupDelay, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "DoubleBuffer", GetDoubleBuffer, SetDoubleBuffer, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "CPieMenuCtrl", GetCPieMenuCtrl, SetCPieMenuCtrl, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ItemGap", GetItemGap, SetItemGap, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Revision", GetRevision, SetRevision, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "PieForegroundColor", GetPieForegroundColor, SetPieForegroundColor, VT_COLOR)
	DISP_PROPERTY_EX(CPieMenuCtrl, "DarkColor", GetDarkColor, SetDarkColor, VT_COLOR)
	DISP_PROPERTY_EX(CPieMenuCtrl, "LightColor", GetLightColor, SetLightColor, VT_COLOR)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Bevel", GetBevel, SetBevel, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ShapeCenterX", GetShapeCenterX, SetShapeCenterX, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ShapeCenterY", GetShapeCenterY, SetShapeCenterY, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ShapePicture", GetShapePicture, SetShapePicture, VT_PICTURE)
	DISP_PROPERTY_EX(CPieMenuCtrl, "DynamicShaping", GetDynamicShaping, SetDynamicShaping, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ShapeTransparentX", GetShapeTransparentX, SetShapeTransparentX, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ShapeTransparentY", GetShapeTransparentY, SetShapeTransparentY, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "SliceInset", GetSliceInset, SetSliceInset, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "UserData", GetUserData, SetUserData, VT_DISPATCH)
	DISP_PROPERTY_EX(CPieMenuCtrl, "MaxSlices", GetMaxSlices, SetMaxSlices, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "LayerRadius", GetLayerRadius, SetLayerRadius, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Shuffle", GetShuffle, SetShuffle, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "AutoScroll", GetAutoScroll, SetAutoScroll, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "PieBackgroundColor", GetPieBackgroundColor, SetPieBackgroundColor, VT_COLOR)
	DISP_PROPERTY_EX(CPieMenuCtrl, "ScrollingMovesCursor", GetScrollingMovesCursor, SetScrollingMovesCursor, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "MaxSlicesIndex", GetMaxSlicesIndex, SetMaxSlicesIndex, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "RoundRectRadius", GetRoundRectRadius, SetRoundRectRadius, VT_I4)
	DISP_PROPERTY_EX(CPieMenuCtrl, "Stack", GetStack, SetStack, VT_BOOL)
	DISP_FUNCTION(CPieMenuCtrl, "PopUp", PopUp, VT_EMPTY, VTS_I4 VTS_I4)
	DISP_FUNCTION(CPieMenuCtrl, "Clear", Clear, VT_EMPTY, VTS_NONE)
	DISP_PROPERTY_PARAM(CPieMenuCtrl, "Item", GetItem, SetItem, VT_BSTR, VTS_I4)
	DISP_STOCKPROP_BACKCOLOR()
	DISP_STOCKPROP_FORECOLOR()
	DISP_STOCKPROP_FONT()
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CPieMenuCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CPieMenuCtrl, COleControl)
	//{{AFX_EVENT_MAP(CPieMenuCtrl)
	EVENT_CUSTOM("Action", FireAction, VTS_BSTR  VTS_BSTR  VTS_I4  VTS_I4)
	EVENT_CUSTOM("Preview", FirePreview, VTS_BSTR  VTS_BSTR  VTS_I4  VTS_I4)
	EVENT_CUSTOM("Change", FireChange, VTS_BSTR  VTS_BSTR  VTS_I4  VTS_I4)
	EVENT_CUSTOM("Cancel", FireCancel, VTS_NONE)
	EVENT_STOCK_CLICK()
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CPieMenuCtrl, 7)
	PROPPAGEID(CPieMenuInfo::guid)
	PROPPAGEID(CPieMenuPropPage::guid)
	PROPPAGEID(CPieMenuPropPage2::guid)
	PROPPAGEID(CPieMenuPropPage3::guid)
	PROPPAGEID(CLSID_CFontPropPage)
	PROPPAGEID(CLSID_CColorPropPage)
	PROPPAGEID(CLSID_CPicturePropPage)
END_PROPPAGEIDS(CPieMenuCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CPieMenuCtrl, "PIEMENU.PieMenuCtrl.1",
	0x87351bc3, 0x983f, 0x11cf, 0x9a, 0x4b, 0x54, 0xa4, 0xff, 0xc0, 0, 0)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CPieMenuCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DPieMenu =
		{ 0x87351bc1, 0x983f, 0x11cf, { 0x9a, 0x4b, 0x54, 0xa4, 0xff, 0xc0, 0, 0 } };
const IID BASED_CODE IID_DPieMenuEvents =
		{ 0x87351bc2, 0x983f, 0x11cf, { 0x9a, 0x4b, 0x54, 0xa4, 0xff, 0xc0, 0, 0 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwPieMenuOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CPieMenuCtrl, IDS_PIEMENU, _dwPieMenuOleMisc)


/////////////////////////////////////////////////////////////////////////////
// Instance handle of this module.

HINSTANCE CPieMenuCtrl::instanceHandle = NULL;


/////////////////////////////////////////////////////////////////////////////


long FAR PASCAL PieLevelWindowProc(HWND hWnd, UINT message, 
								   WPARAM wParam, LPARAM lParam);


long FAR PASCAL PieLevelWindowProc(HWND hWnd, UINT message, 
								   WPARAM wParam, LPARAM lParam)
{
	CPieMenuLevel *level = 
		(CPieMenuLevel *)GetWindowLong(hWnd, GWL_USERDATA);

	return level->PieLevelWindowProc(hWnd, message, 
									 wParam, lParam);
}


/////////////////////////////////////////////////////////////////////////////


long FAR PASCAL PieMenuCaptureProc(HWND hWnd, UINT message, 
								   WPARAM wParam, LPARAM lParam);


long FAR PASCAL PieMenuCaptureProc(HWND hWnd, UINT message, 
								   WPARAM wParam, LPARAM lParam)
{
	CPieMenuCtrl *pie = 
		(CPieMenuCtrl *)GetWindowLong(hWnd, GWL_USERDATA);

	return pie->PieMenuCaptureProc(hWnd, message, 
								   wParam, lParam);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl::CPieMenuCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CPieMenuCtrl

BOOL CPieMenuCtrl::CPieMenuCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_PIEMENU,
			IDB_PIEMENU,
			TRUE,                       //  Insertable
			_dwPieMenuOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl::CPieMenuCtrl - Constructor

void CPieMenuCtrl::Init()
{
	InitializeIIDs(&IID_DPieMenu, &IID_DPieMenuEvents);

	if (instanceHandle == NULL) {
		instanceHandle = AfxGetInstanceHandle();
	}

	UpdateProps();

	static int classRegistered = 0;
	if (classRegistered == 0) {
		classRegistered = 1;

		WNDCLASSEX popupWindowClass;

		popupWindowClass.cbSize = sizeof(WNDCLASSEX);
		popupWindowClass.style = 0;
		popupWindowClass.lpfnWndProc = PieLevelWindowProc;
		popupWindowClass.cbClsExtra = 0;
		popupWindowClass.cbWndExtra = 0;
		popupWindowClass.hInstance = instanceHandle;
		popupWindowClass.hIcon = LoadIcon(instanceHandle,
										  MAKEINTRESOURCE(IDI_PIEICON));
		popupWindowClass.hCursor = NULL;
		popupWindowClass.hbrBackground = NULL;
		popupWindowClass.lpszMenuName = NULL;
		popupWindowClass.lpszClassName = "PIEMENUPOPUP";
		popupWindowClass.hIconSm = LoadIcon(instanceHandle,
											MAKEINTRESOURCE(IDI_PIEICONSM));

		RegisterClassEx(&popupWindowClass);

#if 0
		WNDCLASSEX captureWindowClass;

		captureWindowClass.cbSize = sizeof(WNDCLASSEX);
		captureWindowClass.style = 0;
		captureWindowClass.lpfnWndProc = ::PieMenuCaptureProc;
		captureWindowClass.cbClsExtra = 0;
		captureWindowClass.cbWndExtra = 0;
		captureWindowClass.hInstance = instanceHandle;
		captureWindowClass.hIcon = LoadIcon(instanceHandle,
										  MAKEINTRESOURCE(IDI_PIEICON));
		captureWindowClass.hCursor = NULL;
		captureWindowClass.hbrBackground = NULL;
		captureWindowClass.lpszMenuName = NULL;
		captureWindowClass.lpszClassName = "PIEMENUCAPTURE";
		captureWindowClass.hIconSm = LoadIcon(instanceHandle,
											MAKEINTRESOURCE(IDI_PIEICONSM));

		RegisterClassEx(&captureWindowClass);
#endif
	}

#if 0
	if (captureWindow == NULL) {
		int screenWidth = GetSystemMetrics(SM_CXSCREEN);
		int screenHeight = GetSystemMetrics(SM_CYSCREEN);

		// Create a new capture window with the appropriate event handler.
		captureWindow = 
			::CreateWindowEx(
				0,
				"PIEMENUCAPTURE",
				"PIEMENUCAPTURE",
				WS_POPUP,
				0,
				0,
				screenWidth,
				screenHeight,
				NULL,
				NULL,
				CPieMenuCtrl::instanceHandle,
				NULL);

		SetWindowLong(captureWindow, GWL_USERDATA, (long)this);
	} // if
#endif

}


void CPieMenuCtrl::UpdateProps()
{
	DestroyLevels();

	SetModifiedFlag();

	pieNeedsLayout = 1;
	if (rootLevel) {
		rootLevel->SetNeedsLayout();
	}
}


void CPieMenuCtrl::UpdateCursor(int id)
{
	if (id != pieCursorID) {
		pieCursorID = id;
		HCURSOR last = pieCursor;

		if (pieCursor != NULL) {
//			::DeleteObject(pieCursor);
			pieCursor = NULL;
		}

		pieCursor =
			::LoadCursor(
				instanceHandle, 
				MAKEINTRESOURCE(id));

		if (pieCursor != NULL) {
			::SetCursor(pieCursor);
		} else {
			::SetCursor(pieCursor);
		} // if
	} // if
}


HBRUSH CPieMenuCtrl::CreateABrush(COLORREF color)
{
	LOGBRUSH logBrush;
	logBrush.lbStyle = BS_SOLID;
	logBrush.lbColor = color;
	logBrush.lbHatch = 0;
	return ::CreateBrushIndirect(&logBrush);
}


HBRUSH CPieMenuCtrl::CreateAnOleForegroundBrush()
{
	return CreateABrush(GetForeColor());
}


HBRUSH CPieMenuCtrl::CreateAnOleBackgroundBrush()
{
	return CreateABrush(GetBackColor());
}


HBRUSH CPieMenuCtrl::CreateAForegroundBrush()
{
	return CreateABrush(pieForeground);
}


HBRUSH CPieMenuCtrl::CreateABackgroundBrush()
{
	return CreateABrush(pieBackground);
}


HBRUSH CPieMenuCtrl::CreateALightBrush()
{
	return CreateABrush(light);
}


HBRUSH CPieMenuCtrl::CreateADarkBrush()
{
	return CreateABrush(dark);
}


HPEN CPieMenuCtrl::CreateAPen(COLORREF color,
							  int width,
							  int frame)
{
	LOGBRUSH logBrush;
	logBrush.lbStyle = BS_SOLID;
	logBrush.lbColor = color;
	logBrush.lbHatch = 0;
	return ::ExtCreatePen(
		PS_COSMETIC | 
		(frame ? PS_INSIDEFRAME : PS_SOLID),
		width,
		&logBrush,
		0,
		0);
}


HPEN CPieMenuCtrl::CreateAForegroundPen()
{
	return CreateAPen(pieForeground, 1, 0);
}


HPEN CPieMenuCtrl::CreateAForegroundFramePen()
{
	return CreateAPen(pieForeground, 1, 1);
}


HPEN CPieMenuCtrl::CreateABackgroundPen()
{
	return CreateAPen(pieBackground, 1, 0);
}


HPEN CPieMenuCtrl::CreateALightPen()
{
	return CreateAPen(light, 1, 0);
}


HPEN CPieMenuCtrl::CreateADarkPen()
{
	return CreateAPen(dark, 1, 0);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl::~CPieMenuCtrl - Destructor

CPieMenuCtrl::~CPieMenuCtrl()
{
	DestroyLevels();
	if (userData != NULL) {
		userData->Release();
		userData = NULL;
	}
	if (shapeRegion != NULL) {
		::DeleteObject(shapeRegion);
		shapeRegion = NULL;
	}
	if (pieCursor != NULL) {
		::DeleteObject(pieCursor);
		pieCursor = NULL;
	}
//	if (captureWindow != NULL) {
//		::DeleteWindow(captureWindow);
//		captureWindow = NULL;
//	}
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl::OnDraw - Drawing function

void CPieMenuCtrl::OnDraw(CDC* pdc, 
						  const CRect& rcBounds, 
						  const CRect& rcInvalid)
{
	short picType = targetPicture.GetType();
	if ((picType != PICTYPE_NONE) &&
		(picType != PICTYPE_UNINITIALIZED)) {
		targetPicture.Render(pdc, rcBounds, rcBounds);
	} else {
		GState g(this);
		pdc->FillRect(rcBounds, 
					  CBrush::FromHandle(g.GetOleBackgroundBrush()));
		pdc->FrameRect(rcBounds, 
					   CBrush::FromHandle(g.GetOleForegroundBrush()));
	}
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl::DoPropExchange - Persistence support

void CPieMenuCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	PX_Picture(pPX, "BackgroundPicture", backgroundPicture);
	PX_Picture(pPX, "TargetPicture", targetPicture);
	PX_Picture(pPX, "ShapePicture", shapePicture);

	PX_Color(pPX, "PieForegroundColor", pieForeground, DEFAULT_PIEFOREGROUNDCOLOR);
	PX_Color(pPX, "PieBackgroundColor", pieBackground, DEFAULT_PIEBACKGROUNDCOLOR);
	PX_Color(pPX, "LightColor", light, DEFAULT_LIGHTCOLOR);
	PX_Color(pPX, "DarkColor", dark, DEFAULT_DARKCOLOR);

	PX_String(pPX, "Items", items, DEFAULT_ITEMS);
	PX_Long(pPX, "Clockwise", clockwise, DEFAULT_CLOCKWISE);
	PX_Long(pPX, "InitialAngle", initialAngle, DEFAULT_INITIALANGLE);
	PX_Long(pPX, "MaxSlices", maxSlices, DEFAULT_MAXSLICES);
	PX_Long(pPX, "Shuffle", shuffle, DEFAULT_SHUFFLE);
	PX_Long(pPX, "Stack", stack, DEFAULT_STACK);
	PX_Long(pPX, "AutoScroll", autoScroll, DEFAULT_AUTOSCROLL);
	PX_Long(pPX, "LayerRadius", layerRadius, DEFAULT_LAYERRADIUS);
	PX_Long(pPX, "InactiveRadius", inactiveRadius, DEFAULT_INACTIVERADIUS);
	PX_Long(pPX, "MinRadius", minRadius, DEFAULT_MINRADIUS);
	PX_Long(pPX, "RoundRectRadius", roundRectRadius, DEFAULT_ROUNDRECTRADIUS);
	PX_Long(pPX, "BorderWidth", borderWidth, DEFAULT_BORDERWIDTH);
	PX_Long(pPX, "ItemBorderWidth", itemBorderWidth, DEFAULT_ITEMBORDERWIDTH);
	PX_Long(pPX, "ItemGap", itemGap, DEFAULT_ITEMGAP);
	PX_Long(pPX, "ExtraRadius", extraRadius, DEFAULT_EXTRARADIUS);
	PX_Long(pPX, "FixedRadius", fixedRadius, DEFAULT_FIXEDRADIUS);
	PX_Long(pPX, "SliceInset", sliceInset, DEFAULT_SLICEINSET);
	PX_Long(pPX, "ShrinkWrap", shrinkWrap, DEFAULT_SHRINKWRAP);
	PX_Long(pPX, "ShapeWindow", shapeWindow, DEFAULT_SHAPEWINDOW);
	PX_Long(pPX, "DynamicShaping", dynamicShaping, DEFAULT_DYNAMICSHAPING);
	PX_Long(pPX, "PopupDelay", popupDelay, DEFAULT_POPUPDELAY);
	PX_Long(pPX, "DoubleBuffer", doubleBuffer, DEFAULT_DOUBLEBUFFER);
	PX_Long(pPX, "Bevel", bevel, DEFAULT_BEVEL);
	PX_Long(pPX, "ShapeCenterX", shapeCenterX, DEFAULT_SHAPECENTERX);
	PX_Long(pPX, "ShapeCenterY", shapeCenterY, DEFAULT_SHAPECENTERY);
	PX_Long(pPX, "ShapeTransparentX", shapeTransparentX, DEFAULT_SHAPETRANSPARENTX);
	PX_Long(pPX, "ShapeTransparentY", shapeTransparentY, DEFAULT_SHAPETRANSPARENTY);
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl::PieMenuCaptureProc

long CPieMenuCtrl::PieMenuCaptureProc(HWND hWnd, UINT message, 
									  WPARAM wParam, LPARAM lParam)
{
	long result = 1;

    switch (message) {

	case WM_PAINT:
	case WM_NCPAINT:
		break;

	case WM_CHAR:
		OnChar(wParam, 
			   (int)(short)LOWORD(lParam),
			   (UINT)HIWORD(lParam));
		break;

	case WM_KEYDOWN:
		OnKeyDown(wParam, 
				  (int)(short)LOWORD(lParam),
				  (UINT)HIWORD(lParam));
		break;

	case WM_KEYUP:
		OnKeyUp(wParam, 
				(int)(short)LOWORD(lParam),
				(UINT)HIWORD(lParam));
		break;

	case 0xcccb: // I don't know why I'm getting this but I am...
	case WM_MOUSEWHEEL:
		OnMouseWheel(LOWORD(wParam),
					 (int)HIWORD(wParam),
					 CPoint(LOWORD(lParam), HIWORD(lParam)));
		break;

	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_MOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDBLCLK:
		{
			CPoint pt;
			pt.x = LOWORD(lParam);
			pt.y = HIWORD(lParam);

			::ClientToScreen((HWND)wParam, &pt);
			ScreenToClient(&pt);

			switch (message) {
			case WM_LBUTTONDOWN:
				OnLButtonDown(wParam, pt);
				break;
			case WM_RBUTTONDOWN:
				OnRButtonDown(wParam, pt);
				break;
			case WM_MOUSEMOVE:
				OnMouseMove(wParam, pt);
				break;
			case WM_LBUTTONUP:
				OnLButtonUp(wParam, pt);
				break;
			case WM_RBUTTONUP:
				OnRButtonUp(wParam, pt);
				break;
			case WM_LBUTTONDBLCLK:
				OnLButtonDblClk(wParam, pt);
				break;
			case WM_RBUTTONDBLCLK:
				OnRButtonDblClk(wParam, pt);
				break;
			} // switch

			return TRUE;
		} // scope
		break;

	// Ignore these
	case WM_ACTIVATEAPP:
	case WM_NCCREATE:
	case WM_NCDESTROY:
	case WM_NCCALCSIZE:
	case WM_CREATE:
	case WM_DESTROY:
	case WM_SIZE:
	case WM_MOVE:
	case WM_WINDOWPOSCHANGING:
	case WM_WINDOWPOSCHANGED:
	case WM_NCACTIVATE:
	case WM_ACTIVATE:
	case WM_SETFOCUS:
	case WM_KILLFOCUS:
	case WM_SHOWWINDOW:
	case WM_ERASEBKGND:
	case WM_NCHITTEST:
	case WM_AFXFIRST + 0x0e: // 36e
		result = ::DefWindowProc(hWnd, message, wParam, lParam);
		break;

	default:
		result = ::DefWindowProc(hWnd, message, wParam, lParam);
		break;

    } // switch

    return result;
}


/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl::OnResetState - Reset control to default state

void CPieMenuCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	UpdateProps();
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl::AboutBox - Display an "About" box to the user

void CPieMenuCtrl::AboutBox()
{
	CPieMenuAboutBox dlgAbout;
	dlgAbout.DoModal();
}


CPieMenuEntry *CPieMenuCtrl::CurrentEntry()
{
	CPieMenuEntry *result = NULL;

	if (level != NULL) {
		return level->CurrentEntry();
	}

	return NULL;
}


int CPieMenuCtrl::CountLevels()
{
	CreateLevels();
	return numLevels;
}


CPieMenuLevel *CPieMenuCtrl::GetLevel(int i)
{
	CreateLevels();

	if (firstLevel == NULL) {
		return NULL;
	} else {
		// The linked list is in reverse order.
		return firstLevel->GetLevel(numLevels - i - 1);
	}
}


int CPieMenuCtrl::GetLevelIndex(CPieMenuLevel *level)
{
	int i = 0;
	CPieMenuLevel *l = firstLevel;

	while (l != NULL) {
		if (l == level) {
			return i;
		}

		i++;
		l = l->next;
	}

	return -1;
}


void CPieMenuCtrl::ResetPieMenu()
{
//	UpdateProps();
	CreateLevels();
	level = rootLevel;
}


void CPieMenuCtrl::PropogateNeedsLayout()
{
	if (pieNeedsLayout) {
		if (rootLevel != NULL) {
			pieNeedsLayout = 0;
			rootLevel->SetNeedsLayout();
		}
	}
}


void CPieMenuCtrl::CancelPopupTimer()
{
	if (popupTimer != 0) {
		KillTimer(popupTimer);
		popupTimer = 0;
	}
}


void CPieMenuCtrl::StartPopupTimer()
{
	CancelPopupTimer();
	if (!poppedUp) {
		popupTimer = SetTimer(1, popupDelay, NULL);
	}
}


void CPieMenuCtrl::PopUpNow()
{
	CancelPopupTimer();

	if (!poppedUp) {
		poppedUp = 1;

		CPieMenuLevel *lev = rootLevel;

		while (lev) {
			lev->Show();
			lev = lev->child;
		}
	}
}


long CPieMenuCtrl::CalcPieMenuItem(long x, long y)
{
	// Translate x and y from root window coordinates so they are 
	// relative to the menu center, in right side up coordinates.

	dx = x;
	dy = y;

	distance = (long)(sqrt((float)(dx * dx) + (dy * dy)));
	if (distance != 0) {
		direction = (long)RAD_TO_DEG(atan2((float)dy, (float)dx));
		if (direction < 0) {
			direction += 360;
		}
	} else {
		direction = 0;
	}

	if (level == NULL) {
		return (-1);
	}

	return level->CalcPieMenuItem(x, y);
} // CalcPieMenuItem


void CPieMenuCtrl::CleanItems()
{
	if (!itemsClean) {
		int i, j;
		char *itemsString = (char *)LPCTSTR(items);
		int len = strlen(itemsString);
		int ch = '\r';
		int chLast = 0;
		int newLine = 1;
		int indent = 0;
		CString out;
		int lines = 0;

		DestroyLevels();

		// Canonicalize the string and
		// count the number of items.
		for (i = 0; i < len; i++) {
			ch = itemsString[i];
			switch (ch) {
			case ' ':
				if (newLine) {
					indent++;
				}
				out += ch;
				break;
			case '\t':
				out += "    ";
			case '\r':
				out += "\r\n";
				lines++;
				newLine = 1;
				indent = 0;
				break;
			case '\n':
				if (chLast != '\r') {
					out += "\r\n";
					lines++;
				}
				newLine = 1;
				indent = 0;
				break;
			case ';':
				newLine = 1;
				out += "\r\n";
				lines++;
				for (j = 0; j < indent; j++) {
					out += ' ';
				}
				break;
			default:
				newLine = 0;
				out += ch;
				break;
			} // switch (ch)
			chLast = ch;
		} // for i

		if (!newLine) {
			out += "\r\n";
			lines++;
		} // if

		items = out;
		itemsClean = 1;
	} // if
}


void CPieMenuCtrl::CreateLevels()
{
	if (rootLevel == NULL) {
		int i;
		int ch = 0;
		int chLast = 0;
		int newLine = 1;
		int indent = 0;

		revision++;
		numLevels = 0;
		CleanItems();

		char *itemsString = (char *)LPCTSTR(items);
		int len = strlen(itemsString);

		numEntriesTree = 0;
		for (i = 0; i < len; i++) {
			if (itemsString[i] == '\r') {
				numEntriesTree++;
			} // if
		} // for

		// Parse out the entries from the menu description string,
		// into a flat array of entries.

		entriesTree = new CPieMenuEntry*[numEntriesTree];
		memset(entriesTree, 0, numEntriesTree * sizeof(CPieMenuEntry *));

		char *cp = itemsString, cha;
		char *limit = cp + len;
		char *start;

		indent = 0;
		chLast = 0;
		for (i = 0; i < numEntriesTree; i++) {
			CPieMenuEntry *ent = new CPieMenuEntry();
			entriesTree[i] = ent;

			indent = 0;
			start = cp;
			for (len = 0;
				 (cp != limit) && ((cha = *cp) != '\r');
				 len++, cp++) {
				if ((indent == len) &&
					(cha == ' ')) {
					indent++;
				} // if
			} // for len,cp

			start += indent;
			len -= indent;

			char *at = NULL;
			char *action = NULL;
			long actionLength = 0;
			long j;

			for (j = 0; j < len; j++) {
				if (start[j] == '=') {
					action = &start[j + 1];
					actionLength = len - j - 1;
					len -= actionLength + 1;
					break;
				} // if
			} // for

			if (action == NULL) {
				action = start;
				actionLength = len;
			} else {
				ent->flags |= kEntryAction;
			} // if

			for (j = 0; j < len; j++) {
				if (start[j] == '@') {
					at = &start[j];
					break;
				} // if
			} // for

			if (at != NULL) {
				long len1 = at - start;
				long len2 = len - len1;
				len = len1;

				if (action == start) {
					actionLength = len;
				} // if

				while ((len2 > 1) && 
					   (at[0] == '@')) {
					len2--;
					at++;
					if (isdigit(at[0])) {
						long deg = atoi(&at[0]);
						ent->layoutInitialAngle = deg;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "nw", 2) == 0) {
						ent->layoutInitialAngle = 90 + 45;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "ne", 2) == 0) {
						ent->layoutInitialAngle = 45;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "sw", 2) == 0) {
						ent->layoutInitialAngle = 180 + 45;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "se", 2) == 0) {
						ent->layoutInitialAngle = 180 + 90 + 45;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "n", 1) == 0) {
						ent->layoutInitialAngle = 90;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "s", 1) == 0) {
						ent->layoutInitialAngle = 180 + 90;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "w", 1) == 0) {
						ent->layoutInitialAngle = 180;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "e", 1) == 0) {
						ent->layoutInitialAngle = 0;
						ent->flags |= kEntryLayoutInitialAngle;
					} else if (strnicmp(at, "cw", 2) == 0) {
						ent->layoutClockwise = 1;
						ent->flags |= kEntryLayoutClockwise;
					} else if (strnicmp(at, "ccw", 3) == 0) {
						ent->layoutClockwise = 0;
						ent->flags |= kEntryLayoutClockwise;
					} else if (strnicmp(at, "r", 1) == 0) {
						ent->layoutFixedRadius = atoi(&at[1]);
						ent->flags |= kEntryLayoutFixedRadius;
					} // if
					while ((len2 > 1) &&
						   (at[0] != '@')) {
						len2--;
						at++;
					} // while
				} // if
			} // for

			ent->SetLabel(start, len);
			ent->SetAction(action, actionLength);
			ent->indent = indent;

			if ((cp != limit) && (cha == '\r')) {
				cp++;
				if ((cp != limit) && (*cp == '\n')) {
					cp++;
				} // if
			} // if
		} // for i < numEntriesTree

		// Now go over the flat array of menu entries, 
		// and shake it out into a tree of menu levels, 
		// according to the indentation.

		long curIndent = -1;

		level = NULL;
		firstLevel = NULL;
		rootLevel = NULL;

		for (i = 0; i < numEntriesTree; i++) {
			CPieMenuEntry *ent = entriesTree[i];

			ent->index = i;

			// If the indentation has changed, push or pop the menu stack
			// to the appropriate level.
			if (ent->indent > curIndent) { // push menu stack
				CPieMenuLevel *newLevel = new CPieMenuLevel(this);

				newLevel->next = rootLevel;
				newLevel->parentIndex = i - 1;
				newLevel->parent = level;

				// Indented out to the right, into a new level.

				if (level == NULL) {
					// New tree, so initialize first level.
					rootLevel = newLevel;
					newLevel->indent = ent->indent;
					// Initialize list of levels.
					firstLevel = newLevel;
					numLevels = 1;
				} else {
					// Hook this new level up to the previous level,
					// and "inherit" its properties. 
					level->entries[level->numEntries - 1]->subLevel = newLevel;
					newLevel->clockwise = level->clockwise;
					newLevel->initialAngle = level->initialAngle;
					newLevel->indent = ent->indent;
					// Link up list of levels.
					newLevel->next = firstLevel;
					firstLevel = newLevel;
					numLevels++;
				} // if

				// Now we're in the new level.
				level = newLevel;

			} else if (curIndent > ent->indent) { // pop menu stack

				// Indented in to the left, back to an old level.

				// Pop the menu stack until we're back to the appropriate
				// level of indentation.
				while ((level->parent != NULL) &&
					   (level->parent->indent >= ent->indent)) {
					// Shrink wrap entries array, now that we're done adding entries. 
					level->entries = (CPieMenuEntry **)realloc(level->entries,
															   level->numEntries * sizeof(CPieMenuEntry *));
					level->maxEntries = level->numEntries;

					// Pop the menu stack back one level.
					level = level->parent;
					curIndent = level->indent;
				} // while
			} // if

			// Add this entry to the current level. 
			level->AddEntry(ent);

			// Apply the entry's level properties to the level it ended up in. 
			if (ent->flags & kEntryLayoutClockwise) {
				level->clockwise = ent->layoutClockwise;
				level->flags |= kLevelLayoutClockwise;
			} // if

			if (ent->flags & kEntryLayoutInitialAngle) {
				level->initialAngle = ent->layoutInitialAngle;
				level->flags |= kLevelLayoutInitialAngle;
			} // if

			if (ent->flags & kEntryLayoutFixedRadius) {
				level->fixedRadius = ent->layoutFixedRadius;
				level->flags |= kLevelLayoutFixedRadius;
			} // if

			curIndent = ent->indent;
		} // for i
		
		// Clear menu stack by popping back to the top level.
		while (level != NULL) {
			level->Shrink();
			level = level->parent;
		} // if

		// Make a dummy level in case there were no entries.
		if (rootLevel == NULL) {
			rootLevel = new CPieMenuLevel(this);
			firstLevel = rootLevel;
			numLevels = 1;
		} // if

		// Reset the menu to the top.
		level = rootLevel;
	} // if rootLevel == NULL
} // CreateLevels


void CPieMenuCtrl::DestroyLevels()
{
	// Bump the revision so the property sheets can tell
	// that we've changed. 
	revision++;

	if (numEntriesTree != 0) {
		long i;

		for (i = 0; i < numEntriesTree; i++) {
			CPieMenuEntry *ent = entriesTree[i];

			if (ent->subLevel != NULL) {
				delete ent->subLevel;
			} // if

			delete ent;
		} // for

		if (rootLevel != NULL) {
			delete rootLevel;
		} // if

		delete [] entriesTree;
		entriesTree = NULL;
		numEntriesTree = 0;
		rootLevel = NULL;
		firstLevel = NULL;
		level = NULL;
		numLevels = 0;
		pieNeedsLayout = 1;
	} // if
}


/////////////////////////////////////////////////////////////////////////////
// Tracking


void CPieMenuCtrl::TrackDown(int x, int y) 
{
	ResetPieMenu();

	if (level) {
//		::SetCapture(captureWindow);
		::SetCapture(m_hWnd);

		tracking = 1;

		level->PopUp(x, y);
	} // if

	TrackMove(x, y);
}


void CPieMenuCtrl::TrackMove(int x, int y) 
{
	if (level && tracking) {
		long deltax = x - level->popupDownX;
		long deltay = -(y - level->popupDownY);
		long numEntries = level->numEntries;
		long activeItemLast = level->activeItem;
		long activeGroupItemLast = level->activeGroupItem;
		long activeItem = CalcPieMenuItem(deltax, deltay);
		long activeGroupItem = level->activeGroupItem;

		// Has the selection changed?
		if ((activeItem != activeItemLast) ||
			(activeGroupItem != activeGroupItemLast)) {
			CPieMenuEntry *ent = NULL;
			CPieMenuLevel *subLevel = NULL;

			if (activeItem != -1) {
				ent = level->entries[activeItem];
				subLevel = ent->subLevel;
			} // if

			level->UpdateCursor();

			// Should we dynamically reshape the window?
			// The dynamicShaping flag must be set, the button
			// must be down, and the shape must not be
			// rectangular or punched. 
			if ((dynamicShaping != 0) &&
				(buttonsDown != 0) &&
				(shapeWindow != kShapeRectangular) &&
				(shapeWindow != kShapePunched)) {

				// Reshape the window dynamically. 
				level->ShapeWindow();
			
			} else {

				// Update the highlighting of the selected slice. 
				HDC dc = ::GetDC(level->popupWindow);
				GState g(this);

				// Un-highlight the last active item.
				if (level->activeItem != -1) {
					ent = level->entries[level->activeItem];
					ent->Paint(dc, &g, 1);
				} // if
				
				// Highlight the active item.
				if (activeItemLast != -1) {
					ent = level->entries[activeItemLast];
					ent->Paint(dc, &g, 0);
				} // if

				::ReleaseDC(level->popupWindow, dc);

			} // if
		} // if

		CPieMenuEntry *it = CurrentEntry();

		if (it != NULL) {
			CString item(it->label, it->labelLength);
			CString action(it->action, it->actionLength);

			if (level->activeItem != activeItemLast) {
				FireChange(item, action, direction, distance);
			}

			FirePreview(item, action, direction, distance);
		} else {
			if (level->activeItem != activeItemLast) {
				FireChange("", "", 0, 0);
			} // if

			FirePreview("", "", 0, 0);
		} // if
	} // if
}


void CPieMenuCtrl::TrackUp(int x, int y) 
{
	TrackMove(x, y);

	if (level == NULL) return;

	if (level->activeItem == -1) {
		if (level->TryScroll(x, y)) {
			pinnedUp = 1;
			PopUpNow();
		} else {
			if (!pinnedUp) {
				pinnedUp = 1;
				PopUpNow();
			} else {
				TrackCancel();
				FireCancel();
			} // if
		}
	} else {
		CPieMenuEntry *it = level->entries[level->activeItem];

		if (it->subLevel != NULL) {
			level->child = it->subLevel;
			level = it->subLevel;

			pinnedUp = 1;
			level->PopUp(x, y);
		} else {
			CString item(it->label, it->labelLength);
			CString action(it->action, it->actionLength);

			TrackCancel();

			FireAction(item, action, direction, distance);
			FireClick();
		} // if
	} // if
}


void CPieMenuCtrl::TrackBack()
{
	if (level == rootLevel) {
		TrackCancel();
		FireCancel();
	} else if (level != NULL) {
		level = level->Back();
		if (dynamicShaping &&
			(level != NULL)) {
			level->ShapeWindow();
		}
	} // if
}


void CPieMenuCtrl::TrackCancel()
{
	::ReleaseCapture();
//	::ShowWindow(captureWindow, 0);

	tracking = 0;
	pinnedUp = 0;
	poppedUp = 0;

	CancelPopupTimer();

	if (level != NULL) {
		level->Cancel();
//		level = NULL;
	} // if
}


void CPieMenuCtrl::OnAnyButtonDown(UINT nFlags, CPoint point, int button) 
{
	if (!tracking) {
		POINT pt;
		pt.x = point.x;
		pt.y = point.y;
		::ClientToScreen(m_hWnd, &pt);

		buttonsDown = 1;
		trackingButton = button;

		TrackDown(pt.x, pt.y);
	} else {
		if (button == trackingButton) {
			buttonsDown = 1;

			if (dynamicShaping &&
				(level != NULL)) {
				level->ShapeWindow();
			}
		} else {
			// Move cursor to middle of current menu.
			if (level != NULL) {
				int curx = level->popupX + level->popupCenterX;
				int cury = level->popupY + level->popupCenterY;
				::SetCursorPos(curx, cury);
				TrackMove(curx, cury);
			} // if
		} // if
	} // if
}


void CPieMenuCtrl::OnAnyButtonUp(UINT nFlags, CPoint point, int button) 
{
	if (tracking) {
		POINT pt;
		pt.x = point.x;
		pt.y = point.y;
		::ClientToScreen(m_hWnd, &pt);

		if (button != trackingButton) {
			if ((level != NULL) &&
				(level->activeItem == -1)) {
				TrackBack();
				if (level) {
					TrackMove(pt.x, pt.y);
				} // if
			} // if
		} else {
			TrackUp(pt.x, pt.y);
			buttonsDown = 0;
		} // if
	} // if
}


void CPieMenuCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{

	if (level && tracking) {
		POINT pt;

		pt.x = point.x;
		pt.y = point.y;
		::ClientToScreen(m_hWnd, &pt);

		StartPopupTimer();

		TrackMove(pt.x, pt.y);
	} // if
}


void CPieMenuCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	OnAnyButtonDown(nFlags, point, 1);
}


void CPieMenuCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	OnAnyButtonUp(nFlags, point, 1);
}


void CPieMenuCtrl::OnMButtonDown(UINT nFlags, CPoint point) 
{
	OnAnyButtonDown(nFlags, point, 2);
}


void CPieMenuCtrl::OnMButtonUp(UINT nFlags, CPoint point) 
{
	OnAnyButtonUp(nFlags, point, 2);
}


void CPieMenuCtrl::OnRButtonDown(UINT nFlags, CPoint point) 
{
	OnAnyButtonDown(nFlags, point, 3);
}


void CPieMenuCtrl::OnRButtonUp(UINT nFlags, CPoint point) 
{
	OnAnyButtonUp(nFlags, point, 3);
}


BOOL CPieMenuCtrl::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	if (level != NULL) {
		if (zDelta < 0) {
			level->NextItem(1);
		} else {
			level->NextItem(-1);
		}
	}

	return true;
}


/////////////////////////////////////////////////////////////////////////////
// CPieMenuCtrl message handlers

BSTR CPieMenuCtrl::GetItems() 
{
	CString strResult;

	CleanItems();
	strResult = items;

	return strResult.AllocSysString();
}


void CPieMenuCtrl::SetItems(LPCTSTR lpszNewValue) 
{
	items = lpszNewValue;
	itemsClean = 0;
	CleanItems();
	UpdateProps();
}


long CPieMenuCtrl::GetDirection() 
{
	return direction;
}


void CPieMenuCtrl::SetDirection(long nNewValue) 
{
	direction = nNewValue;
}


long CPieMenuCtrl::GetDistance() 
{
	return distance;
}


void CPieMenuCtrl::SetDistance(long nNewValue) 
{
	distance = nNewValue;
}


long CPieMenuCtrl::GetIndex() 
{
	if ((level == NULL) ||
		(level->activeItem == -1) ||
		(level->activeItem >= level->numEntries)) {
		return -1;
	} else {
		CPieMenuEntry *it = level->entries[level->activeItem];
		return it->index;
	}
}


void CPieMenuCtrl::SetIndex(long nNewValue) 
{
}


BSTR CPieMenuCtrl::GetAction() 
{
	if ((level == NULL) ||
		(level->activeItem == -1) ||
		(level->activeItem >= level->numEntries)) {
		CString strResult = "";
		return strResult.AllocSysString();
	} else {
		CPieMenuEntry *it = level->entries[level->activeItem];
		CString strResult(it->action, it->actionLength);
		return strResult.AllocSysString();
	}
}


void CPieMenuCtrl::SetAction(LPCTSTR lpszNewValue) 
{
}


LPPICTUREDISP CPieMenuCtrl::GetBackgroundPicture() 
{
	return backgroundPicture.GetPictureDispatch();
}


void CPieMenuCtrl::SetBackgroundPicture(LPPICTUREDISP newValue) 
{
	backgroundPicture.SetPictureDispatch(newValue);
	UpdateProps();
}


LPPICTUREDISP CPieMenuCtrl::GetTargetPicture() 
{
	return targetPicture.GetPictureDispatch();
}


void CPieMenuCtrl::SetTargetPicture(LPPICTUREDISP newValue) 
{
	targetPicture.SetPictureDispatch(newValue);
	UpdateProps();
}


long CPieMenuCtrl::GetItemCount() 
{
	CreateLevels();
	return numEntriesTree;
}


void CPieMenuCtrl::SetItemCount(long nNewValue)
{
}


long CPieMenuCtrl::GetInactiveRadius() 
{
	return inactiveRadius;
}


void CPieMenuCtrl::SetInactiveRadius(long nNewValue) 
{
	inactiveRadius = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetMinRadius() 
{
	return minRadius;
}


void CPieMenuCtrl::SetMinRadius(long nNewValue) 
{
	minRadius = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetClockwise() 
{
	return clockwise ? TRUE : FALSE;
}


void CPieMenuCtrl::SetClockwise(long nNewValue) 
{
	clockwise = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetInitialAngle() 
{
	return initialAngle;
}


void CPieMenuCtrl::SetInitialAngle(long nNewValue) 
{
	initialAngle = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetBorderWidth() 
{
	return borderWidth;
}


void CPieMenuCtrl::SetBorderWidth(long nNewValue) 
{
	borderWidth = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetItemBorderWidth() 
{
	return itemBorderWidth;
}


void CPieMenuCtrl::SetItemBorderWidth(long nNewValue) 
{
	itemBorderWidth = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetExtraRadius() 
{
	return extraRadius;
}


void CPieMenuCtrl::SetExtraRadius(long nNewValue) 
{
	extraRadius = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetSliceInset() 
{
	return sliceInset;
}


void CPieMenuCtrl::SetSliceInset(long nNewValue) 
{
	sliceInset = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetFixedRadius() 
{
	return fixedRadius;
}


void CPieMenuCtrl::SetFixedRadius(long nNewValue) 
{
	fixedRadius = nNewValue;
	UpdateProps();
}


void CPieMenuCtrl::PopUp(long xx, long yy)
{
	CPoint pt;

	pt.x = xx;
	pt.y = yy;

	if (tracking) {
		TrackCancel();
		FireCancel();
	} // if

	// Oh hell, ignore what they passed in, and pop it up under the cursor!

	::GetCursorPos(&pt);
	::ScreenToClient(m_hWnd, &pt);

	if (IsLButtonDown()) {
		OnLButtonDown(0, pt);
	} else if (IsRButtonDown()) {
		OnRButtonDown(0, pt);
	} else if (IsMButtonDown()) {
		OnMButtonDown(0, pt);
	} else {
		OnRButtonDown(0, pt);
	} // if
}


void CPieMenuCtrl::Clear() 
{
	SetItems("");
}


BSTR CPieMenuCtrl::GetCurrentItem() 
{
	if ((level == NULL) ||
		(level->activeItem == -1) ||
		(level->activeItem >= level->numEntries)) {
		CString strResult = "";
		return strResult.AllocSysString();
	} else {
		CPieMenuEntry *it = level->entries[level->activeItem];
		CString strResult(it->label, it->labelLength);
		return strResult.AllocSysString();
	} // if
}


void CPieMenuCtrl::SetCurrentItem(LPCTSTR lpszNewValue) 
{
}


BSTR CPieMenuCtrl::GetItem(long index) 
{
	CString strResult;
	int line;
	int ch;

	CleanItems();

	char *str = (char *)LPCTSTR(items);

	for (line = 0; line < index; line++) {
		str = strchr(str, '\n') + 1;
	} // for

	while (((ch = *str++) != '\0') &&
		   (ch != '\r')) {
		strResult += ch;
	} // while

	return strResult.AllocSysString();
}


void CPieMenuCtrl::SetItem(long index, LPCTSTR newItem) 
{
	CString out;
	int line;
	int ch;
	int newItemLen = strlen(newItem);

	DestroyLevels();
	UpdateProps();

	char *str = (char *)LPCTSTR(items);

	for (line = 0; line < index; line++) {
		while (((ch = *str) != '\0') &&
			   (ch != '\n')) {
			out += ch;
			str++;
		} // while
		if (ch != '\0') str++;
		out += '\n';
	} // for

	out += newItem;

	if ((newItemLen == 0) ||
		((newItem[newItemLen - 1] != '\r') &&
		 (newItem[newItemLen - 1] != '\n'))) {
		out += "\r\n";
	} // if

	while (((ch = *str) != '\0') &&
		   (ch != '\n')) {
		str++;
	} // while

	if (ch != '\0') str++;

	while ((ch = *str) != '\0') {
		out += ch;
		str++;
	} // while

	items = out;

	CleanItems();

	UpdateProps();
}


long CPieMenuCtrl::GetShrinkWrap() 
{
	return shrinkWrap;
}


void CPieMenuCtrl::SetShrinkWrap(long nNewValue) 
{
	shrinkWrap = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetShapeWindow() 
{
	return shapeWindow;
}


void CPieMenuCtrl::SetShapeWindow(long nNewValue) 
{
	if (nNewValue < 0) {
		nNewValue = 0;
	} else if (nNewValue >= kNumShapes) {
		nNewValue = kNumShapes - 1;
	} // if
	shapeWindow = nNewValue;

	if (shapeWindow == kShapeAsshole) {
		InvalidateShapeRegion();
		backgroundPicture.CreateFromBitmap(IDB_ASSHOLE);
		shapePicture.CreateFromBitmap(IDB_ASSHOLE);
		shapeCenterX = 18;
		shapeCenterY = 18;
		shapeTransparentX = 0;
		shapeTransparentY = 0;
		maxSlices = 8;
		roundRectRadius = 0;
		bevel = 0;
		shrinkWrap = 1;
		dynamicShaping = 0;
		pieBackground = RGB(128, 128, 128);
		pieForeground = RGB(0, 0, 0);
		UpdateProps();
	}

	UpdateProps();
}


long CPieMenuCtrl::GetDynamicShaping() 
{
	return dynamicShaping;
}


void CPieMenuCtrl::SetDynamicShaping(long nNewValue) 
{
	dynamicShaping = nNewValue;
	UpdateProps();
}


void CPieMenuCtrl::OnTimer(UINT nIDEvent) 
{
	PopUpNow();

	COleControl::OnTimer(nIDEvent);
}


long CPieMenuCtrl::GetPopupDelay() 
{
	return popupDelay;
}


void CPieMenuCtrl::SetPopupDelay(long nNewValue) 
{
	popupDelay = nNewValue;
}


long CPieMenuCtrl::GetDoubleBuffer() 
{
	return doubleBuffer;
}


void CPieMenuCtrl::SetDoubleBuffer(long nNewValue) 
{
	doubleBuffer = nNewValue;
}


void CPieMenuCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	COleControl::OnSetFocus(pOldWnd);
	
	// TODO: Add your message handler code here
	
}


void CPieMenuCtrl::OnKillFocus(CWnd* pNewWnd) 
{
	COleControl::OnKillFocus(pNewWnd);
	
	// TODO: Add your message handler code here
	
}


void CPieMenuCtrl::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (ignoreNextChar) {
		ignoreNextChar = 0;
	} else {
		// Is there a menu up?
		if (level != NULL) {

			// There is a menu up. 
			if ((nChar > 0x20) &&
				(nChar < 0x7f)) {
				// Printing character, move to the next item beginning with it.
				level->NextItemKey(nChar);
				return;
			} // if
		} // if
	} // if

	COleControl::OnChar(nChar, nRepCnt, nFlags);
}


void CPieMenuCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	ignoreNextChar = 0;

	// Is there a menu up?
	if (level == NULL) {
		// No, pop it up in response to return.

		switch (nChar) {

		case VK_RETURN:
			// Pop it up.
			{
				POINT pt;
				::GetCursorPos(&pt);
				::ScreenToClient(m_hWnd, &pt);

				PopUp(pt.x, pt.y);
				PopUpNow();

				buttonsDown = 0;
				pinnedUp = 1;

				COleControl::OnKeyDown(nChar, nRepCnt, nFlags);

				return;
			} // scope

		default:
			// Unknown, just ignore it.
			COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
			return;

		} // switch

	} // if

	// There is a menu up. 
	switch (nChar) {

	case VK_CANCEL:
	case VK_ESCAPE:
	case VK_DELETE:
		// Cancel
		TrackCancel();
		return;

	case VK_BACK:
		// Back
		TrackBack();
		return;

	case VK_RETURN:
		// Select
		{
			POINT pt;
			::GetCursorPos(&pt);
			buttonsDown = 0;
			pinnedUp = 1;
			TrackUp(pt.x, pt.y);
			return;
		}

	case VK_NUMPAD5:
		ignoreNextChar = 1;
	case ' ':
	case VK_HOME:
		level->Home(0, 0);
		break;

	case VK_END:
		break;

	case VK_NUMPAD7:
		ignoreNextChar = 1;
nw:
		// NW
		level->Home(-2 * inactiveRadius,
					-2 * inactiveRadius);
		break;

	case VK_UP:
		if (GetKeyState(VK_RIGHT) < 0) goto ne;
		if (GetKeyState(VK_LEFT) < 0) goto nw;
		goto n;

	case VK_NUMPAD8:
		ignoreNextChar = 1;
n:
		// North
		level->Home(0,
					-2 * inactiveRadius);
		break;

	case VK_NUMPAD9:
		ignoreNextChar = 1;
ne:
		// NE
		level->Home(2 * inactiveRadius,
					-2 * inactiveRadius);
		break;

	case VK_LEFT:
		if (GetKeyState(VK_UP) < 0) goto nw;
		if (GetKeyState(VK_DOWN) < 0) goto sw;
		goto w;

	case VK_NUMPAD4:
		ignoreNextChar = 1;
w:
		// West
		level->Home(-2 * inactiveRadius,
					0);
		break;

	case VK_RIGHT:
		if (GetKeyState(VK_UP) < 0) goto ne;
		if (GetKeyState(VK_DOWN) < 0) goto se;
		goto e;

	case VK_NUMPAD6:
		ignoreNextChar = 1;
e:
		// East
		level->Home(2 * inactiveRadius,
					0);
		break;

	case VK_NUMPAD1:
		ignoreNextChar = 1;
sw:
		// SW
		level->Home(-2 * inactiveRadius,
					2 * inactiveRadius);
		break;

	case VK_DOWN:
		if (GetKeyState(VK_RIGHT) < 0) goto se;
		if (GetKeyState(VK_LEFT) < 0) goto sw;
		goto s;

	case VK_NUMPAD2:
		ignoreNextChar = 1;
s:
		// South
		level->Home(0,
					2 * inactiveRadius);
		break;

	case VK_NUMPAD3:
		ignoreNextChar = 1;
se:
		// SE
		level->Home(2 * inactiveRadius,
					2 * inactiveRadius);
		break;

	case VK_PRIOR:
		// page up
		level->ScrollItems(-1);
		break;

	case VK_NEXT:
		// page down
		level->ScrollItems(1);
		break;

	case VK_TAB:
		// page down
		if (GetKeyState(VK_SHIFT) < 0) {
			level->NextItem(-1);
		} else {
			level->NextItem(1);
		}
		break;

	default:
		// Unknown, just ignore it.
		break;

	} // switch

	COleControl::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CPieMenuCtrl::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
}


void CPieMenuCtrl::OnFontChanged() 
{
	COleControl::OnFontChanged();
	UpdateProps();
}


long CPieMenuCtrl::GetCPieMenuCtrl() 
{
	return (long)(CPieMenuCtrl *)this;
}


void CPieMenuCtrl::SetCPieMenuCtrl(long nNewValue) 
{
}


long CPieMenuCtrl::GetItemGap() 
{
	return itemGap;
}


void CPieMenuCtrl::SetItemGap(long nNewValue) 
{
	itemGap = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetRevision() 
{
	return revision;
}


void CPieMenuCtrl::SetRevision(long nNewValue) 
{
	revision = nNewValue;
}


OLE_COLOR CPieMenuCtrl::GetPieForegroundColor() 
{
	return pieForeground;
}


void CPieMenuCtrl::SetPieForegroundColor(OLE_COLOR nNewValue) 
{
	if (FAILED(::OleTranslateColor(nNewValue, NULL, &pieForeground))) {
		ThrowError(CTL_E_INVALIDPROPERTYVALUE, AFX_IDP_E_INVALIDPROPERTYVALUE);
	} // if

	UpdateProps();
}


OLE_COLOR CPieMenuCtrl::GetPieBackgroundColor() 
{
	return pieBackground;
}


void CPieMenuCtrl::SetPieBackgroundColor(OLE_COLOR nNewValue) 
{
	if (FAILED(::OleTranslateColor(nNewValue, NULL, &pieBackground))) {
		ThrowError(CTL_E_INVALIDPROPERTYVALUE, AFX_IDP_E_INVALIDPROPERTYVALUE);
	} // if

	UpdateProps();
}


OLE_COLOR CPieMenuCtrl::GetLightColor() 
{
	return light;
}


void CPieMenuCtrl::SetLightColor(OLE_COLOR nNewValue) 
{
	if (FAILED(::OleTranslateColor(nNewValue, NULL, &light))) {
		ThrowError(CTL_E_INVALIDPROPERTYVALUE, AFX_IDP_E_INVALIDPROPERTYVALUE);
	} // if

	UpdateProps();
}


OLE_COLOR CPieMenuCtrl::GetDarkColor() 
{
	return dark;
}


void CPieMenuCtrl::SetDarkColor(OLE_COLOR nNewValue) 
{
	if (FAILED(::OleTranslateColor(nNewValue, NULL, &dark))) {
		ThrowError(CTL_E_INVALIDPROPERTYVALUE, AFX_IDP_E_INVALIDPROPERTYVALUE);
	} // if

	UpdateProps();
}


long CPieMenuCtrl::GetBevel() 
{
	return bevel;
}


void CPieMenuCtrl::SetBevel(long nNewValue) 
{
	bevel = nNewValue;
}


void CPieMenuCtrl::DecompileItems()
{
	CString str;

	CreateLevels();
	rootLevel->Decompile(str, 0);
	DestroyLevels();

	items = str;
}


int CPieMenuCtrl::GetShapeRegionSize(long *widthp,
									 long *heightp)
{
	int result;
	HDC dc = ::GetDC(m_hWnd);

	result = GetPictureSize(dc,
						    &shapePicture,
							widthp,
							heightp);

	::ReleaseDC(m_hWnd, dc);

	return result;
}


HRGN CPieMenuCtrl::GetShapeRegion()
{
	if (!shapeRegionValid) {
		HDC dc = ::GetDC(m_hWnd);

		shapeRegion = 
			MakePictureRegion(dc,
							  &shapePicture,
							  shapeTransparentX,
							  shapeTransparentY);

		::ReleaseDC(m_hWnd, dc);

		shapeRegionValid = 1;
	} // if

	if (shapeRegion == NULL) {
		return NULL;
	} // if

	HRGN reg = ::CreateRectRgn(0, 0, 1, 1);

	::CombineRgn(reg, 
				 shapeRegion, 
				 NULL, 
				 RGN_COPY);

	return reg;
}


void CPieMenuCtrl::InvalidateShapeRegion()
{
	if (shapeRegionValid) {
		shapeRegionValid = 0;
		if (shapeRegion != NULL) {
			::DeleteObject(shapeRegion);
			shapeRegion = NULL;
		} // if
	} // if
}


int CPieMenuCtrl::GetPictureSize(HDC dc,
								 CPictureHolder *pictHolder,
								 long *widthp,
								 long *heightp)
{
	short picType = pictHolder->GetType();
	if ((picType == PICTYPE_NONE) ||
		(picType == PICTYPE_UNINITIALIZED)) {
		return 0;
	} // if

	LPPICTUREDISP pictDisp = 
		pictHolder->GetPictureDispatch();
	if (pictDisp == NULL) {
		return 0;
	} // if

	LPPICTURE pict = NULL;
	pictDisp->QueryInterface(IID_IPicture,
							 (LPVOID *)&pict);
	pictDisp->Release();
	if (pict == NULL) {
		return 0;
	} // if

	SIZE sizeHIMETRIC;
	SIZE size;

	pict->get_Width(&sizeHIMETRIC.cx);
	pict->get_Height(&sizeHIMETRIC.cy);

	{
		CDC *cdc = CDC::FromHandle(dc);

		size = sizeHIMETRIC;
		cdc->HIMETRICtoDP(&size);
	}

	*widthp = size.cx + 1;
	*heightp = size.cy + 1;

	pict->Release();

	return 1;
}


// Convert a picture to a region.
// Takes a dc to use, an OLE CPictureHolder to use as a shape,
// and the x and y position of a pixel whose color is transparent. 
// Returns a region if it's successful, or NULL otherwise.
// By Don Hopkins.
HRGN CPieMenuCtrl::MakePictureRegion(HDC dc,
									 CPictureHolder *pictHolder,
									 int transparentX,
									 int transparentY)
{
	HRGN result = NULL;
	long width = 0;
	int height = 0;
	LPPICTURE pict = NULL;
	HDC dibdc = NULL;
	HBITMAP dib = NULL;
	unsigned char *mem = NULL;
	int rowBytes = 0;
	int transparentPixel = 0;

	// Try to get the IPicture interface.
	{ // scope
		short picType = pictHolder->GetType();
		if ((picType == PICTYPE_NONE) ||
			(picType == PICTYPE_UNINITIALIZED)) {
			goto bail;
		} // if

		LPPICTUREDISP pictDisp = 
			pictHolder->GetPictureDispatch();
		if (pictDisp == NULL) {
			goto bail;
		} // if

		pictDisp->QueryInterface(IID_IPicture,
								 (LPVOID *)&pict);
		pictDisp->Release();
		if (pict == NULL) {
			goto bail;
		} // if
	} // scope

	// Get the picture size.
	{ // scope
		CDC *cdc = CDC::FromHandle(dc);
		SIZE size;

		pict->get_Width(&size.cx);
		pict->get_Height(&size.cy);

		cdc->HIMETRICtoDP(&size);

		width = size.cx;
		height = size.cy;
	} // scope

	// Make an offscreen bitmap and draw the picture in it.
	{ // scope
		char info[sizeof(BITMAPINFO) + sizeof(RGBQUAD)*(256-1)];
		BITMAPINFO &bmi = *((BITMAPINFO*)info);
		BITMAPINFOHEADER &bmih = bmi.bmiHeader;

		if ((transparentX < 0) ||
			(transparentX >= width) ||
			(transparentY < 0) ||
			(transparentY >= height)) {
			goto bail;
		} // if

		bmih.biSize = sizeof(bmih);
		bmih.biWidth = width;
		bmih.biHeight = -height; // top down!
		bmih.biPlanes = 1;
		bmih.biBitCount = 8;
		bmih.biCompression = BI_RGB;
		bmih.biSizeImage = 0;
		bmih.biXPelsPerMeter = 0;
		bmih.biYPelsPerMeter = 0;
		bmih.biClrUsed = 256;
		bmih.biClrImportant = 256;

		int i;
		LPPALETTEENTRY pal = (LPPALETTEENTRY)&bmi.bmiColors[0];

		for (i = 0; i < 256; i++) {
			pal[i].peRed = pal[i].peGreen = pal[i].peBlue = i;
			pal[i].peFlags = 0;
		} // for

		dibdc = ::CreateCompatibleDC(dc);
		dib = ::CreateDIBSection(dibdc,
								 (BITMAPINFO*)&bmih, 
								 DIB_RGB_COLORS, 
								 (void **)&mem, 
								 NULL, 
								 0);

		if ((mem == NULL) ||
			(dib == NULL)) {
			goto bail;
		} // if

		::SelectObject(dibdc, dib);

		// Clear the background.
		rowBytes = (bmih.biWidth + 3) & ~3;
		memset(mem, 1, rowBytes * height);

		// Draw the picture in the bitmap.
		CDC *cdc = CDC::FromHandle(dibdc);
		RECT rect;
		rect.left = 0;
		rect.top = 0;
		rect.right = width;
		rect.bottom = height;

		pictHolder->Render(cdc,
						   rect,
						   rect);

		::GdiFlush();

		// Fetch the transparent pixel.
		transparentPixel = 
			mem[(transparentY * rowBytes) +
				transparentX];
	} // scope

	{ // scope
		int i;
		int xx, yy;
		int curRect = -1;
		int rectAbove = -1;
		int rectCount = 0;
		int rectBufSize = 256;
		RECT *rects = new RECT[rectBufSize];
		RECT *r = NULL;

		for (yy = 0; yy < height; yy++) {
			int isInside = 0;
			int wasInside = 0;
		
			for (xx = 0; xx < width; xx++) {
				int pixel = mem[xx];
				isInside = (pixel != transparentPixel);
			
				if (wasInside) {
					if (! isInside) {
						r->right = xx;
				
						if ((rectAbove != -1) &&
							(rects[rectAbove].right == xx)) {
							// merge with rect above
							rects[rectAbove].bottom = r->bottom;
							rectCount--;
						} // if
						
						wasInside = 0;
						curRect = -1;
						rectAbove = -1;
					} // if (! isInside)
				} else { // if (wasInside)
					if (isInside) {
						wasInside = 1;
						
						curRect = rectCount++;

						if (rectCount > rectBufSize) {
							RECT *newRects;
							
							rectBufSize += 256;
							newRects = new RECT[rectBufSize];
							
							memcpy((char *)newRects,
								   (char *)rects,
								   curRect * sizeof(RECT));
							
							delete [] rects;
							rects = newRects;
						} // if (rectCount > rectBufSize)

						r = &rects[curRect];
						r->left = xx;
						r->top = yy;
						r->right = xx + 1;
						r->bottom = yy + 1;
						
						rectAbove = -1;

						for (i = 0; i < curRect; i++) {
							RECT *ra = &rects[i];
							if ((ra->left == xx) &&
								(ra->bottom == yy)) {
								rectAbove = i;
								break;
							} // if
						} // for i
					} // if (isInside)
				} // if (wasInside)
			} // for xx

			if (curRect != -1) {
				r->right = xx;

				if ((rectAbove != -1) &&
					(rects[rectAbove].right == xx)) {
					// merge with rect above
					rects[rectAbove].bottom = r->bottom;
					rectCount--;
				} // if
			} // if (curRect != -1)

			curRect = -1;
			rectAbove = -1;
			mem += rowBytes;

		} // for yy

		int headerSize = sizeof(RGNDATAHEADER);
		int rectSize = (sizeof(RECT) * rectCount);
		int dataSize = headerSize + rectSize;
		char *data = 
			new char[dataSize];
		RGNDATA *rd = 
			(RGNDATA *)data;
		RECT *regionRects = 
			(RECT *)(data + headerSize);

		rd->rdh.dwSize = headerSize;
		rd->rdh.iType = RDH_RECTANGLES;
		rd->rdh.nCount = rectCount;
		rd->rdh.nRgnSize = rectSize;
		rd->rdh.rcBound.left = 0;
		rd->rdh.rcBound.top = 0;
		rd->rdh.rcBound.right = width;
		rd->rdh.rcBound.bottom = height;

		for (i = 0; i < rectCount; i++) {
			regionRects[i].left = rects[i].left + 1;
			regionRects[i].top = rects[i].top + 1;
			regionRects[i].right = rects[i].right + 1;
			regionRects[i].bottom = rects[i].bottom + 1;
		} // for

		delete [] rects;

		result = ::ExtCreateRegion(NULL,
								   dataSize,
								   rd);

		delete [] data;
	} // scope

bail:

	if (dibdc != NULL) {
		::DeleteDC(dibdc);
	} // if

	if (dib != NULL) {
		::DeleteObject(dib);
	} // if

	if (pict != NULL) {
		pict->Release();
	} // if

	return result;
}


long CPieMenuCtrl::GetShapeCenterX() 
{
	return shapeCenterX;
}


void CPieMenuCtrl::SetShapeCenterX(long cx) 
{
	shapeCenterX = cx;
	UpdateProps();
}


long CPieMenuCtrl::GetShapeCenterY() 
{
	return shapeCenterY;
}


void CPieMenuCtrl::SetShapeCenterY(long cy) 
{
	shapeCenterY = cy;
	UpdateProps();
}


LPPICTUREDISP CPieMenuCtrl::GetShapePicture() 
{
	return shapePicture.GetPictureDispatch();
}


void CPieMenuCtrl::SetShapePicture(LPPICTUREDISP newValue) 
{
	shapePicture.SetPictureDispatch(newValue);
	InvalidateShapeRegion();
	UpdateProps();
}


long CPieMenuCtrl::GetShapeTransparentX() 
{
	return shapeTransparentX;
}


void CPieMenuCtrl::SetShapeTransparentX(long nNewValue) 
{
	if (shapeTransparentX != nNewValue) {
		InvalidateShapeRegion();
		shapeTransparentX = nNewValue;
		UpdateProps();
	} // if
}


long CPieMenuCtrl::GetShapeTransparentY() 
{
	return shapeTransparentY;
}


void CPieMenuCtrl::SetShapeTransparentY(long nNewValue) 
{
	if (shapeTransparentY != nNewValue) {
		InvalidateShapeRegion();
		shapeTransparentY = nNewValue;
		UpdateProps();
	} // if
}


LPDISPATCH CPieMenuCtrl::GetUserData() 
{
	return userData;
}


void CPieMenuCtrl::SetUserData(LPDISPATCH newValue) 
{
	if (userData != NULL) {
		userData->Release();
	} // if

	userData = newValue;
	
	if (userData != NULL) {
		userData->AddRef();
	} // if
}


long CPieMenuCtrl::GetMaxSlices() 
{
	return maxSlices;
}


void CPieMenuCtrl::SetMaxSlices(long nNewValue) 
{
	switch (nNewValue) {
	case 0:
		nNewValue = 0;
		break;
	case 1:
	case 2:
		nNewValue = 2;
		break;
	case 3:
	case 4:
		nNewValue = 4;
		break;
	case 5:
	case 7:
	case 8:
		nNewValue = 8;
		break;
	default:
		nNewValue = 8;
		break;
	}

	if (nNewValue != maxSlices) {
		maxSlices = nNewValue;
		UpdateProps();
	}
}


long CPieMenuCtrl::GetScrollingMovesCursor() 
{
	return scrollingMovesCursor;
}

void CPieMenuCtrl::SetScrollingMovesCursor(long nNewValue) 
{
	scrollingMovesCursor = nNewValue;
}


long CPieMenuCtrl::GetLayerRadius() 
{
	return layerRadius;
}


void CPieMenuCtrl::SetLayerRadius(long nNewValue) 
{
	if (nNewValue < 1) {
		nNewValue = 1;
	} // if

	layerRadius = nNewValue;
}


long CPieMenuCtrl::GetShuffle() 
{
	return shuffle;
}


void CPieMenuCtrl::SetShuffle(long nNewValue) 
{
	shuffle = nNewValue;
	UpdateProps();
}


long CPieMenuCtrl::GetAutoScroll() 
{
	return autoScroll;
}


void CPieMenuCtrl::SetAutoScroll(long nNewValue) 
{
	autoScroll = nNewValue;
}



long CPieMenuCtrl::GetMaxSlicesIndex() 
{
	int i = 0;
	switch (maxSlices) {
	case 1:
		i = 1;
		break;
	case 2:
		i = 2;
		break;
	case 4:
		i = 3;
		break;
	case 8:
		i = 4;
		break;
	} // switch

	return i;
}


void CPieMenuCtrl::SetMaxSlicesIndex(long nNewValue) 
{
	int ms = 0;

	switch (nNewValue) {
	case 0:
		ms = 0;
		break;
	case 1:
		ms = 1;
		break;
	case 2:
		ms = 2;
		break;
	case 3:
		ms = 4;
		break;
	case 4:
		ms = 8;
		break;
	} // switch

	if (maxSlices != ms) {
		maxSlices = ms;
		UpdateProps();
	}
}


long CPieMenuCtrl::GetRoundRectRadius() 
{
	return roundRectRadius;
}


void CPieMenuCtrl::SetRoundRectRadius(long nNewValue) 
{
	roundRectRadius = nNewValue;
	UpdateProps();
}


BOOL CPieMenuCtrl::GetStack() 
{
	return stack;
}


void CPieMenuCtrl::SetStack(BOOL bNewValue) 
{
	stack = bNewValue;
	UpdateProps();
}


/////////////////////////////////////////////////////////////////////////////
