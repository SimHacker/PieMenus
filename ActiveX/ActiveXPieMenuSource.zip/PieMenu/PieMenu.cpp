/////////////////////////////////////////////////////////////////////////////
//
// PieMenu.cpp : Implementation of CPiemenuApp and DLL registration
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////


CPiemenuApp NEAR theApp;

const GUID CDECL BASED_CODE _tlid =
		{ 0x87351bc0, 0x983f, 0x11cf, { 0x9a, 0x4b, 0x54, 0xa4, 0xff, 0xc0, 0, 0 } };
const WORD _wVerMajor = 1;
const WORD _wVerMinor = 0;


////////////////////////////////////////////////////////////////////////////


extern LRESULT CALLBACK
EditPieMenuWindowProc(HWND hWnd, 
					  UINT message,
					  WPARAM wParam,
					  LPARAM lParam);


////////////////////////////////////////////////////////////////////////////
// CPiemenuApp::InitInstance - DLL initialization

BOOL CPiemenuApp::InitInstance()
{
	BOOL bInit = COleControlModule::InitInstance();

	if (bInit)
	{
		AfxEnableControlContainer(); // Enable OLE control container
	}

	RegisterClasses();

	return bInit;
}


////////////////////////////////////////////////////////////////////////////
// CPiemenuApp::ExitInstance - DLL termination

int CPiemenuApp::ExitInstance()
{
	UnregisterClasses();

	return COleControlModule::ExitInstance();
}


/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
	AFX_MANAGE_STATE(_afxModuleAddrThis);

	if (!AfxOleRegisterTypeLib(AfxGetInstanceHandle(), _tlid))
		return ResultFromScode(SELFREG_E_TYPELIB);

	if (!COleObjectFactoryEx::UpdateRegistryAll(TRUE))
		return ResultFromScode(SELFREG_E_CLASS);

	return NOERROR;
}


/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
	AFX_MANAGE_STATE(_afxModuleAddrThis);

	if (!AfxOleUnregisterTypeLib(_tlid))
		return ResultFromScode(SELFREG_E_TYPELIB);

	if (!COleObjectFactoryEx::UpdateRegistryAll(FALSE))
		return ResultFromScode(SELFREG_E_CLASS);

	return NOERROR;
}


/////////////////////////////////////////////////////////////////////////////


void CPiemenuApp::RegisterClasses()
{

    WNDCLASSEX wcex;
	HRESULT result;

	wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
    wcex.lpfnWndProc = EditPieMenuWindowProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = m_hInstance;
    wcex.hIcon = NULL;
    wcex.hCursor = ::LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName = NULL;
    wcex.lpszClassName = _T("EDITPIEMENUWINDOW");
	wcex.hIconSm = NULL;

	result = ::RegisterClassEx(&wcex);
}


/////////////////////////////////////////////////////////////////////////////


void CPiemenuApp::UnregisterClasses()
{
	::UnregisterClass("EDITPIEMENUWINDOW", m_hInstance);
}


/////////////////////////////////////////////////////////////////////////////
