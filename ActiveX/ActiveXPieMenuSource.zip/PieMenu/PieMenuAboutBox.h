/////////////////////////////////////////////////////////////////////////////
//
// PieMenuAboutBox.h : About Box
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CPieMenuAboutBox dialog

class CPieMenuAboutBox : public CDialog
{
// Construction
public:
	CPieMenuAboutBox(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPieMenuAboutBox)
	enum { IDD = IDD_ABOUTBOX_PIEMENU };
	CEdit	m_Info;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPieMenuAboutBox)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPieMenuAboutBox)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
