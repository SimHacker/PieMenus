/////////////////////////////////////////////////////////////////////////////
//
// GState.h : Graphics State
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


class CPieMenuCtrl;


/////////////////////////////////////////////////////////////////////////////
// Class GState


class GState {

private:

	CPieMenuCtrl *pie;
	HBRUSH oleForegroundBrush;
	HBRUSH oleBackgroundBrush;
	HBRUSH foregroundBrush;
	HBRUSH backgroundBrush;
	HBRUSH lightBrush;
	HBRUSH darkBrush;
	HPEN foregroundPen;
	HPEN foregroundFramePen;
	HPEN backgroundPen;
	HPEN lightPen;
	HPEN darkPen;
	HFONT font;

public:

	GState(CPieMenuCtrl *p) :
		pie(p),
		oleForegroundBrush(NULL),
		oleBackgroundBrush(NULL),
		foregroundBrush(NULL),
		backgroundBrush(NULL),
		lightBrush(NULL),
		darkBrush(NULL),
		foregroundPen(NULL),
		foregroundFramePen(NULL),
		backgroundPen(NULL),
		lightPen(NULL),
		darkPen(NULL),
		font(NULL) 
	{
	}

	~GState();

	HBRUSH GetOleForegroundBrush();
	HBRUSH GetOleBackgroundBrush();
	HBRUSH GetForegroundBrush();
	HBRUSH GetBackgroundBrush();
	HBRUSH GetLightBrush();
	HBRUSH GetDarkBrush();
	HPEN GetForegroundPen();
	HPEN GetForegroundFramePen();
	HPEN GetBackgroundPen();
	HPEN GetLightPen();
	HPEN GetDarkPen();
	HFONT GetLastFont(HDC dc);
};


/////////////////////////////////////////////////////////////////////////////
