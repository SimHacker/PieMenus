/////////////////////////////////////////////////////////////////////////////
//
// PieMenuInfo.h : Implementation of the CPieMenuInfo property page class.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CPieMenuInfo dialog

class CPieMenuInfo : public COlePropertyPage
{
	DECLARE_DYNCREATE(CPieMenuInfo)
	DECLARE_OLECREATE_EX(CPieMenuInfo)

// Construction
public:
	CPieMenuInfo();

// Dialog Data
	//{{AFX_DATA(CPieMenuInfo)
	enum { IDD = IDD_PROPPAGE_PIEMENU_INFO };
	CEdit	m_Info;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CPieMenuInfo)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
