/////////////////////////////////////////////////////////////////////////////
//
// PieMenuLevel.h : Pie Menu Level
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// Class CPieMenuLevel


enum {
	kCollapsedGroupHeight = 8
};


enum {
	kLevelLayoutInitialAngle = 1,
	kLevelLayoutClockwise = 2,
	kLevelLayoutFixedRadius = 4
};


enum {
	kEmpty = -1,
	kNorth = 0,
	kNorthEast = 1,
	kEast = 2,
	kSouthEast = 3,
	kSouth = 4,
	kSouthWest = 5,
	kWest = 6,
	kNorthWest = 7,
	kOther = 8
};


class CPieMenuLevel {
	friend class CPieMenuEntry;
	friend class CPieMenuCtrl;

public:
	CPieMenuCtrl *pie;
	CPieMenuLevel *parent;
	CPieMenuLevel *child;
	CPieMenuLevel *next;
	long parentIndex;
	long maxEntries;
	long numEntries;
	CPieMenuEntry **entries;
	int firstSlice;
	int lastSlice;
	int slicesUsed;
	int slices;
	int *storage2direction;
	int *direction2storage;
	char *storage2display;
	char *display2storage;
	long indent;
	long initialAngle;
	long clockwise;
	long activeItem;
	long activeGroupItem;

	HWND popupWindow;
	HRGN windowRegion;
	long popupX;
	long popupY;
	long popupWidth;
	long popupHeight;
	long popupDownX;
	long popupDownY;
	long popupCenterX;
	long popupCenterY;
	long shapeHotX;
	long shapeHotY;
	long shapeWidth;
	long shapeHeight;
	long levelNeedsLayout;
	long labelRadius;
	long fixedRadius;
	long maxRadius;
	long shown;
	long flags;
	long topItem;
	long beginningEntry;
	long endingEntry;
	long groupsStackedAbove;
	long groupsStackedBelow;

	class IndexMapping {
	public:

		IndexMapping(int slicesUsed0,
					 int slices0,
					 int *storage2direction0,
					 char *storage2display0,
					 char *display2storage0) :
			slicesUsed(slicesUsed0),
			slices(slices0),
			storage2direction(storage2direction0),
			storage2display(storage2display0),
			display2storage(display2storage0) {}

		int slicesUsed;
		int slices;
		int *storage2direction;
		char *storage2display;
		char *display2storage;
	};

	static IndexMapping indexMap[9];

	CPieMenuLevel(CPieMenuCtrl *pie0) :
		parent(NULL),
		child(NULL),
		next(NULL),
		parentIndex(0),
		popupWindow(NULL),
		windowRegion(NULL),
		maxEntries(0),
		numEntries(0),
		entries(NULL),
		firstSlice(0),
		lastSlice(0),
		slicesUsed(0),
		slices(0),
		storage2direction(NULL),
		direction2storage(NULL),
		storage2display(NULL),
		display2storage(NULL),
		indent(0),
		activeItem(-1),
		activeGroupItem(-1),
		popupX(0),
		popupY(0),
		popupWidth(0),
		popupHeight(0),
		popupDownX(0),
		popupDownY(0),
		popupCenterX(0),
		popupCenterY(0),
		shapeHotX(0),
		shapeHotY(0),
		shapeWidth(0),
		shapeHeight(0),
		levelNeedsLayout(0),
		labelRadius(0),
		maxRadius(0),
		shown(0),
		pie(pie0),
		initialAngle(pie0->initialAngle),
		clockwise(pie0->clockwise),
		fixedRadius(pie0->fixedRadius),
		flags(0),
		topItem(0),
		beginningEntry(0),
		endingEntry(0),
		groupsStackedAbove(0),
		groupsStackedBelow(0)
	{
	}

	~CPieMenuLevel();

public:

	void CalcQuadNumDen(float x, 
						float y, 
						long &quad, 
						float &num, 
						float &den);
	int CompareEdges(long quad1,
					 float num1,
					 float den1,
					 long quad2,
					 float slope2);
	int CalcPieMenuItem(long x, 
						long y);
	long PieLevelWindowProc(HWND hWnd, 
							UINT message, 
							WPARAM wParam,
							LPARAM lParam);
	void Paint(HDC dcWindow,
			   GState *g);
	void PaintSlices(HDC dc);
	void PaintBevel(HDC dc,
					GState *g,
					int width, 
					int height,
					HRGN region,
					HPEN darkPen,
					HPEN lightPen);
	void PaintBevelFromDepthMap(HDC dc,
								unsigned char *baseAddr,
								int fatWidth,
								int fatHeight,
								int rowBytes,
								HPEN darkPen,
								HPEN medDarkPen,
								HPEN medLightPen,
								HPEN lightPen);
	CPieMenuLevel *GetLevel(int i);
	void SetNeedsLayout();
	void Layout();
	void MakeWindow();
	void ShapeWindow();
	void UpdateCursor();
	void PopUp(long x, long y);
	void Show();
	void Hide();
	void Home(int dx = 0, int dy = 0);
	void NextItem(int steps);
	void NextItemKey(int key);
	int TryScroll(long x, long y);
	void ScrollItems(int dir, int dist = 0);
	void ScrollToShow(int index, int encompass);
	CPieMenuLevel *Back();
	void Cancel();
	CPieMenuEntry *CurrentEntry();
	void AddEntry(CPieMenuEntry *ent, int index = -1);
	void Shrink();
	void Decompile(CString &str,
				   int indent);
};


/////////////////////////////////////////////////////////////////////////////
