This is the source code to the ActiveX Pie Menu Control,
designed and written by Don Hopkins (don@toad.com).

More information about pie menus, and the latest version
of this source code as well as a compiled binary piemenu.ocx,
can be found on the pie menu web page at:

http://www.catalog.com/hopkins/piemenu/index.html

This compiles under Microsoft Visual C++ 5.0.
There is some documentation and instructions in the Doc directory.
You should check the web for the latest and most complete information, though. 

Currently the pie menu control is not signed. 
If you don't trust me, you can read over the source code (which even has some comments),
compile it yourself, and sign it with your own certificate if you want. 
At some point I will get around to distributing a piemenu.ocx that's signed
with my own software developer certificate, but I haven't had time to do that yet. 

Copyright notice and comments from the code:

/////////////////////////////////////////////////////////////////////////////
//
// PieMenuCtl.cpp : Pie Menu ActiveX Control.
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
// mailto:don@toad.com
// mailto:dhopkins@maxis.com
// http://www.catalog.com/hopkins
// http://www.catalog.com/hopkins/piemenus/index.html
//
// This program is provided for unrestricted use, 
// provided that this copyright message is preserved. 
// There is no warranty, and no author or distributer 
// accepts responsibility for any damage caused by 
// this program. 
// 
// This code and the ideas behind it were developed 
// over time by Don Hopkins, thanks to the support of:
// University of Maryland, UniPress Software, 
// Sun Microsystems, DUX Software, Turing Institute, 
// Carnegie Mellon University, Kaleida Labs, 
// Interval Research Corporation, and Maxis Software.
//
// The ideas behind pie menus are not patented or 
// restricted in any way, and the interface and 
// algorithms may be freely copied and improved upon. 
// Don't bother patenting the idea yourself, because 
// it's been around for a long time, and your patent
// will be easy to challenge. 
//
// Pie menus are the natural result of optimizing an 
// interface with respect to Fitt's Law, which states 
// that the time it takes to hit a target (and the error 
// rate) is lower, the bigger and closer the target. 
// So all the pie menu targets are big and close. 
//
/////////////////////////////////////////////////////////////////////////////

