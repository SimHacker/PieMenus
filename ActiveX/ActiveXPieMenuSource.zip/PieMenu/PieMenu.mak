# Microsoft Developer Studio Generated NMAKE File, Format Version 4.20
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

!IF "$(CFG)" == ""
CFG=piemenu - Win32 Debug
!MESSAGE No configuration specified.  Defaulting to piemenu - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "piemenu - Win32 Release" && "$(CFG)" !=\
 "piemenu - Win32 Debug" && "$(CFG)" != "piemenu - Win32 Profile"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE on this makefile
!MESSAGE by defining the macro CFG on the command line.  For example:
!MESSAGE 
!MESSAGE NMAKE /f "PieMenu.mak" CFG="piemenu - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "piemenu - Win32 Release" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE "piemenu - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "piemenu - Win32 Profile" (based on\
 "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 
################################################################################
# Begin Project
# PROP Target_Last_Scanned "piemenu - Win32 Profile"
RSC=rc.exe
MTL=mktyplib.exe
CPP=cl.exe

!IF  "$(CFG)" == "piemenu - Win32 Release"

# PROP BASE Use_MFC 2
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP BASE Target_Ext "ocx"
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# PROP Target_Ext "ocx"
OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "$(OUTDIR)\PieMenu.ocx" "$(OUTDIR)\PieMenu.bsc" "$(OUTDIR)\regsvr32.trg"

CLEAN : 
	-@erase "$(INTDIR)\GState.obj"
	-@erase "$(INTDIR)\GState.sbr"
	-@erase "$(INTDIR)\piemenu.obj"
	-@erase "$(INTDIR)\PieMenu.pch"
	-@erase "$(INTDIR)\piemenu.res"
	-@erase "$(INTDIR)\piemenu.sbr"
	-@erase "$(INTDIR)\piemenu.tlb"
	-@erase "$(INTDIR)\PieMenuAboutBox.obj"
	-@erase "$(INTDIR)\PieMenuAboutBox.sbr"
	-@erase "$(INTDIR)\PieMenuCtl.obj"
	-@erase "$(INTDIR)\PieMenuCtl.sbr"
	-@erase "$(INTDIR)\PieMenuEntry.obj"
	-@erase "$(INTDIR)\PieMenuEntry.sbr"
	-@erase "$(INTDIR)\PieMenuInfo.obj"
	-@erase "$(INTDIR)\PieMenuInfo.sbr"
	-@erase "$(INTDIR)\PieMenuLevel.obj"
	-@erase "$(INTDIR)\PieMenuLevel.sbr"
	-@erase "$(INTDIR)\PieMenuPpg.obj"
	-@erase "$(INTDIR)\PieMenuPpg.sbr"
	-@erase "$(INTDIR)\PieMenuPpg2.obj"
	-@erase "$(INTDIR)\PieMenuPpg2.sbr"
	-@erase "$(INTDIR)\PieMenuPpg3.obj"
	-@erase "$(INTDIR)\PieMenuPpg3.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(OUTDIR)\PieMenu.bsc"
	-@erase "$(OUTDIR)\PieMenu.exp"
	-@erase "$(OUTDIR)\PieMenu.lib"
	-@erase "$(OUTDIR)\PieMenu.ocx"
	-@erase "$(OUTDIR)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR /Yu"stdafx.h" /c
CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)/"\
 /Fp"$(INTDIR)/PieMenu.pch" /Yu"stdafx.h" /Fo"$(INTDIR)/" /c 
CPP_OBJS=.\Release/
CPP_SBRS=.\Release/
# ADD BASE MTL /nologo /D "NDEBUG" /win32
# ADD MTL /nologo /D "NDEBUG" /win32
MTL_PROJ=/nologo /D "NDEBUG" /win32 
# ADD BASE RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/piemenu.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/PieMenu.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\GState.sbr" \
	"$(INTDIR)\piemenu.sbr" \
	"$(INTDIR)\PieMenuAboutBox.sbr" \
	"$(INTDIR)\PieMenuCtl.sbr" \
	"$(INTDIR)\PieMenuEntry.sbr" \
	"$(INTDIR)\PieMenuInfo.sbr" \
	"$(INTDIR)\PieMenuLevel.sbr" \
	"$(INTDIR)\PieMenuPpg.sbr" \
	"$(INTDIR)\PieMenuPpg2.sbr" \
	"$(INTDIR)\PieMenuPpg3.sbr" \
	"$(INTDIR)\StdAfx.sbr"

"$(OUTDIR)\PieMenu.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 /nologo /subsystem:windows /dll /machine:I386
LINK32_FLAGS=/nologo /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)/PieMenu.pdb" /machine:I386 /def:".\piemenu.def"\
 /out:"$(OUTDIR)/PieMenu.ocx" /implib:"$(OUTDIR)/PieMenu.lib" 
DEF_FILE= \
	".\piemenu.def"
LINK32_OBJS= \
	"$(INTDIR)\GState.obj" \
	"$(INTDIR)\piemenu.obj" \
	"$(INTDIR)\piemenu.res" \
	"$(INTDIR)\PieMenuAboutBox.obj" \
	"$(INTDIR)\PieMenuCtl.obj" \
	"$(INTDIR)\PieMenuEntry.obj" \
	"$(INTDIR)\PieMenuInfo.obj" \
	"$(INTDIR)\PieMenuLevel.obj" \
	"$(INTDIR)\PieMenuPpg.obj" \
	"$(INTDIR)\PieMenuPpg2.obj" \
	"$(INTDIR)\PieMenuPpg3.obj" \
	"$(INTDIR)\StdAfx.obj"

"$(OUTDIR)\PieMenu.ocx" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

# Begin Custom Build - Registering OLE control...
OutDir=.\Release
TargetPath=.\Release\PieMenu.ocx
InputPath=.\Release\PieMenu.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   regsvr32 /s /c "$(TargetPath)"

# End Custom Build

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

# PROP BASE Use_MFC 2
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP BASE Target_Ext "ocx"
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# PROP Target_Ext "ocx"
OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\PieMenu.ocx" "$(OUTDIR)\PieMenu.bsc" "$(OUTDIR)\regsvr32.trg"

CLEAN : 
	-@erase "$(INTDIR)\GState.obj"
	-@erase "$(INTDIR)\GState.sbr"
	-@erase "$(INTDIR)\piemenu.obj"
	-@erase "$(INTDIR)\PieMenu.pch"
	-@erase "$(INTDIR)\piemenu.res"
	-@erase "$(INTDIR)\piemenu.sbr"
	-@erase "$(INTDIR)\piemenu.tlb"
	-@erase "$(INTDIR)\PieMenuAboutBox.obj"
	-@erase "$(INTDIR)\PieMenuAboutBox.sbr"
	-@erase "$(INTDIR)\PieMenuCtl.obj"
	-@erase "$(INTDIR)\PieMenuCtl.sbr"
	-@erase "$(INTDIR)\PieMenuEntry.obj"
	-@erase "$(INTDIR)\PieMenuEntry.sbr"
	-@erase "$(INTDIR)\PieMenuInfo.obj"
	-@erase "$(INTDIR)\PieMenuInfo.sbr"
	-@erase "$(INTDIR)\PieMenuLevel.obj"
	-@erase "$(INTDIR)\PieMenuLevel.sbr"
	-@erase "$(INTDIR)\PieMenuPpg.obj"
	-@erase "$(INTDIR)\PieMenuPpg.sbr"
	-@erase "$(INTDIR)\PieMenuPpg2.obj"
	-@erase "$(INTDIR)\PieMenuPpg2.sbr"
	-@erase "$(INTDIR)\PieMenuPpg3.obj"
	-@erase "$(INTDIR)\PieMenuPpg3.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\vc40.idb"
	-@erase "$(INTDIR)\vc40.pdb"
	-@erase "$(OUTDIR)\PieMenu.bsc"
	-@erase "$(OUTDIR)\PieMenu.exp"
	-@erase "$(OUTDIR)\PieMenu.ilk"
	-@erase "$(OUTDIR)\PieMenu.lib"
	-@erase "$(OUTDIR)\PieMenu.ocx"
	-@erase "$(OUTDIR)\PieMenu.pdb"
	-@erase "$(OUTDIR)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR /Yu"stdafx.h" /c
CPP_PROJ=/nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS"\
 /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)/"\
 /Fp"$(INTDIR)/PieMenu.pch" /Yu"stdafx.h" /Fo"$(INTDIR)/" /Fd"$(INTDIR)/" /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.\Debug/
# ADD BASE MTL /nologo /D "_DEBUG" /win32
# ADD MTL /nologo /D "_DEBUG" /win32
MTL_PROJ=/nologo /D "_DEBUG" /win32 
# ADD BASE RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/piemenu.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/PieMenu.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\GState.sbr" \
	"$(INTDIR)\piemenu.sbr" \
	"$(INTDIR)\PieMenuAboutBox.sbr" \
	"$(INTDIR)\PieMenuCtl.sbr" \
	"$(INTDIR)\PieMenuEntry.sbr" \
	"$(INTDIR)\PieMenuInfo.sbr" \
	"$(INTDIR)\PieMenuLevel.sbr" \
	"$(INTDIR)\PieMenuPpg.sbr" \
	"$(INTDIR)\PieMenuPpg2.sbr" \
	"$(INTDIR)\PieMenuPpg3.sbr" \
	"$(INTDIR)\StdAfx.sbr"

"$(OUTDIR)\PieMenu.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /dll /debug /machine:I386
# ADD LINK32 /nologo /subsystem:windows /dll /debug /machine:I386
LINK32_FLAGS=/nologo /subsystem:windows /dll /incremental:yes\
 /pdb:"$(OUTDIR)/PieMenu.pdb" /debug /machine:I386 /def:".\piemenu.def"\
 /out:"$(OUTDIR)/PieMenu.ocx" /implib:"$(OUTDIR)/PieMenu.lib" 
DEF_FILE= \
	".\piemenu.def"
LINK32_OBJS= \
	"$(INTDIR)\GState.obj" \
	"$(INTDIR)\piemenu.obj" \
	"$(INTDIR)\piemenu.res" \
	"$(INTDIR)\PieMenuAboutBox.obj" \
	"$(INTDIR)\PieMenuCtl.obj" \
	"$(INTDIR)\PieMenuEntry.obj" \
	"$(INTDIR)\PieMenuInfo.obj" \
	"$(INTDIR)\PieMenuLevel.obj" \
	"$(INTDIR)\PieMenuPpg.obj" \
	"$(INTDIR)\PieMenuPpg2.obj" \
	"$(INTDIR)\PieMenuPpg3.obj" \
	"$(INTDIR)\StdAfx.obj"

"$(OUTDIR)\PieMenu.ocx" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

# Begin Custom Build
OutDir=.\Debug
TargetPath=.\Debug\PieMenu.ocx
InputPath=.\Debug\PieMenu.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   regsvr32 /s /c "$(TargetPath)"

# End Custom Build

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

# PROP BASE Use_MFC 2
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "piemenu_"
# PROP BASE Intermediate_Dir "piemenu_"
# PROP BASE Target_Dir ""
# PROP BASE Target_Ext "ocx"
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Profile"
# PROP Intermediate_Dir "Profile"
# PROP Target_Dir ""
# PROP Target_Ext "ocx"
OUTDIR=.\Profile
INTDIR=.\Profile
# Begin Custom Macros
OutDir=.\Profile
# End Custom Macros

ALL : "$(OUTDIR)\PieMenu.ocx" "$(OUTDIR)\PieMenu.bsc" "$(OUTDIR)\regsvr32.trg"

CLEAN : 
	-@erase "$(INTDIR)\GState.obj"
	-@erase "$(INTDIR)\GState.sbr"
	-@erase "$(INTDIR)\piemenu.obj"
	-@erase "$(INTDIR)\PieMenu.pch"
	-@erase "$(INTDIR)\piemenu.res"
	-@erase "$(INTDIR)\piemenu.sbr"
	-@erase "$(INTDIR)\piemenu.tlb"
	-@erase "$(INTDIR)\PieMenuAboutBox.obj"
	-@erase "$(INTDIR)\PieMenuAboutBox.sbr"
	-@erase "$(INTDIR)\PieMenuCtl.obj"
	-@erase "$(INTDIR)\PieMenuCtl.sbr"
	-@erase "$(INTDIR)\PieMenuEntry.obj"
	-@erase "$(INTDIR)\PieMenuEntry.sbr"
	-@erase "$(INTDIR)\PieMenuInfo.obj"
	-@erase "$(INTDIR)\PieMenuInfo.sbr"
	-@erase "$(INTDIR)\PieMenuLevel.obj"
	-@erase "$(INTDIR)\PieMenuLevel.sbr"
	-@erase "$(INTDIR)\PieMenuPpg.obj"
	-@erase "$(INTDIR)\PieMenuPpg.sbr"
	-@erase "$(INTDIR)\PieMenuPpg2.obj"
	-@erase "$(INTDIR)\PieMenuPpg2.sbr"
	-@erase "$(INTDIR)\PieMenuPpg3.obj"
	-@erase "$(INTDIR)\PieMenuPpg3.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\vc40.pdb"
	-@erase "$(OUTDIR)\PieMenu.bsc"
	-@erase "$(OUTDIR)\PieMenu.exp"
	-@erase "$(OUTDIR)\PieMenu.lib"
	-@erase "$(OUTDIR)\PieMenu.map"
	-@erase "$(OUTDIR)\PieMenu.ocx"
	-@erase "$(OUTDIR)\regsvr32.trg"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR /Yu"stdafx.h" /c
# ADD CPP /nologo /MD /W3 /GX /Zi /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR /Yu"stdafx.h" /c
CPP_PROJ=/nologo /MD /W3 /GX /Zi /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)/"\
 /Fp"$(INTDIR)/PieMenu.pch" /Yu"stdafx.h" /Fo"$(INTDIR)/" /Fd"$(INTDIR)/" /c 
CPP_OBJS=.\Profile/
CPP_SBRS=.\Profile/
# ADD BASE MTL /nologo /D "NDEBUG" /win32
# ADD MTL /nologo /D "NDEBUG" /win32
MTL_PROJ=/nologo /D "NDEBUG" /win32 
# ADD BASE RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
RSC_PROJ=/l 0x409 /fo"$(INTDIR)/piemenu.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/PieMenu.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\GState.sbr" \
	"$(INTDIR)\piemenu.sbr" \
	"$(INTDIR)\PieMenuAboutBox.sbr" \
	"$(INTDIR)\PieMenuCtl.sbr" \
	"$(INTDIR)\PieMenuEntry.sbr" \
	"$(INTDIR)\PieMenuInfo.sbr" \
	"$(INTDIR)\PieMenuLevel.sbr" \
	"$(INTDIR)\PieMenuPpg.sbr" \
	"$(INTDIR)\PieMenuPpg2.sbr" \
	"$(INTDIR)\PieMenuPpg3.sbr" \
	"$(INTDIR)\StdAfx.sbr"

"$(OUTDIR)\PieMenu.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 /nologo /subsystem:windows /dll /profile /map /debug /machine:I386
LINK32_FLAGS=/nologo /subsystem:windows /dll /profile\
 /map:"$(INTDIR)/PieMenu.map" /debug /machine:I386 /def:".\piemenu.def"\
 /out:"$(OUTDIR)/PieMenu.ocx" /implib:"$(OUTDIR)/PieMenu.lib" 
DEF_FILE= \
	".\piemenu.def"
LINK32_OBJS= \
	"$(INTDIR)\GState.obj" \
	"$(INTDIR)\piemenu.obj" \
	"$(INTDIR)\piemenu.res" \
	"$(INTDIR)\PieMenuAboutBox.obj" \
	"$(INTDIR)\PieMenuCtl.obj" \
	"$(INTDIR)\PieMenuEntry.obj" \
	"$(INTDIR)\PieMenuInfo.obj" \
	"$(INTDIR)\PieMenuLevel.obj" \
	"$(INTDIR)\PieMenuPpg.obj" \
	"$(INTDIR)\PieMenuPpg2.obj" \
	"$(INTDIR)\PieMenuPpg3.obj" \
	"$(INTDIR)\StdAfx.obj"

"$(OUTDIR)\PieMenu.ocx" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

# Begin Custom Build - Registering OLE control...
OutDir=.\Profile
TargetPath=.\Profile\PieMenu.ocx
InputPath=.\Profile\PieMenu.ocx
SOURCE=$(InputPath)

"$(OutDir)\regsvr32.trg" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
   regsvr32 /s /c "$(TargetPath)"

# End Custom Build

!ENDIF 

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

################################################################################
# Begin Target

# Name "piemenu - Win32 Release"
# Name "piemenu - Win32 Debug"
# Name "piemenu - Win32 Profile"

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

################################################################################
# Begin Source File

SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_STDAF=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	
# ADD CPP /Yc"stdafx.h"

BuildCmds= \
	$(CPP) /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)/"\
 /Fp"$(INTDIR)/PieMenu.pch" /Yc"stdafx.h" /Fo"$(INTDIR)/" /c $(SOURCE) \
	

"$(INTDIR)\StdAfx.obj" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\StdAfx.sbr" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\PieMenu.pch" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_STDAF=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	
# ADD CPP /Yc"stdafx.h"

BuildCmds= \
	$(CPP) /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS"\
 /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)/"\
 /Fp"$(INTDIR)/PieMenu.pch" /Yc"stdafx.h" /Fo"$(INTDIR)/" /Fd"$(INTDIR)/" /c\
 $(SOURCE) \
	

"$(INTDIR)\StdAfx.obj" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\StdAfx.sbr" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\PieMenu.pch" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_STDAF=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	
# ADD BASE CPP /Yc"stdafx.h"
# ADD CPP /Yc"stdafx.h"

BuildCmds= \
	$(CPP) /nologo /MD /W3 /GX /Zi /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)/"\
 /Fp"$(INTDIR)/PieMenu.pch" /Yc"stdafx.h" /Fo"$(INTDIR)/" /Fd"$(INTDIR)/" /c\
 $(SOURCE) \
	

"$(INTDIR)\StdAfx.obj" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\StdAfx.sbr" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\PieMenu.pch" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\piemenu.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEME=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\piemenu.obj" : $(SOURCE) $(DEP_CPP_PIEME) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\piemenu.sbr" : $(SOURCE) $(DEP_CPP_PIEME) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEME=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\piemenu.obj" : $(SOURCE) $(DEP_CPP_PIEME) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\piemenu.sbr" : $(SOURCE) $(DEP_CPP_PIEME) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEME=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\piemenu.obj" : $(SOURCE) $(DEP_CPP_PIEME) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\piemenu.sbr" : $(SOURCE) $(DEP_CPP_PIEME) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\piemenu.def

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\piemenu.rc

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_RSC_PIEMEN=\
	".\Resources\AboutDLL.ico"\
	".\Resources\cur00001.cur"\
	".\Resources\cur00002.cur"\
	".\Resources\cur00003.cur"\
	".\Resources\cur00004.cur"\
	".\Resources\cur00005.cur"\
	".\Resources\cur00006.cur"\
	".\Resources\cur00007.cur"\
	".\Resources\cur00008.cur"\
	".\Resources\cur00009.cur"\
	".\Resources\cur00010.cur"\
	".\Resources\cur00011.cur"\
	".\Resources\cur00012.cur"\
	".\Resources\cur00013.cur"\
	".\Resources\cur00014.cur"\
	".\Resources\cur00015.cur"\
	".\Resources\cur00016.cur"\
	".\Resources\cur00017.cur"\
	".\Resources\cur00018.cur"\
	".\Resources\cur00019.cur"\
	".\Resources\cur00020.cur"\
	".\Resources\cur00021.cur"\
	".\Resources\cur00022.cur"\
	".\Resources\cur00023.cur"\
	".\Resources\cur00024.cur"\
	".\Resources\cur00025.cur"\
	".\Resources\cur00026.cur"\
	".\Resources\cur00027.cur"\
	".\Resources\cur00028.cur"\
	".\Resources\cursor1.cur"\
	".\Resources\flower1.cur"\
	".\Resources\flower10.cur"\
	".\Resources\flower11.cur"\
	".\Resources\flower12.cur"\
	".\Resources\flower13.cur"\
	".\Resources\flower14.cur"\
	".\Resources\flower15.cur"\
	".\Resources\flower16.cur"\
	".\Resources\flower2.cur"\
	".\Resources\flower3.cur"\
	".\Resources\flower4.cur"\
	".\Resources\flower5.cur"\
	".\Resources\flower6.cur"\
	".\Resources\flower7.cur"\
	".\Resources\flower8.cur"\
	".\Resources\flower9.cur"\
	".\Resources\Ico00001.ico"\
	".\Resources\PieMenu.ico"\
	".\Resources\PieMenu2.bmp"\
	".\Resources\PieMenuCtl.bmp"\
	
NODEP_RSC_PIEMEN=\
	".\Release\piemenu.tlb"\
	

"$(INTDIR)\piemenu.res" : $(SOURCE) $(DEP_RSC_PIEMEN) "$(INTDIR)"\
 "$(INTDIR)\piemenu.tlb"
   $(RSC) /l 0x409 /fo"$(INTDIR)/piemenu.res" /i "Release" /d "NDEBUG" /d\
 "_AFXDLL" $(SOURCE)


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_RSC_PIEMEN=\
	".\Debug\piemenu.tlb"\
	".\Resources\AboutDLL.ico"\
	".\Resources\cur00001.cur"\
	".\Resources\cur00002.cur"\
	".\Resources\cur00003.cur"\
	".\Resources\cur00004.cur"\
	".\Resources\cur00005.cur"\
	".\Resources\cur00006.cur"\
	".\Resources\cur00007.cur"\
	".\Resources\cur00008.cur"\
	".\Resources\cur00009.cur"\
	".\Resources\cur00010.cur"\
	".\Resources\cur00011.cur"\
	".\Resources\cur00012.cur"\
	".\Resources\cur00013.cur"\
	".\Resources\cur00014.cur"\
	".\Resources\cur00015.cur"\
	".\Resources\cur00016.cur"\
	".\Resources\cur00017.cur"\
	".\Resources\cur00018.cur"\
	".\Resources\cur00019.cur"\
	".\Resources\cur00020.cur"\
	".\Resources\cur00021.cur"\
	".\Resources\cur00022.cur"\
	".\Resources\cur00023.cur"\
	".\Resources\cur00024.cur"\
	".\Resources\cur00025.cur"\
	".\Resources\cur00026.cur"\
	".\Resources\cur00027.cur"\
	".\Resources\cur00028.cur"\
	".\Resources\cursor1.cur"\
	".\Resources\flower1.cur"\
	".\Resources\flower10.cur"\
	".\Resources\flower11.cur"\
	".\Resources\flower12.cur"\
	".\Resources\flower13.cur"\
	".\Resources\flower14.cur"\
	".\Resources\flower15.cur"\
	".\Resources\flower16.cur"\
	".\Resources\flower2.cur"\
	".\Resources\flower3.cur"\
	".\Resources\flower4.cur"\
	".\Resources\flower5.cur"\
	".\Resources\flower6.cur"\
	".\Resources\flower7.cur"\
	".\Resources\flower8.cur"\
	".\Resources\flower9.cur"\
	".\Resources\Ico00001.ico"\
	".\Resources\PieMenu.ico"\
	".\Resources\PieMenu2.bmp"\
	".\Resources\PieMenuCtl.bmp"\
	

"$(INTDIR)\piemenu.res" : $(SOURCE) $(DEP_RSC_PIEMEN) "$(INTDIR)"\
 "$(INTDIR)\piemenu.tlb"
   $(RSC) /l 0x409 /fo"$(INTDIR)/piemenu.res" /i "Debug" /d "_DEBUG" /d\
 "_AFXDLL" $(SOURCE)


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_RSC_PIEMEN=\
	".\Resources\AboutDLL.ico"\
	".\Resources\cur00001.cur"\
	".\Resources\cur00002.cur"\
	".\Resources\cur00003.cur"\
	".\Resources\cur00004.cur"\
	".\Resources\cur00005.cur"\
	".\Resources\cur00006.cur"\
	".\Resources\cur00007.cur"\
	".\Resources\cur00008.cur"\
	".\Resources\cur00009.cur"\
	".\Resources\cur00010.cur"\
	".\Resources\cur00011.cur"\
	".\Resources\cur00012.cur"\
	".\Resources\cur00013.cur"\
	".\Resources\cur00014.cur"\
	".\Resources\cur00015.cur"\
	".\Resources\cur00016.cur"\
	".\Resources\cur00017.cur"\
	".\Resources\cur00018.cur"\
	".\Resources\cur00019.cur"\
	".\Resources\cur00020.cur"\
	".\Resources\cur00021.cur"\
	".\Resources\cur00022.cur"\
	".\Resources\cur00023.cur"\
	".\Resources\cur00024.cur"\
	".\Resources\cur00025.cur"\
	".\Resources\cur00026.cur"\
	".\Resources\cur00027.cur"\
	".\Resources\cur00028.cur"\
	".\Resources\cursor1.cur"\
	".\Resources\flower1.cur"\
	".\Resources\flower10.cur"\
	".\Resources\flower11.cur"\
	".\Resources\flower12.cur"\
	".\Resources\flower13.cur"\
	".\Resources\flower14.cur"\
	".\Resources\flower15.cur"\
	".\Resources\flower16.cur"\
	".\Resources\flower2.cur"\
	".\Resources\flower3.cur"\
	".\Resources\flower4.cur"\
	".\Resources\flower5.cur"\
	".\Resources\flower6.cur"\
	".\Resources\flower7.cur"\
	".\Resources\flower8.cur"\
	".\Resources\flower9.cur"\
	".\Resources\Ico00001.ico"\
	".\Resources\PieMenu.ico"\
	".\Resources\PieMenu2.bmp"\
	".\Resources\PieMenuCtl.bmp"\
	
NODEP_RSC_PIEMEN=\
	".\Profile\piemenu.tlb"\
	

"$(INTDIR)\piemenu.res" : $(SOURCE) $(DEP_RSC_PIEMEN) "$(INTDIR)"\
 "$(INTDIR)\piemenu.tlb"
   $(RSC) /l 0x409 /fo"$(INTDIR)/piemenu.res" /i "Profile" /d "NDEBUG" /d\
 "_AFXDLL" $(SOURCE)


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\piemenu.odl

!IF  "$(CFG)" == "piemenu - Win32 Release"


"$(OUTDIR)\piemenu.tlb" : $(SOURCE) "$(OUTDIR)"
   $(MTL) /nologo /D "NDEBUG" /tlb "$(OUTDIR)/piemenu.tlb" /win32 $(SOURCE)


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"


"$(OUTDIR)\piemenu.tlb" : $(SOURCE) "$(OUTDIR)"
   $(MTL) /nologo /D "_DEBUG" /tlb "$(OUTDIR)/piemenu.tlb" /win32 $(SOURCE)


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"


"$(OUTDIR)\piemenu.tlb" : $(SOURCE) "$(OUTDIR)"
   $(MTL) /nologo /D "NDEBUG" /tlb "$(OUTDIR)/piemenu.tlb" /win32 $(SOURCE)


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuCtl.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEMENU=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuAboutBox.h"\
	".\PieMenuCtl.h"\
	".\PieMenuInfo.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg.h"\
	".\PieMenuPpg2.h"\
	".\PieMenuPpg3.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuCtl.obj" : $(SOURCE) $(DEP_CPP_PIEMENU) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuCtl.sbr" : $(SOURCE) $(DEP_CPP_PIEMENU) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEMENU=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuAboutBox.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuInfo.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg.h"\
	".\PieMenuPpg2.h"\
	".\PieMenuPpg3.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuCtl.obj" : $(SOURCE) $(DEP_CPP_PIEMENU) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuCtl.sbr" : $(SOURCE) $(DEP_CPP_PIEMENU) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEMENU=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuAboutBox.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuInfo.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg.h"\
	".\PieMenuPpg2.h"\
	".\PieMenuPpg3.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuCtl.obj" : $(SOURCE) $(DEP_CPP_PIEMENU) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuCtl.sbr" : $(SOURCE) $(DEP_CPP_PIEMENU) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuPpg.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEMENUP=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg.obj" : $(SOURCE) $(DEP_CPP_PIEMENUP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEMENUP=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg.obj" : $(SOURCE) $(DEP_CPP_PIEMENUP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEMENUP=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg.obj" : $(SOURCE) $(DEP_CPP_PIEMENUP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuInfo.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEMENUI=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuInfo.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuInfo.obj" : $(SOURCE) $(DEP_CPP_PIEMENUI) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuInfo.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUI) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEMENUI=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuInfo.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuInfo.obj" : $(SOURCE) $(DEP_CPP_PIEMENUI) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuInfo.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUI) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEMENUI=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuInfo.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuInfo.obj" : $(SOURCE) $(DEP_CPP_PIEMENUI) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuInfo.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUI) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuPpg2.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEMENUPP=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg2.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg2.obj" : $(SOURCE) $(DEP_CPP_PIEMENUPP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg2.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUPP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEMENUPP=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg2.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg2.obj" : $(SOURCE) $(DEP_CPP_PIEMENUPP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg2.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUPP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEMENUPP=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg2.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg2.obj" : $(SOURCE) $(DEP_CPP_PIEMENUPP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg2.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUPP) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuAboutBox.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEMENUA=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuAboutBox.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuAboutBox.obj" : $(SOURCE) $(DEP_CPP_PIEMENUA) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuAboutBox.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUA) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEMENUA=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuAboutBox.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuAboutBox.obj" : $(SOURCE) $(DEP_CPP_PIEMENUA) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuAboutBox.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUA) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEMENUA=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuAboutBox.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuAboutBox.obj" : $(SOURCE) $(DEP_CPP_PIEMENUA) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuAboutBox.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUA) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuPpg3.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEMENUPPG=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg3.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg3.obj" : $(SOURCE) $(DEP_CPP_PIEMENUPPG) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg3.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUPPG) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEMENUPPG=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg3.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg3.obj" : $(SOURCE) $(DEP_CPP_PIEMENUPPG) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg3.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUPPG) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEMENUPPG=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\PieMenuPpg3.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuPpg3.obj" : $(SOURCE) $(DEP_CPP_PIEMENUPPG) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuPpg3.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUPPG) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuLevel.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEMENUL=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuLevel.obj" : $(SOURCE) $(DEP_CPP_PIEMENUL) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuLevel.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUL) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEMENUL=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuLevel.obj" : $(SOURCE) $(DEP_CPP_PIEMENUL) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuLevel.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUL) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEMENUL=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuLevel.obj" : $(SOURCE) $(DEP_CPP_PIEMENUL) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuLevel.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUL) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuEntry.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_PIEMENUE=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuEntry.obj" : $(SOURCE) $(DEP_CPP_PIEMENUE) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuEntry.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUE) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_PIEMENUE=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuEntry.obj" : $(SOURCE) $(DEP_CPP_PIEMENUE) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuEntry.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUE) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_PIEMENUE=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\PieMenuEntry.obj" : $(SOURCE) $(DEP_CPP_PIEMENUE) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\PieMenuEntry.sbr" : $(SOURCE) $(DEP_CPP_PIEMENUE) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\GState.cpp

!IF  "$(CFG)" == "piemenu - Win32 Release"

DEP_CPP_GSTAT=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\GState.obj" : $(SOURCE) $(DEP_CPP_GSTAT) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\GState.sbr" : $(SOURCE) $(DEP_CPP_GSTAT) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

DEP_CPP_GSTAT=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\GState.obj" : $(SOURCE) $(DEP_CPP_GSTAT) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\GState.sbr" : $(SOURCE) $(DEP_CPP_GSTAT) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

DEP_CPP_GSTAT=\
	".\GState.h"\
	".\PieMenu.h"\
	".\PieMenuCtl.h"\
	".\PieMenuEntry.h"\
	".\PieMenuLevel.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\GState.obj" : $(SOURCE) $(DEP_CPP_GSTAT) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"

"$(INTDIR)\GState.sbr" : $(SOURCE) $(DEP_CPP_GSTAT) "$(INTDIR)"\
 "$(INTDIR)\PieMenu.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\StdAfx.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenu.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuAboutBox.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuCtl.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuEntry.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuInfo.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuLevel.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuPpg.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuPpg2.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\PieMenuPpg3.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\resource.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\GState.h

!IF  "$(CFG)" == "piemenu - Win32 Release"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Debug"

!ELSEIF  "$(CFG)" == "piemenu - Win32 Profile"

!ENDIF 

# End Source File
# End Target
# End Project
################################################################################
################################################################################
# Section piemenu : {87351BC1-983F-11CF-9A4B-54A4FFC00000}
# 	2:5:Class:CPieMenu
# 	2:10:HeaderFile:piemenuwrapper.h
# 	2:8:ImplFile:piemenuwrapper.cpp
# End Section
################################################################################
################################################################################
# Section OLE Controls
# 	{87351BC3-983F-11CF-9A4B-54A4FFC00000}
# End Section
################################################################################
################################################################################
# Section piemenu : {BEF6E003-A874-101A-8BBA-00AA00300CAB}
# 	2:5:Class:COleFont
# 	2:10:HeaderFile:font.h
# 	2:8:ImplFile:font.cpp
# End Section
################################################################################
################################################################################
# Section piemenu : {87351BC3-983F-11CF-9A4B-54A4FFC00000}
# 	0:9:Picture.h:C:\USERS\DHopkins\piemenu\Picture.h
# 	0:8:Font.cpp:C:\USERS\DHopkins\piemenu\Font.cpp
# 	0:6:Font.h:C:\USERS\DHopkins\piemenu\Font.h
# 	0:11:Picture.cpp:C:\USERS\DHopkins\piemenu\Picture.cpp
# 	0:11:PieMenu.cpp:C:\USERS\DHopkins\piemenu\PieMenu1.cpp
# 	0:9:PieMenu.h:C:\USERS\DHopkins\piemenu\PieMenu1.h
# 	2:21:DefaultSinkHeaderFile:piemenuwrapper.h
# 	2:16:DefaultSinkClass:CPieMenu
# End Section
################################################################################
################################################################################
# Section piemenu : {7BF80981-BF32-101A-8BBB-00AA00300CAB}
# 	2:5:Class:CPicture
# 	2:10:HeaderFile:picture.h
# 	2:8:ImplFile:picture.cpp
# End Section
################################################################################
