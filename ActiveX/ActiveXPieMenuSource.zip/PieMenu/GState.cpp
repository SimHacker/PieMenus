/////////////////////////////////////////////////////////////////////////////
//
// GState.cpp : Graphics State
// Copyright (C) 1997 by Don Hopkins. 
// All rights reserved. 
// Designed and implemented by Don Hopkins. 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"


/////////////////////////////////////////////////////////////////////////////


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Class GState


GState::~GState()
{
	if (oleForegroundBrush != NULL) {
		::DeleteObject(oleForegroundBrush);
	}
	if (oleBackgroundBrush != NULL) {
		::DeleteObject(oleBackgroundBrush);
	}
	if (foregroundBrush != NULL) {
		::DeleteObject(foregroundBrush);
	}
	if (backgroundBrush != NULL) {
		::DeleteObject(backgroundBrush);
	}
	if (lightBrush != NULL) {
		::DeleteObject(lightBrush);
	}
	if (darkBrush != NULL) {
		::DeleteObject(darkBrush);
	}
	if (foregroundPen != NULL) {
		::DeleteObject(foregroundPen);
	}
	if (foregroundFramePen != NULL) {
		::DeleteObject(foregroundFramePen);
	}
	if (backgroundPen != NULL) {
		::DeleteObject(backgroundPen);
	}
	if (lightPen != NULL) {
		::DeleteObject(lightPen);
	}
	if (darkPen != NULL) {
		::DeleteObject(darkPen);
	}
	if (font != NULL) {
		::DeleteObject(font);
	}
}


HBRUSH GState::GetOleForegroundBrush()
{
	if (oleForegroundBrush == NULL) {
		oleForegroundBrush = pie->CreateAnOleForegroundBrush();
	} // if
	return oleForegroundBrush;
}


HBRUSH GState::GetOleBackgroundBrush()
{
	if (oleBackgroundBrush == NULL) {
		oleBackgroundBrush = pie->CreateAnOleBackgroundBrush();
	} // if
	return oleBackgroundBrush;
}


HBRUSH GState::GetForegroundBrush()
{
	if (foregroundBrush == NULL) {
		foregroundBrush = pie->CreateAForegroundBrush();
	} // if
	return foregroundBrush;
}


HBRUSH GState::GetBackgroundBrush()
{
	if (backgroundBrush == NULL) {
		backgroundBrush = pie->CreateABackgroundBrush();
	} // if
	return backgroundBrush;
}


HBRUSH GState::GetLightBrush()
{
	if (lightBrush == NULL) {
		lightBrush = pie->CreateALightBrush();
	} // if
	return lightBrush;
}


HBRUSH GState::GetDarkBrush()
{
	if (darkBrush == NULL) {
		darkBrush = pie->CreateADarkBrush();
	} // if
	return darkBrush;
}


HPEN GState::GetForegroundPen()
{
	if (foregroundPen == NULL) {
		foregroundPen = pie->CreateAForegroundPen();
	} // if
	return foregroundPen;
}


HPEN GState::GetForegroundFramePen()
{
	if (foregroundFramePen == NULL) {
		foregroundFramePen = pie->CreateAForegroundFramePen();
	} // if
	return foregroundFramePen;
}


HPEN GState::GetBackgroundPen()
{
	if (backgroundPen == NULL) {
		backgroundPen = pie->CreateABackgroundPen();
	} // if
	return backgroundPen;
}


HPEN GState::GetLightPen()
{
	if (lightPen == NULL) {
		lightPen = pie->CreateALightPen();
	} // if
	return lightPen;
}


HPEN GState::GetDarkPen()
{
	if (darkPen == NULL) {
		darkPen = pie->CreateADarkPen();
	} // if
	return darkPen;
}


HFONT GState::GetLastFont(HDC dc)
{
	CFont *font = pie->SelectStockFont(CDC::FromHandle(dc));
	
	return HFONT(font);
}


/////////////////////////////////////////////////////////////////////////////
